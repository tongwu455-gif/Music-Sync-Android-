/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.content.Context
import android.provider.Settings

/**
 * 设备唯一标识。
 *
 * 【为什么要持久化】
 * 原实现每次连接都生成随机 clientId：
 *     put("clientId", "mc-" + Net.randomId())
 * 导致从机每次重连都被主机当成「新从机」，列表里越积越多。
 *
 * 现在改为取 Android ID（SSAID）：
 *   - 同一设备、同一 App、重装前不变
 *   - 不需要任何权限
 *   - 长度 16 位十六进制，足够唯一
 *
 * 拿不到时兜底用「设备型号 + 首次生成的随机值」并写入 SharedPreferences。
 */
object DeviceId {

    private const val PREFS = "synccast_device"
    private const val KEY_ID = "device_id"

    @Volatile private var cached: String? = null

    fun get(ctx: Context): String {
        cached?.let { return it }

        // 1) 优先用 Android ID
        val ssAid = runCatching {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID)
        }.getOrNull()

        val id = if (!ssAid.isNullOrBlank() && ssAid != "9774d56d682e549c") {
            "dev-" + ssAid.take(12)
        } else {
            // 2) 兜底：持久化的随机值
            val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val saved = sp.getString(KEY_ID, null)
            if (!saved.isNullOrBlank()) {
                saved
            } else {
                val fresh = "dev-" + Net.randomId() + Net.randomId().take(4)
                sp.edit().putString(KEY_ID, fresh).apply()
                fresh
            }
        }
        cached = id
        return id
    }
}
