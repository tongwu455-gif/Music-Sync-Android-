/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * 通知监听服务。
 *
 * 这是获得 MediaSession 访问权限的标准入口（「设置 → 通知使用权」）。
 * 没有它，MediaSessionManager.getActiveSessions() 会直接抛 SecurityException。
 *
 * 本身不处理通知内容，只用于获得授权；媒体会话通过 MediaSessionManager 读取。
 */
class MediaNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile var connected: Boolean = false
            private set

        fun component(ctx: android.content.Context): ComponentName =
            ComponentName(ctx, MediaNotificationListener::class.java)

        /** 是否已获得通知使用权 */
        fun isAuthorized(ctx: android.content.Context): Boolean {
            val flat = android.provider.Settings.Secure.getString(
                ctx.contentResolver, "enabled_notification_listeners"
            ) ?: return false
            return flat.contains(ctx.packageName)
        }
    }

    override fun onCreate() {
        super.onCreate()
        connected = true
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        connected = false
    }

    override fun onDestroy() {
        connected = false
        super.onDestroy()
    }

    // 通知内容不关心，仅用于持有权限
    override fun onNotificationPosted(sbn: StatusBarNotification?) = Unit
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = Unit
}
