/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.synccast.app.MainActivity
import com.synccast.app.core.MediaClientSession
import com.synccast.app.core.MediaSessionBridge

/**
 * 媒体同步从机服务：接收主机播放状态并让本机音乐 App 对齐。
 */
class MediaClientService : Service() {

    companion object {
        const val CHANNEL_ID = "synccast_media_client"
        const val NOTIF_ID = 1004
        const val ACTION_STOP = "com.synccast.action.MEDIA_CLIENT_STOP"
        const val EXTRA_IP = "ip"
        /** 4 位配对码（推荐用法） */
        const val EXTRA_CODE = "code"

        private var instance: MediaClientService? = null
        private var latest: MediaClientSession.Stats? = null
        private val listeners = mutableListOf<(MediaClientSession.Stats) -> Unit>()
        private val lock = Any()

        fun addListener(l: (MediaClientSession.Stats) -> Unit) {
            synchronized(lock) {
                listeners.add(l)
                latest?.let { l(it) }
            }
        }

        fun removeListener(l: (MediaClientSession.Stats) -> Unit) {
            synchronized(lock) { listeners.remove(l) }
        }

        fun isActive(): Boolean = instance != null

        /** 开关音量统一（本机侧） */
        fun setLocalVolumeSyncEnabled(enabled: Boolean) {
            instance?.session?.setLocalVolumeSyncEnabled(enabled)
        }

        fun isLocalVolumeSyncEnabled(): Boolean =
            instance?.session?.isLocalVolumeSyncEnabled() ?: true

        /**
         * 用 4 位配对码连接主机。
         * 程序自动试探热点网关，用户不需要知道任何 IP。
         */
        fun connectWithCode(ctx: android.content.Context, code: Int) {
            val i = Intent(ctx, MediaClientService::class.java).apply {
                putExtra(EXTRA_CODE, code)
                putExtra(EXTRA_IP, com.synccast.app.core.MediaClientSession.PLACEHOLDER_IP)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }

        /** 传统方式：直接指定 IP 连接 */
        fun connect(ctx: android.content.Context, ip: String) {
            val i = Intent(ctx, MediaClientService::class.java).apply {
                putExtra(EXTRA_IP, ip)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }

        /**
         * 配对码 + 明确主机 IP。
         *
         * 最可靠的方式：主机 IP 由 Deep Link 直接带过来，
         * 从机不必猜测网段。
         */
        fun connectWithCodeAndHost(ctx: android.content.Context, code: Int, host: String) {
            val i = Intent(ctx, MediaClientService::class.java).apply {
                putExtra(EXTRA_CODE, code)
                putExtra(EXTRA_IP, host)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }

        /** 停止从机服务（简洁模式用） */
        fun stop(ctx: android.content.Context) {
            runCatching {
                ctx.startService(
                    Intent(ctx, MediaClientService::class.java).setAction(ACTION_STOP)
                )
            }
        }
    }

    private var session: MediaClientSession? = null

    /** 从机报到器：连上热点后让主机能发现本机 */
    private var announcer: com.synccast.app.core.SlaveAnnouncer? = null

    /** 接收主机「请连接我」指令 */
    private var connectReceiver: com.synccast.app.core.HostConnectReceiver? = null

    /** 待自动连接的主机配对码（主机主动拉时设置） */
    @Volatile private var pendingAutoCode: Int = 0
    @Volatile private var pendingAutoHost: String = ""

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            session?.stop()
            session = null
            announcer?.stop()
            announcer = null
            stopSelf()
            return START_NOT_STICKY
        }
        val ip = intent?.getStringExtra(EXTRA_IP)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        // 至少要有一个连接目标
        if (ip.isNullOrBlank() && code <= 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        // 启动报到器，让热点主机能发现本机
        if (announcer == null) {
            announcer = com.synccast.app.core.SlaveAnnouncer(com.synccast.app.core.Net.randomId()).also {
                it.start()
            }
        }
        // 启动「主机主动拉我」接收器：主机点连接时会发指令过来
        if (connectReceiver == null) {
            connectReceiver = com.synccast.app.core.HostConnectReceiver { c, host ->
                android.util.Log.i("SyncCast", "收到主机连接指令 code=$c host=$host")
                pendingAutoCode = c
                pendingAutoHost = host
                // 切回主线程执行连接
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    runCatching { autoConnect() }
                }
            }.also { it.start() }
        }
        if (session == null) {
            val bridge = MediaSessionBridge(this)
            val s = try {
                MediaClientSession(
                    hostIp = ip ?: com.synccast.app.core.MediaClientSession.PLACEHOLDER_IP,
                    port = com.synccast.app.core.Net.CONTROL_PORT,
                    pairingCode = code,
                    bridge = bridge,
                    targetPackage = null,
                    deviceId = com.synccast.app.core.DeviceId.get(this),
                    onStats = { st ->
                        synchronized(lock) { latest = st }
                        val snap: List<(MediaClientSession.Stats) -> Unit>
                        synchronized(lock) { snap = listeners.toList() }
                        for (l in snap) runCatching { l(st) }
                        updateNotification(st)
                    },
                    onLog = { android.util.Log.i("SyncCast", it) }
                )
            } catch (t: Throwable) {
                android.util.Log.e("SyncCast", "创建 MediaClientSession 失败", t)
                stopSelf()
                return START_NOT_STICKY
            }
            if (!s.start()) {
                stopSelf()
                return START_NOT_STICKY
            }
            s.attachVolume(com.synccast.app.core.VolumeController(this))
            session = s
        }
        return START_NOT_STICKY
    }

    /**
     * 主机动「拉」从机时的自动连接。
     * 由 HostConnectReceiver 触发，用主机下发的配对码建立连接。
     */
    fun autoConnect() {
        val c = pendingAutoCode
        if (c <= 0) return
        if (session != null) return
        android.util.Log.i("SyncCast", "自动连接主机 code=$c host=$pendingAutoHost")
        startAsForeground()
        val bridge = MediaSessionBridge(this)
        val s = try {
            MediaClientSession(
                hostIp = pendingAutoHost.ifBlank {
                    com.synccast.app.core.MediaClientSession.PLACEHOLDER_IP
                },
                port = com.synccast.app.core.Net.CONTROL_PORT,
                pairingCode = c,
                bridge = bridge,
                targetPackage = null,
                deviceId = com.synccast.app.core.DeviceId.get(this),
                onStats = { st ->
                    synchronized(lock) { latest = st }
                    val snap: List<(MediaClientSession.Stats) -> Unit>
                    synchronized(lock) { snap = listeners.toList() }
                    for (l in snap) runCatching { l(st) }
                    updateNotification(st)
                },
                onLog = { android.util.Log.i("SyncCast", it) }
            )
        } catch (t: Throwable) {
            android.util.Log.e("SyncCast", "自动连接失败", t)
            return
        }
        if (s.start()) {
            s.attachVolume(com.synccast.app.core.VolumeController(this))
            session = s
        }
    }

    private fun startAsForeground(): Boolean = try {
        val n = buildNotification("媒体同步从机", "连接中…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (t: Throwable) {
        android.util.Log.e("SyncCast", "startForeground 失败", t)
        false
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "媒体同步从机", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 4, Intent(this, MediaClientService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "断开", stop).build())
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(st: MediaClientSession.Stats) {
        val nm = getSystemService(NotificationManager::class.java)
        val text = if (!st.hasPermission) "缺少通知使用权"
        else if (st.hint != null) st.hint!!
        else "已同步 · 偏差 ${st.offsetMs}ms · seek ${st.seekCount} 次"
        runCatching { nm.notify(NOTIF_ID, buildNotification("媒体同步从机", text)) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        session?.stop()
        session = null
        announcer?.stop()
        announcer = null
        connectReceiver?.stop()
        connectReceiver = null
        instance = null
        synchronized(lock) { latest = null }
        super.onDestroy()
    }
}
