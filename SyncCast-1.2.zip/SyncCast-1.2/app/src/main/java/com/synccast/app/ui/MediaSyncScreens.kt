/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.synccast.app.core.MediaClientSession
import com.synccast.app.core.MediaMasterSession
import com.synccast.app.core.MediaNotificationListener
import com.synccast.app.core.Net
import com.synccast.app.core.SlavePresenceListener
import com.synccast.app.service.MediaClientService
import com.synccast.app.service.MediaMasterService
import androidx.compose.runtime.mutableStateListOf

/**
 * 主机侧「已发现从机」列表的状态持有者。
 * 在 Composable 外暴露，方便 Service 回调时更新。
 */
class SlaveListState {
    val items = mutableStateListOf<SlavePresenceListener.SlaveInfo>()
    val state get() = items
}

@Composable
fun rememberSlaveList(): SlaveListState {
    val holder = remember { SlaveListState() }
    DisposableEffect(Unit) {
        val l: (List<SlavePresenceListener.SlaveInfo>) -> Unit = { list ->
            holder.items.clear()
            holder.items.addAll(list)
        }
        MediaMasterService.addDiscoveryListener(l)
        onDispose { MediaMasterService.removeDiscoveryListener(l) }
    }
    return holder
}

/**
 * 主机主动把「配对码连接」推送给从机 —— 由主机 UI 触发，
 * 实际是从机侧发起连接（从机去连主机）。
 *
 * 注意：TCP 连接的发起方必须是「持有服务端的一端不收」，
 * 这里由用户点「连接」时，把该从机加入待连列表并提示从机输入配对码。
 *
 * 为了真正做到「主机主动发起连接」，实现方式为：
 * 主机通过 UDP 向该从机发送一条「请连接我」的指令，
 * 从机收到后自动用配对码建立 TCP 连接。
 */
fun connectSlaveToHost(ctx: android.content.Context, slaveIp: String) {
    val code = MediaMasterService.pairingCode()
    if (code <= 0) return
    // 通过 UDP 通知该从机主动连上来
    Thread {
        runCatching {
            val payload = org.json.JSONObject().apply {
                put("t", "connect")
                put("code", code)
                put("host", MediaMasterService.localIp())
            }.toString().toByteArray(Charsets.UTF_8)
            val s = java.net.DatagramSocket()
            s.send(
                java.net.DatagramPacket(
                    payload, payload.size,
                    java.net.InetAddress.getByName(slaveIp),
                    Net.DISCOVERY_PORT
                )
            )
            s.close()
        }
    }.start()
}

/** 媒体同步：主机页 */
@Composable
fun MediaMasterScreen() {
    val ctx = LocalContext.current
    var stats by remember { mutableStateOf<MediaMasterSession.Stats?>(null) }
    var running by remember { mutableStateOf(MediaMasterService.isActive()) }
    var authorized by remember { mutableStateOf(MediaNotificationListener.isAuthorized(ctx)) }

    // 已发现的从机列表（主机主动发现）
    val slaveList = rememberSlaveList()

    DisposableEffect(Unit) {
        val l: (MediaMasterSession.Stats) -> Unit = { stats = it }
        MediaMasterService.addListener(l)
        onDispose { MediaMasterService.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            running = MediaMasterService.isActive()
            authorized = MediaNotificationListener.isAuthorized(ctx)
            kotlinx.coroutines.delay(600)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        if (!authorized) {
            PermissionCard(
                title = "需要「通知使用权」",
                body = "Android 只有拿到通知使用权，才允许读取网易云/QQ音乐的播放状态。" +
                    "这是系统标准权限，不会读取你的通知内容。",
                action = "去授权",
                onAction = {
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            )
            Spacer(Modifier.height(12.dp))
        }

        // ── 配对码卡片：4 位数字大字显示 ──
        if (running && (stats?.pairingCode ?: 0) > 0) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "让从机连接这个配对码",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    // 4 位码逐位显示，字间距拉开，方便念/输
                    Text(
                        stats?.pairingCode?.toString()?.toCharArray()?.joinToString(" ") ?: "----",
                        color = Color.White,
                        fontSize = 46.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (stats?.hotspotHost == true)
                            "本机已是热点 · IP ${stats?.localIp}"
                        else
                            "提示：先在系统设置里开启热点，从机连上后再点下方按钮",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(Modifier.height(14.dp))
                    // 一键分享连接链接
                    Button(
                        onClick = {
                            val code = stats?.pairingCode ?: 0
                            val ip = stats?.localIp ?: ""
                            if (code > 0) {
                                val link = com.synccast.app.core.ConnectLink.build(code, ip)
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "用 SyncCast 一起听歌，点这个链接直接连接：\n$link"
                                    )
                                }
                                runCatching {
                                    ctx.startActivity(
                                        Intent.createChooser(share, "分享连接链接")
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                }
                            }
                        },
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("分享连接链接", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // ── 发现的从机（主机主动发现）──
        if (running) {
            val slaves = slaveList.items
            SectionCard("发现附近的从机") {
                if (slaves.isEmpty()) {
                    Text(
                        "正在搜索…\n请让从机连上本机热点，并打开 SyncCast",
                        fontSize = 13.sp, color = Color.Gray
                    )
                } else {
                    for (s in slaves) {
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(s.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(s.ip, fontSize = 12.sp, color = Color.Gray)
                            }
                            Button(onClick = { connectSlaveToHost(ctx, s.ip) }) {
                                Text("连接")
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        SectionCard("主机状态") {
            StatRow("运行中", if (running) "是" else "否")
            StatRow("授权状态", if (authorized) "已授权 ✅" else "未授权 ❌")
            StatRow("配对码", if ((stats?.pairingCode ?: 0) > 0) "${stats?.pairingCode}" else "-")
            StatRow("热点主机", if (stats?.hotspotHost == true) "是" else "否")
            StatRow("本机 IP", stats?.localIp ?: "-")
            StatRow("已连从机", "${stats?.clients ?: 0} 台")
            StatRow("当前歌曲", stats?.songTitle ?: "-")
            StatRow("歌手", stats?.songArtist ?: "-")
            StatRow("播放位置", formatMs(stats?.positionMs ?: 0))
            StatRow("播放状态", if (stats?.playing == true) "播放中" else "已暂停")
            StatRow("媒体音量", "${stats?.volumePercent ?: 0}%  (${stats?.volumeLevel ?: "-"})")
            stats?.error?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = Color.Red, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("统一音量") {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("音量统一", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        if (stats?.volumeSyncEnabled != false) "开启：从机音量跟随主机"
                        else "关闭：各机音量独立控制",
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                androidx.compose.material3.Switch(
                    checked = stats?.volumeSyncEnabled != false,
                    onCheckedChange = { enabled ->
                        MediaMasterService.setVolumeSyncEnabled(enabled)
                    }
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "拖动会同时改变本机与所有从机的媒体音量（按百分比对齐，" +
                    "不同机型音量档位不同）。关闭后各机互不影响。",
                fontSize = 12.sp, color = Color.Gray
            )
            Spacer(Modifier.height(8.dp))
            val vc = remember { com.synccast.app.core.VolumeController(ctx) }
            var pct by remember { mutableStateOf((vc.currentPercent() * 100).toInt()) }
            Text("${pct}%", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            androidx.compose.material3.Slider(
                value = pct.toFloat(),
                onValueChange = {
                    pct = it.toInt()
                    vc.setPercent(it / 100f)
                },
                valueRange = 0f..100f,
                enabled = stats?.volumeSyncEnabled != false
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 50, 70, 100).forEach { preset ->
                    Button(
                        onClick = {
                            pct = preset
                            vc.setPercent(preset / 100f)
                        },
                        enabled = stats?.volumeSyncEnabled != false,
                        modifier = Modifier.weight(1f)
                    ) { Text("$preset%", fontSize = 12.sp) }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("使用说明") {
            Text(
                "1. 本机打开网易云，播放你想同步的歌\n" +
                    "2. 点下面「启动同步主机」\n" +
                    "3. 其他手机在同一 Wi-Fi 下打开 SyncCast，进入「媒体同步 · 从机」，输入本机 IP\n" +
                    "4. 从机会自动对齐进度；若提示歌曲不同，请手动切到同一首\n\n" +
                    "本模式不录音、不外放，音质是网易云原生音质。",
                fontSize = 13.sp
            )
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (running) {
                    ctx.startService(
                        Intent(ctx, MediaMasterService::class.java)
                            .setAction(MediaMasterService.ACTION_STOP)
                    )
                } else {
                    val i = Intent(ctx, MediaMasterService::class.java)
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        ctx.startForegroundService(i)
                    } else {
                        ctx.startService(i)
                    }
                }
                running = !running
            },
            enabled = authorized,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text(if (running) "停止同步主机" else "启动同步主机")
        }
    }
}

/** 媒体同步：从机页 */
@Composable
fun MediaClientScreen(
    /** Deep Link 带入的配对码，> 0 时自动连接 */
    autoCode: Int = 0,
    /** Deep Link 带入的主机 IP */
    autoHost: String = "",
    /** 自动连接后通知外层清理待处理状态 */
    onAutoConnected: () -> Unit = {}
) {
    val ctx = LocalContext.current
    var ip by remember { mutableStateOf("") }
    // 4 位配对码输入
    var codeInput by remember { mutableStateOf("") }
    var stats by remember { mutableStateOf<MediaClientSession.Stats?>(null) }
    var running by remember { mutableStateOf(MediaClientService.isActive()) }
    var authorized by remember { mutableStateOf(MediaNotificationListener.isAuthorized(ctx)) }
    var error by remember { mutableStateOf<String?>(null) }

    // 本机音量统一开关：用独立本地状态，立即响应点击
    var localVolOn by remember {
        mutableStateOf(MediaClientService.isLocalVolumeSyncEnabled())
    }
    // 是否已真正连上主机
    val connected = stats?.connected == true

    DisposableEffect(Unit) {
        val l: (MediaClientSession.Stats) -> Unit = { stats = it }
        MediaClientService.addListener(l)
        onDispose { MediaClientService.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            running = MediaClientService.isActive()
            authorized = MediaNotificationListener.isAuthorized(ctx)
            // 与服务端状态同步（服务重启后会重置为 true）
            localVolOn = MediaClientService.isLocalVolumeSyncEnabled()
            kotlinx.coroutines.delay(600)
        }
    }

    // ── Deep Link 自动连接 ──
    // 从链接点进来时，autoCode > 0，直接建立连接，无需用户操作
    LaunchedEffect(autoCode, autoHost) {
        if (autoCode > 0) {
            codeInput = autoCode.toString()
            error = null
            try {
                if (autoHost.isNotBlank()) {
                    MediaClientService.connectWithCodeAndHost(ctx, autoCode, autoHost)
                } else {
                    MediaClientService.connectWithCode(ctx, autoCode)
                }
                running = true
            } catch (t: Throwable) {
                error = "自动连接失败：${t.message}"
            } finally {
                onAutoConnected()
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        if (!authorized) {
            PermissionCard(
                title = "需要「通知使用权」",
                body = "读取和控制本机网易云的播放进度需要这个系统权限。",
                action = "去授权",
                onAction = {
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            )
            Spacer(Modifier.height(12.dp))
        }

        error?.let {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
            ) {
                Text(it, color = Color(0xFFB71C1C), fontSize = 13.sp,
                    modifier = Modifier.padding(12.dp))
            }
        }

        SectionCard("输入配对码连接") {
            Text(
                "1. 先在系统设置里开启「个人热点」\n" +
                    "2. 让主机也打开 SyncCast，看它屏幕上的 4 位数字\n" +
                    "3. 把数字填在下面",
                fontSize = 12.sp,
                color = Color.Gray,
                lineHeight = 20.sp
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = codeInput,
                onValueChange = { raw ->
                    // 只允许 4 位数字
                    codeInput = raw.filter { it.isDigit() }.take(4)
                    error = null
                },
                label = { Text("4 位配对码") },
                placeholder = { Text("例如 7429") },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 8.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val code = Net.normalizeCode(codeInput)
                    if (code == null) {
                        error = "请输入 4 位配对码（1000~9999）"
                        return@Button
                    }
                    error = null
                    try {
                        MediaClientService.connectWithCode(ctx, code)
                        running = true
                    } catch (e: Throwable) {
                        error = "启动失败：${e.message}"
                    }
                },
                enabled = codeInput.length == 4,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(if (codeInput.length == 4) "连接" else "请输入 4 位数字")
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("高级：手动填 IP") {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = ip,
                    onValueChange = { ip = it },
                    label = { Text("主机 IP") },
                    placeholder = { Text("192.168.43.1") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        val t = ip.trim()
                        if (!Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(t)) {
                            error = "IP 格式不正确"
                            return@Button
                        }
                        error = null
                        try {
                            MediaClientService.connect(ctx, t)
                            running = true
                        } catch (e: Throwable) {
                            error = "启动失败：${e.message}"
                        }
                    }
                ) { Text("连接") }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "一般用不到。配对码连不上时可手动指定。",
                fontSize = 11.sp, color = Color.Gray
            )
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("音量统一") {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("本机跟随主机音量", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        when {
                            !localVolOn -> "本机已关闭（手动调节）"
                            !connected -> "未连接主机，连上后自动生效"
                            stats?.hostVolumeSyncEnabled == false -> "主机已关闭音量统一"
                            else -> "生效中：跟随主机音量"
                        },
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                androidx.compose.material3.Switch(
                    // 用本地状态驱动，立即响应，不依赖主机回调
                    checked = localVolOn,
                    onCheckedChange = { enabled ->
                        localVolOn = enabled
                        MediaClientService.setLocalVolumeSyncEnabled(enabled)
                    }
                )
            }
            Spacer(Modifier.height(6.dp))
            StatRow("本机开关", if (localVolOn) "开" else "关")
            StatRow("主机开关", when (stats?.hostVolumeSyncEnabled) {
                null -> "未连接"
                true -> "开"
                false -> "关"
            })
            StatRow(
                "实际生效",
                if (localVolOn && stats?.volumeSyncActive == true) "✅ 是" else "❌ 否"
            )
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("同步状态") {
            StatRow("已连接", if (stats?.connected == true) "是" else "否")
            StatRow("授权", if (authorized) "✅" else "❌")
            StatRow("歌曲是否一致", if (stats?.songMatch == true) "✅ 一致" else "❌ 不一致")
            StatRow("主机歌曲", "${stats?.hostSong ?: "-"} / ${stats?.hostArtist ?: ""}")
            StatRow("本机歌曲", "${stats?.localSong ?: "-"} / ${stats?.localArtist ?: ""}")
            StatRow("主机位置", formatMs(stats?.hostPositionMs ?: 0))
            StatRow("本机位置", formatMs(stats?.localPositionMs ?: 0))
            StatRow("位置差值（原始）", "${stats?.offsetMs ?: 0} ms")
            StatRow("位置差值（平滑）", "${stats?.smoothDiffMs ?: 0} ms")
            StatRow(
                "同步状态",
                if (stats?.inDeadZone == true)
                    "✅ 已同步（阈值 ${stats?.deadZoneMs}ms 内）"
                else
                    "⚠️ 偏差超 ${stats?.deadZoneMs}ms，将执行对齐"
            )
            StatRow("上次 seek 误差", if ((stats?.lastSeekErrorMs ?: 0) > 0) "${stats?.lastSeekErrorMs} ms" else "-")
            StatRow("RTT 抖动", "${stats?.jitterMs ?: 0} ms")
            StatRow("主机音量", "${stats?.hostVolumePercent ?: -1}%")
            StatRow("本机音量", "${stats?.localVolumePercent ?: 0}%")
            StatRow("音量同步", if (stats?.whileSyncingVolume == true) "对齐中…" else "✅ 一致")
            StatRow("RTT", if ((stats?.rttMs ?: -1) >= 0) "${stats?.rttMs} ms" else "-")
            StatRow("已对齐次数", "${stats?.seekCount ?: 0}")
            StatRow(
                "本周期预算",
                "${stats?.seeksInWindow ?: 0} / ${stats?.seekBudget ?: 1} 次（每1分钟）"
            )
            StatRow("主机播放态", if (stats?.hostPlaying == true) "播放中" else "暂停")
            stats?.hint?.let {
                Spacer(Modifier.height(8.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))) {
                    Text(it, color = Color(0xFF6B5200), fontSize = 13.sp,
                        modifier = Modifier.padding(10.dp))
                }
            }
            stats?.error?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = Color.Red, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                ctx.startService(
                    Intent(ctx, MediaClientService::class.java)
                        .setAction(MediaClientService.ACTION_STOP)
                )
                running = false
            },
            enabled = running,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("断开") }
    }
}

@Composable
private fun PermissionCard(title: String, body: String, action: String, onAction: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color(0xFF6B5200))
            Spacer(Modifier.height(6.dp))
            Text(body, fontSize = 13.sp, color = Color(0xFF6B5200))
            Spacer(Modifier.height(10.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
internal fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
internal fun StatRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = Color.Gray)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

internal fun formatMs(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val m = total / 60
    val s = total % 60
    return "%d:%02d.%03d".format(m, s, ms % 1000)
}
