/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Tab { HOME, MEDIA_MASTER, MEDIA_CLIENT, ABOUT }

/**
 * 界面模式。
 *
 * - SIMPLE：简洁模式，只回答「现在该做什么」，隐藏所有技术数值
 * - PRO：专业模式，显示偏差、预算、时钟抖动等全部信息
 *
 * 两种模式功能完全一致，只是信息密度不同。
 */
private enum class UiMode { SIMPLE, PRO }

@Composable
fun SyncCastApp(
    permissionsGranted: Boolean,
    onRequestPermissions: () -> Unit,
    /** Deep Link 带入的配对码，0 表示无 */
    pendingConnectCode: Int = 0,
    pendingConnectHost: String = "",
    onConsumePendingConnect: () -> Unit = {}
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current

    // 默认简洁模式；用户选择会持久化
    val prefs = remember {
        ctx.getSharedPreferences("synccast_ui", android.content.Context.MODE_PRIVATE)
    }
    var mode by remember {
        mutableStateOf(
            if (prefs.getBoolean("pro_mode", false)) UiMode.PRO else UiMode.SIMPLE
        )
    }

    var tab by remember { mutableStateOf(Tab.HOME) }

    // 收到 Deep Link 时自动跳到「从机」页
    LaunchedEffect(pendingConnectCode) {
        if (pendingConnectCode > 0) {
            tab = Tab.MEDIA_CLIENT
        }
    }

    // 简洁模式下，首次进入直接停在首页让用户选身份
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // 顶栏：模式切换 + 标签页
            TopBar(
                tab = tab,
                mode = mode,
                onSelectTab = { tab = it },
                onToggleMode = {
                    mode = if (mode == UiMode.PRO) UiMode.SIMPLE else UiMode.PRO
                    prefs.edit().putBoolean("pro_mode", mode == UiMode.PRO).apply()
                }
            )
            if (!permissionsGranted && mode == UiMode.PRO) {
                PermissionBanner(onRequestPermissions)
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(
                        if (mode == UiMode.SIMPLE) androidx.compose.foundation.layout.PaddingValues(0.dp)
                        else androidx.compose.foundation.layout.PaddingValues(12.dp)
                    )
            ) {
                when (mode) {
                    UiMode.SIMPLE -> SimpleRouter(
                        tab = tab,
                        onGoMaster = { tab = Tab.MEDIA_MASTER },
                        onGoClient = { tab = Tab.MEDIA_CLIENT },
                        pendingConnectCode = pendingConnectCode,
                        pendingConnectHost = pendingConnectHost,
                        onConsumePendingConnect = onConsumePendingConnect
                    )
                    UiMode.PRO -> ProRouter(
                        tab = tab,
                        permissionsGranted = permissionsGranted,
                        onGoMaster = { tab = Tab.MEDIA_MASTER },
                        onGoClient = { tab = Tab.MEDIA_CLIENT },
                        pendingConnectCode = pendingConnectCode,
                        pendingConnectHost = pendingConnectHost,
                        onConsumePendingConnect = onConsumePendingConnect
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionBanner(onRequest: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "需要麦克风与通知权限（主机要采集外放声音，从机要保持后台播放）。",
                modifier = Modifier.weight(1f),
                fontSize = 13.sp,
                color = Color(0xFF6B5200)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = onRequest) { Text("授权") }
        }
    }
}

@Composable
private fun TopBar(
    tab: Tab,
    mode: UiMode,
    onSelectTab: (Tab) -> Unit,
    onToggleMode: () -> Unit
) {
    // ⚠️ Compose 不允许在这里 return 提前返回（会破坏组栈导致闪退），
    // 所以用 if / else 分支。
    if (mode == UiMode.SIMPLE) {
        // ── 简洁模式顶栏 ──
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "SyncCast",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onToggleMode) {
                    Text("专业模式", fontSize = 13.sp)
                }
            }
            // 简洁模式只需要「首页 / 主机 / 从机」三个入口，不要「说明」
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val simpleItems = listOf(
                    Tab.HOME to "首页",
                    Tab.MEDIA_MASTER to "主机",
                    Tab.MEDIA_CLIENT to "从机"
                )
                for ((t, label) in simpleItems) {
                    TextButton(
                        onClick = { onSelectTab(t) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            label,
                            fontSize = 14.sp,
                            fontWeight = if (t == tab) FontWeight.Bold else FontWeight.Normal,
                            color = if (t == tab) MaterialTheme.colorScheme.primary
                            else Color.Gray
                        )
                    }
                }
            }
            HorizontalDivider(color = Color(0x14000000))
        }
    } else {
        // ── 专业模式顶栏：标签页 + 切回简洁模式 ──
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val items = listOf(
                    Tab.HOME to "首页",
                    Tab.MEDIA_MASTER to "主机",
                    Tab.MEDIA_CLIENT to "从机",
                    Tab.ABOUT to "说明"
                )
                for ((t, label) in items) {
                    TextButton(
                        onClick = { onSelectTab(t) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            label,
                            fontSize = 13.sp,
                            fontWeight = if (t == tab) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
            // 切回简洁模式的入口
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 0.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "专业模式 · 显示全部技术指标",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(Modifier.weight(1f))
                androidx.compose.material3.TextButton(
                    onClick = onToggleMode,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 10.dp, vertical = 2.dp
                    )
                ) {
                    Text("切换简洁模式", fontSize = 12.sp)
                }
            }
            HorizontalDivider()
        }
    }
}

// ------------------------------------------------------------------ 简洁模式路由

@Composable
private fun SimpleRouter(
    tab: Tab,
    onGoMaster: () -> Unit,
    onGoClient: () -> Unit,
    pendingConnectCode: Int,
    pendingConnectHost: String,
    onConsumePendingConnect: () -> Unit
) {
    when (tab) {
        Tab.HOME -> SimpleHomeScreen(
            onGoMaster = onGoMaster,
            onGoClient = onGoClient
        )
        Tab.MEDIA_MASTER -> {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            var stats by remember {
                mutableStateOf<com.synccast.app.core.MediaMasterSession.Stats?>(null)
            }
            var running by remember {
                mutableStateOf(com.synccast.app.service.MediaMasterService.isActive())
            }
            var authorized by remember {
                mutableStateOf(com.synccast.app.core.MediaNotificationListener.isAuthorized(ctx))
            }
            DisposableEffect(Unit) {
                val l: (com.synccast.app.core.MediaMasterSession.Stats) -> Unit = { stats = it }
                com.synccast.app.service.MediaMasterService.addListener(l)
                onDispose { com.synccast.app.service.MediaMasterService.removeListener(l) }
            }
            LaunchedEffect(Unit) {
                while (true) {
                    running = com.synccast.app.service.MediaMasterService.isActive()
                    authorized = com.synccast.app.core.MediaNotificationListener.isAuthorized(ctx)
                    kotlinx.coroutines.delay(500)
                }
            }
            SimpleMasterScreen(
                code = stats?.pairingCode ?: 0,
                running = running,
                authorized = authorized,
                slaves = stats?.clients ?: 0,
                songTitle = stats?.songTitle ?: "",
                playing = stats?.playing ?: false,
                hotspotHost = stats?.hotspotHost ?: false,
                localIp = stats?.localIp ?: "",
                error = stats?.error,
                onStart = {
                    runCatching {
                        com.synccast.app.service.MediaMasterService.start(ctx)
                        running = true
                    }
                },
                onStop = {
                    runCatching { com.synccast.app.service.MediaMasterService.stop(ctx) }
                    running = false
                },
                onGoPermission = {
                    runCatching {
                        ctx.startActivity(
                            android.content.Intent(
                                android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            )
        }
        Tab.MEDIA_CLIENT -> SimpleClientRouter(
            pendingConnectCode = pendingConnectCode,
            pendingConnectHost = pendingConnectHost,
            onConsumePendingConnect = onConsumePendingConnect
        )
        Tab.ABOUT -> AboutScreen()
    }
}

@Composable
private fun SimpleClientRouter(
    pendingConnectCode: Int,
    pendingConnectHost: String,
    onConsumePendingConnect: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var codeInput by remember { mutableStateOf("") }
    var stats by remember {
        mutableStateOf<com.synccast.app.core.MediaClientSession.Stats?>(null)
    }
    var running by remember {
        mutableStateOf(com.synccast.app.service.MediaClientService.isActive())
    }
    var authorized by remember {
        mutableStateOf(com.synccast.app.core.MediaNotificationListener.isAuthorized(ctx))
    }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        val l: (com.synccast.app.core.MediaClientSession.Stats) -> Unit = { stats = it }
        com.synccast.app.service.MediaClientService.addListener(l)
        onDispose { com.synccast.app.service.MediaClientService.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            running = com.synccast.app.service.MediaClientService.isActive()
            authorized = com.synccast.app.core.MediaNotificationListener.isAuthorized(ctx)
            kotlinx.coroutines.delay(500)
        }
    }

    // Deep Link 自动连接
    LaunchedEffect(pendingConnectCode, pendingConnectHost) {
        if (pendingConnectCode > 0) {
            codeInput = pendingConnectCode.toString()
            runCatching {
                if (pendingConnectHost.isNotBlank()) {
                    com.synccast.app.service.MediaClientService
                        .connectWithCodeAndHost(ctx, pendingConnectCode, pendingConnectHost)
                } else {
                    com.synccast.app.service.MediaClientService
                        .connectWithCode(ctx, pendingConnectCode)
                }
            }
            onConsumePendingConnect()
        }
    }

    // 连接失败时把错误显示出来
    LaunchedEffect(stats) {
        val e = stats?.error
        if (e != null) error = e
    }

    val connected = stats?.connected == true && running

    SimpleClientScreen(
        codeInput = codeInput,
        onCodeChange = { raw ->
            codeInput = raw.filter { it.isDigit() }.take(4)
            error = null
        },
        connected = connected,
        connecting = running && !connected && error == null,
        songTitle = stats?.hostSong ?: "",
        onConnect = {
            val code = com.synccast.app.core.Net.normalizeCode(codeInput)
            if (code == null) {
                error = "请输入 4 位配对码"
            } else {
                error = null
                runCatching {
                    com.synccast.app.service.MediaClientService.connectWithCode(ctx, code)
                    running = true
                }.onFailure { error = "启动失败：${it.message}" }
            }
        },
        onDisconnect = {
            runCatching { com.synccast.app.service.MediaClientService.stop(ctx) }
            running = false
            stats = null
            error = null
        },
        authorized = authorized,
        error = error,
        onGoPermission = {
            runCatching {
                ctx.startActivity(
                    android.content.Intent(
                        android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    )
}

/** 简洁模式首页：两个大按钮选择身份 */
@Composable
private fun SimpleHomeScreen(
    onGoMaster: () -> Unit,
    onGoClient: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(36.dp))
        Text(
            "多台手机\n同步播放同一首歌",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 38.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "这台手机要做什么？",
            fontSize = 15.sp,
            color = Color.Gray
        )
        Spacer(Modifier.height(36.dp))

        // 主机按钮
        Button(
            onClick = onGoMaster,
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("我是主机", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "这台放音乐，其他手机跟着放",
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // 从机按钮
        androidx.compose.material3.OutlinedButton(
            onClick = onGoClient,
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("我是从机", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "输配对码，跟着主机播放",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }

        Spacer(Modifier.height(28.dp))
        Text(
            "提示：先把主机热点打开，从机连上热点再输配对码",
            fontSize = 12.sp,
            color = Color.Gray,
            modifier = Modifier.fillMaxWidth(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 18.sp
        )
    }
}

// ------------------------------------------------------------------ 专业模式路由

@Composable
private fun ProRouter(
    tab: Tab,
    permissionsGranted: Boolean,
    onGoMaster: () -> Unit,
    onGoClient: () -> Unit,
    pendingConnectCode: Int,
    pendingConnectHost: String,
    onConsumePendingConnect: () -> Unit
) {
    when (tab) {
        Tab.HOME -> HomeScreen(
            permissionsGranted = permissionsGranted,
            onGoMaster = onGoMaster,
            onGoClient = onGoClient
        )
        Tab.MEDIA_MASTER -> MediaMasterScreen()
        Tab.MEDIA_CLIENT -> MediaClientScreen(
            autoCode = pendingConnectCode,
            autoHost = pendingConnectHost,
            onAutoConnected = onConsumePendingConnect
        )
        Tab.ABOUT -> AboutScreen()
    }
}

// ------------------------------------------------------------------ 首页

@Composable
private fun HomeScreen(
    permissionsGranted: Boolean,
    onGoMaster: () -> Unit,
    onGoClient: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("SyncCast", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary)
        Text("多台手机同步播放同一首歌", fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "主机外放网易云/QQ音乐，麦克风拾音后通过局域网广播给其他手机，\n" +
                "各机按统一时间轴精确对齐播放。",
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))

        BigAction(
            title = "我是主机",
            desc = "这台手机外放音乐，并采集麦克风广播",
            enabled = permissionsGranted,
            color = MaterialTheme.colorScheme.primary,
            onClick = onGoMaster
        )
        Spacer(Modifier.height(16.dp))
        BigAction(
            title = "我是从机",
            desc = "这台手机接收并同步播放",
            enabled = permissionsGranted,
            color = MaterialTheme.colorScheme.secondary,
            onClick = onGoClient
        )
        Spacer(Modifier.height(32.dp))
        Text(
            "使用提示：\n" +
                "1. 所有手机连接到同一个 Wi-Fi（或主机热点）\n" +
                "2. 主机把音量调到中高，手机靠近播放的扬声器\n" +
                "3. 从机延迟建议 200ms，网络抖动大时调到 300ms",
            fontSize = 12.sp,
            color = Color.Gray
        )
    }
}

@Composable
private fun BigAction(
    title: String,
    desc: String,
    enabled: Boolean,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(96.dp),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(desc, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ 说明

@Composable
private fun AboutScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        InfoCard(title = "工作原理") {
            Text(
                "1. 每台手机都运行 SyncCast，并各自打开网易云播放同一首歌。\n\n" +
                    "2. 主机 SyncCast 通过系统 MediaSession 读取本机网易云的播放位置（毫秒级）。\n\n" +
                    "3. 主机把「歌曲名 + 歌手 + 播放位置 + 精确时间戳」通过局域网广播给所有从机。\n\n" +
                    "4. 从机同样读取本机网易云的位置，与主机对比：\n" +
                    "   · 歌曲不一致 → 提示你手动切歌\n" +
                    "   · 位置偏差 > 200ms → 调用 seekTo 精确对齐\n\n" +
                    "这样音质是网易云原生音质，不需要录音、不需要外放。",
                fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        InfoCard(title = "已知限制") {
            Text(
                "· 需要授予「通知使用权」，这是 Android 读取 MediaSession 的标准入口。\n\n" +
                    "· 每台手机必须各自打开网易云并播放同一首歌，App 无法强制切歌。\n\n" +
                    "· 网易云不支持播放速度调节，对齐只能靠 seek，会有极短暂顿。\n\n" +
                    "· 需要所有设备在同一 Wi-Fi 或同一热点下。",
                fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        InfoCard(title = "版本") {
            StatRow("版本号", "1.2　(0.7.3-modeback)")
            StatRow("构建类型", "debug")
            StatRow("许可证", "AGPL-3.0")
        }
        Spacer(Modifier.height(12.dp))

        // ── 开源许可证声明（AGPL-3.0 要求用户能在软件内看到许可信息）──
        InfoCard(title = "开源许可证") {
            Text(
                "Copyright (C) 2026 高子谦\n\n" +
                    "本程序是自由软件：你可以依据自由软件基金会发布的 " +
                    "GNU Affero 通用公共许可证（第 3 版或你选择的任何更新版本）的条款 " +
                    "重新分发和/或修改它。\n\n" +
                    "本程序基于「希望它有用」的目的分发，但没有任何担保，" +
                    "甚至没有适销性或特定用途适用性的默示担保。详见 " +
                    "GNU Affero 通用公共许可证。\n\n" +
                    "你应当已随本程序收到 GNU Affero 通用公共许可证的副本。" +
                    "如果没有，请访问 https://www.gnu.org/licenses/",
                fontSize = 12.5.sp
            )
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = {
                    runCatching {
                        ctx.startActivity(
                            android.content.Intent(
                                android.content.Intent.ACTION_VIEW,
                                android.net.Uri.parse("https://www.gnu.org/licenses/agpl-3.0.html")
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("查看完整许可证", fontSize = 13.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ 组件

@Composable
private fun InfoCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}
