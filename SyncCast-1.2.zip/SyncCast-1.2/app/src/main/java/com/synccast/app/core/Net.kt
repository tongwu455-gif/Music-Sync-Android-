/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface
import kotlin.random.Random

/**
 * 网络常量与热点工具。
 *
 * ── 为什么用 4 位配对码，而不是「改 IP」 ──
 * Android 开热点时网关 IP 由系统固定分配（多数国产 ROM 是 192.168.43.1），
 * 应用层无法修改它。因此本项目把「4 位码」映射成控制端口：
 *
 *      控制端口 = PORT_BASE + (配对码 - CODE_MIN)
 *
 * 从机只需输入 4 位码，程序自动：
 *   1. 试探常见热点网关 IP（HOTSPOT_GATEWAYS）
 *   2. 用计算出的端口发起连接
 *
 * 用户全程看不到任何 IP。
 */
object Net {
    const val DISCOVERY_GROUP = "239.255.42.99"
    const val DISCOVERY_PORT = 47777

    /** 旧版固定端口，保留用于兼容 */
    const val CONTROL_PORT = 47778
    const val AUDIO_PORT = 47779

    /** 配对码范围：1000 ~ 9999 */
    const val CODE_MIN = 1000
    const val CODE_MAX = 9999

    /** 端口基数：实际控制端口 = PORT_BASE + (code - CODE_MIN) */
    const val PORT_BASE = 52000

    /** 常见热点 / 共享网关地址，仅作为「兜底候选」 */
    val HOTSPOT_GATEWAYS_STATIC = listOf(
        "192.168.43.1",
        "192.168.137.1",
        "192.168.1.1",
        "172.20.10.1",
        "192.168.0.1",
        "10.0.0.1",
    )

    /**
     * 推断当前网络中可能的主机候选地址。
     *
     * 【实测结论】
     * - 热点网关不一定以 .1 结尾：
     *   iQOO 的热点是 10.174.67.202/24，三星从机是 10.174.67.240
     * - 热点网段没有「默认网关」条目（主机自己就是网关）：
     *   /proc/net/route 里 ap0 的 Gateway 是 00000000
     *
     * 所以只能靠「本机 IP + 网段」穷举。
     * 优先顺序：
     *   1) 同网段的所有地址（先猜常见主机位，再全扫）
     *   2) 硬编码兜底
     */
    fun candidateHosts(): List<String> {
        val out = LinkedHashSet<String>()
        val me = localIpv4()?.address

        if (me != null) {
            val p = subnetPrefix(me)
            // 1a) 常见主机位优先（热点主机经常是 .1 / .202 / .100 等）
            for (last in listOf("1", "202", "100", "101", "254", "201", "2", "3")) {
                val c = p + last
                if (c != me) out.add(c)
            }
            // 1b) 全网段扫描（跳过网络地址 .0 和广播地址 .255）
            for (i in 1..254) {
                val c = p + i
                if (c != me) out.add(c)
            }
        }

        // 2) 硬编码兜底（跨网段时可能用得上）
        out.addAll(HOTSPOT_GATEWAYS_STATIC)

        return out.toList()
    }

    /** 从 /proc/net/route 读取默认网关（Linux 通用，无需权限） */
    fun routeGateways(): List<String> {
        val list = mutableListOf<String>()
        try {
            val f = java.io.File("/proc/net/route")
            if (!f.canRead()) return list
            f.forEachLine { line ->
                val parts = line.trim().split(Regex("\\s+"))
                if (parts.size >= 3) {
                    val dest = parts[1]
                    val gwHex = parts[2]
                    // 默认路由 dest = 00000000
                    if (dest.equals("00000000", ignoreCase = true) &&
                        !gwHex.equals("00000000", ignoreCase = true)
                    ) {
                        // 小端十六进制转 IP
                        val ip = hexToIp(gwHex)
                        if (ip != null && !ip.startsWith("0.")) list.add(ip)
                    }
                }
            }
        } catch (_: Throwable) {
        }
        return list
    }

    private fun hexToIp(hex: String): String? {
        return try {
            val v = hex.toLong(16)
            val b1 = (v and 0xFF).toString()
            val b2 = ((v shr 8) and 0xFF).toString()
            val b3 = ((v shr 16) and 0xFF).toString()
            val b4 = ((v shr 24) and 0xFF).toString()
            "$b1.$b2.$b3.$b4"
        } catch (_: Throwable) {
            null
        }
    }

    fun randomCode(): Int = Random.nextInt(CODE_MIN, CODE_MAX + 1)

    fun codeToPort(code: Int): Int = PORT_BASE + (code - CODE_MIN)

    fun portToCode(port: Int): Int = port - PORT_BASE + CODE_MIN

    fun isValidCode(code: Int): Boolean = code in CODE_MIN..CODE_MAX

    /** 规范化输入：只保留数字，必须是 4 位且在合法范围内 */
    fun normalizeCode(input: String): Int? {
        val digits = input.filter { it.isDigit() }
        if (digits.length != 4) return null
        val v = digits.toIntOrNull() ?: return null
        return if (isValidCode(v)) v else null
    }

    data class LocalIp(val address: String, val iface: NetworkInterface)

    /** 网卡名黑名单：移动数据 / 虚拟网卡不应作为主机地址 */
    private val BAD_IFACE_PREFIXES = listOf(
        "ccmni", "rmnet", "rmnet_data", "pdp", "wwan", "dummy", "tun", "p2p"
    )

    /**
     * 返回本地 IPv4，优先选「热点网卡」。
     *
     * 实测问题：iQOO 上同时有
     *   ccmni4 : 10.112.25.110   ← 移动数据，不能给从机用
     *   ap0    : 10.174.67.202   ← 热点，这才是主机地址
     * 原实现按遍历顺序取第一个，可能拿到 ccmni。
     *
     * 现在按优先级：
     *   1) 名字含 ap / softap / wlan 的热点网卡
     *   2) 其它非移动数据网卡
     */
    fun localIpv4(): LocalIp? {
        return try {
            val all = mutableListOf<LocalIp>()
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback || ni.isVirtual) continue
                val name = ni.name?.lowercase() ?: ""
                if (BAD_IFACE_PREFIXES.any { name.startsWith(it) }) continue
                for (addr in ni.inetAddresses) {
                    if (addr !is Inet4Address) continue
                    if (addr.isLoopbackAddress || addr.isLinkLocalAddress) continue
                    val ip = addr.hostAddress ?: continue
                    all.add(LocalIp(ip, ni))
                }
            }
            if (all.isEmpty()) return null

            // 1) 热点网卡优先
            all.firstOrNull {
                val n = it.iface.name.lowercase()
                n.startsWith("ap") || n.contains("softap") || n.contains("wlan")
            }?.let { return it }

            // 2) 网关位地址（.1 / .202 等常见网关结尾）
            all.firstOrNull {
                val last = it.address.substringAfterLast('.')
                last == "1" || last == "202" || last == "254"
            }?.let { return it }

            // 3) 兜底
            all.first()
        } catch (_: Throwable) {
            null
        }
    }

    /** 当前设备是否是热点主机（本地 IP 以 .1 结尾） */
    fun isHotspotHost(): Boolean =
        localIpv4()?.address?.endsWith(".1") == true

    /** 从 IP 推出网段前缀，如 "192.168.43." */
    fun subnetPrefix(ip: String): String {
        val idx = ip.lastIndexOf('.')
        return if (idx > 0) ip.substring(0, idx + 1) else ip
    }

    fun deviceName(): String {
        val m = android.os.Build.MANUFACTURER ?: ""
        val mo = android.os.Build.MODEL ?: ""
        return "$m $mo".trim().ifEmpty { "Android 设备" }
    }

    fun randomId(): String =
        java.util.UUID.randomUUID().toString().replace("-", "").take(8)
}

/**
 * 主机发现广播（旧版，保留）。
 */
class DiscoveryAdvertiser(
    private val sessionName: String,
    private val controlPort: Int = Net.CONTROL_PORT,
    private val audioPort: Int = Net.AUDIO_PORT
) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var socket: MulticastSocket? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                val group = InetAddress.getByName(Net.DISCOVERY_GROUP)
                val s = MulticastSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(Net.DISCOVERY_PORT + 1))
                s.timeToLive = 4
                s.networkInterface = Net.localIpv4()?.iface
                socket = s
                val ip = Net.localIpv4()?.address ?: ""
                val payload = JSONObject().apply {
                    put("t", "adv")
                    put("name", sessionName)
                    put("ip", ip)
                    put("control", controlPort)
                    put("audio", audioPort)
                    put("dev", Net.deviceName())
                }.toString().toByteArray(Charsets.UTF_8)
                while (running) {
                    s.send(DatagramPacket(payload, payload.size, group, Net.DISCOVERY_PORT))
                    Thread.sleep(1000)
                }
            } catch (_: Throwable) {
            } finally {
                try { socket?.close() } catch (_: Throwable) { }
            }
        }, "discovery-adv").apply { start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        try { socket?.close() } catch (_: Throwable) { }
    }
}

data class FoundHost(
    val name: String,
    val ip: String,
    val controlPort: Int,
    val audioPort: Int,
    val lastSeenMs: Long
)

/**
 * 从机侧发现监听器（旧版组播，保留兼容）。
 */
class DiscoveryListener(private val onFound: (FoundHost) -> Unit) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var socket: MulticastSocket? = null
    @Volatile var lastError: String? = null
        private set

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                val group = InetAddress.getByName(Net.DISCOVERY_GROUP)
                val s = MulticastSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(Net.DISCOVERY_PORT))
                val local = Net.localIpv4()
                if (local != null) {
                    try { s.joinGroup(InetSocketAddress(group, Net.DISCOVERY_PORT), local.iface) }
                    catch (_: Throwable) { s.joinGroup(group) }
                } else {
                    s.joinGroup(group)
                }
                socket = s
                val buf = ByteArray(2048)
                while (running) {
                    val pkt = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(pkt)
                    } catch (_: Throwable) {
                        if (!running) break else continue
                    }
                    try {
                        val o = JSONObject(String(pkt.data, 0, pkt.length, Charsets.UTF_8))
                        val ip = o.optString("ip").ifBlank { pkt.address.hostAddress }
                        onFound(
                            FoundHost(
                                name = o.optString("dev", "未知主机"),
                                ip = ip,
                                controlPort = o.optInt("control", Net.CONTROL_PORT),
                                audioPort = o.optInt("audio", Net.AUDIO_PORT),
                                lastSeenMs = System.currentTimeMillis()
                            )
                        )
                    } catch (_: Throwable) {
                    }
                }
            } catch (t: Throwable) {
                lastError = t.message
            } finally {
                try { socket?.close() } catch (_: Throwable) { }
            }
        }, "discovery-listen").apply { start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        try { socket?.close() } catch (_: Throwable) { }
    }
}

/**
 * 从机侧：连上热点后持续「报到」，让主机能发现我。
 *
 * 同时向广播地址和候选网关地址发送 UDP，
 * 覆盖「热点主机不回广播」的情况。
 */
class SlaveAnnouncer(private val deviceId: String) {

    @Volatile private var running = false
    private var thread: Thread? = null
    private var socket: DatagramSocket? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                val s = DatagramSocket()
                s.broadcast = true
                socket = s
                val name = Net.deviceName()
                val payload = JSONObject().apply {
                    put("t", "hello")
                    put("id", deviceId)
                    put("name", name)
                }.toString().toByteArray(Charsets.UTF_8)

                while (running) {
                    // 1) 全网广播（热点下通常能到达网关）
                    try {
                        s.send(
                            DatagramPacket(
                                payload, payload.size,
                                InetAddress.getByName("255.255.255.255"),
                                Net.DISCOVERY_PORT
                            )
                        )
                    } catch (_: Throwable) {
                    }
                    // 2) 向动态推断的候选主机单播（更可靠）
                    val targets = Net.candidateHosts().take(12)
                    for (gw in targets) {
                        try {
                            s.send(
                                DatagramPacket(
                                    payload, payload.size,
                                    InetAddress.getByName(gw),
                                    Net.DISCOVERY_PORT
                                )
                            )
                        } catch (_: Throwable) {
                        }
                    }
                    try {
                        Thread.sleep(1500)
                    } catch (_: InterruptedException) {
                        return@Thread
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { socket?.close() } catch (_: Throwable) { }
            }
        }, "slave-announce").apply { start() }
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Throwable) { }
        thread?.interrupt()
        thread = null
    }
}

/**
 * 主机侧：监听从机报到包，维护「在线从机」列表。
 */
class SlavePresenceListener(
    private val onSlave: (SlaveInfo) -> Unit
) {
    data class SlaveInfo(
        val id: String,
        val name: String,
        val ip: String,
        val lastSeenMs: Long
    )

    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var thread: Thread? = null

    /** 收到从机的「请连我」回复时回调（携带从机上报的 IP） */
    @Volatile var onConnectRequest: ((fromIp: String) -> Unit)? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.broadcast = true
                s.bind(InetSocketAddress(Net.DISCOVERY_PORT))
                socket = s
                val buf = ByteArray(1024)
                while (running) {
                    val pkt = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(pkt)
                    } catch (_: Throwable) {
                        if (!running) break else continue
                    }
                    try {
                        val o = JSONObject(String(pkt.data, 0, pkt.length, Charsets.UTF_8))
                        when (o.optString("t")) {
                            "hello" -> onSlave(
                                SlaveInfo(
                                    id = o.optString("id"),
                                    name = o.optString("name", "从机"),
                                    ip = pkt.address.hostAddress ?: "",
                                    lastSeenMs = System.currentTimeMillis()
                                )
                            )
                            "ack" -> {
                                // 从机确认收到「请连接」指令，开始主动连
                                onConnectRequest?.invoke(pkt.address.hostAddress ?: "")
                            }
                        }
                    } catch (_: Throwable) {
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { socket?.close() } catch (_: Throwable) { }
            }
        }, "slave-presence").apply { start() }
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Throwable) { }
        thread?.interrupt()
        thread = null
    }
}

/**
 * 从机侧：监听主机发来的「请连接我」指令。
 *
 * 主机在 UI 上点「连接」时，会向该从机 IP 的 DISCOVERY_PORT 发一条
 * {"t":"connect","code":7429}。从机收到后自动用该配对码建立连接，
 * 从而实现「主机主动发起连接」的效果。
 *
 * （TCP 层面仍由从机发起——因为主机是 ServerSocket 的持有方，
 *   这是 TCP 协议决定的，无法反转。但从用户体验上，
 *   是主机「拉」了从机一把。）
 */
class HostConnectReceiver(
    private val onConnectCmd: (code: Int, hostIp: String) -> Unit
) {
    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.broadcast = true
                s.bind(InetSocketAddress(Net.DISCOVERY_PORT + 1))
                socket = s
                val buf = ByteArray(1024)
                while (running) {
                    val pkt = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(pkt)
                    } catch (_: Throwable) {
                        if (!running) break else continue
                    }
                    try {
                        val o = JSONObject(String(pkt.data, 0, pkt.length, Charsets.UTF_8))
                        if (o.optString("t") != "connect") continue
                        val code = o.optInt("code", 0)
                        val host = o.optString("host", pkt.address.hostAddress ?: "")
                        if (Net.isValidCode(code)) {
                            onConnectCmd(code, host)
                            // 回 ACK，让主机知道指令已收到
                            val ack = JSONObject().apply { put("t", "ack") }
                                .toString().toByteArray(Charsets.UTF_8)
                            runCatching {
                                s.send(
                                    DatagramPacket(
                                        ack, ack.size,
                                        pkt.address, Net.DISCOVERY_PORT
                                    )
                                )
                            }
                        }
                    } catch (_: Throwable) {
                    }
                }
            } catch (_: Throwable) {
            } finally {
                try { socket?.close() } catch (_: Throwable) { }
            }
        }, "host-connect-receiver").apply { start() }
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Throwable) { }
        thread?.interrupt()
        thread = null
    }
}

/** 拿一个 WifiManager 多播锁，避免部分机型休眠后收不到组播。 */
fun acquireMulticastLock(ctx: Context): WifiManager.MulticastLock? {
    return try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.createMulticastLock("synccast-mcast").apply {
            setReferenceCounted(false)
            acquire()
        }
    } catch (_: Throwable) {
        null
    }
}
