/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import org.json.JSONObject

/**
 * 控制消息。
 *
 * 主机 -> 从机：
 *   hello   : 会话参数（采样率/声道/缓冲），从机据此建 AudioTrack
 *   ping    : 测延迟，字段 t0(主机发送时刻) seq
 *   state   : 播放状态，playing / epochHostNs / delayUs / volume
 *   clock   : 低频时钟校准
 *
 * 从机 -> 主机：
 *   welcome : 上报设备名
 *   ping    : 回包，t0(原样带回) / seq / 从机收到时的本地时刻无需带（主机自己算）
 */
object Msg {

    fun pack(t: String, vararg pairs: Pair<String, Any?>): String {
        val o = JSONObject()
        o.put("t", t)
        for ((k, v) in pairs) if (v != null) o.put(k, v)
        return o.toString()
    }

    fun parse(s: String): JSONObject = JSONObject(s)

    fun hello(rate: Int, channels: Int, bufferBytes: Int, masterName: String): String = pack(
        "hello",
        "rate" to rate,
        "channels" to channels,
        "bufferBytes" to bufferBytes,
        "name" to masterName
    )

    fun welcome(deviceName: String): String = pack("welcome", "name" to deviceName)

    /** 主机发起的 ping，只带 t0（主机发送时刻，纳秒）。 */
    fun ping(seq: Long, t0: Long): String = pack("ping", "seq" to seq, "t0" to t0)

    /** 从机回包，原样带回 t0 与 seq。 */
    fun pongLegacy(seq: Long, t0: Long): String = pack("pong", "seq" to seq, "t0" to t0)

    /**
     * 播放状态。
     * @param epochHostNs 主机时间轴上「播放位置 0」对应的主机时刻（纳秒）
     */
    fun state(playing: Boolean, epochHostNs: Long, delayUs: Long, volume: Float): String = pack(
        "state",
        "playing" to playing,
        "epoch" to epochHostNs,
        "delayUs" to delayUs,
        "volume" to volume.toDouble()
    )

    /**
     * RTT 回报。
     * @param rttNs 主机测得的往返时延
     * @param t0 该次 ping 的主机发送时刻
     * @param c1 从机收到该 ping 时上报的本地时刻（带回来用于精确算偏移）
     */
    fun clock(rttNs: Long, t0: Long, c1: Long): String = pack(
        "clock",
        "rtt" to rttNs,
        "t0" to t0,
        "c1" to c1
    )

    /** 从机回 pong 时带上自己收到 ping 的本地时刻，供主机在 clock 里原样带回。 */
    fun pong(seq: Long, t0: Long, localRecvNs: Long, localReplyNs: Long): String = pack(
        "pong",
        "seq" to seq,
        "t0" to t0,
        "c1" to localRecvNs,
        "c2" to localReplyNs
    )
}
