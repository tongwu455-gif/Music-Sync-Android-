/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.media.session.MediaController
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

/**
 * 媒体同步从机。
 *
 * 连接主机，接收 {歌曲, 位置, 状态, 时间戳}，与本地音乐 App 对比：
 *  - 歌曲不一致 → 提示用户手动切歌（不强行切，避免打断）
 *  - 位置偏差 > 200ms → seekTo 对齐
 *  - 播放/暂停不一致 → 同步
 *
 * 时钟同步：复用 ping/pong 得到主机与本地的时间偏移，
 * 从而把主机的「位置 + 时间戳」换算成「此刻应该播到哪」。
 */
class MediaClientSession(
    /** 主机 IP。留空或传 [PLACEHOLDER_IP] 表示使用配对码模式，自动试探网关 */
    private val hostIp: String,
    /** 显式端口；配对码模式下会被覆盖 */
    private val port: Int,
    /**
     * 4 位配对码。> 0 时启用「配对码模式」：
     * 自动尝试常见热点网关 + Net.codeToPort(pairingCode)。
     */
    private val pairingCode: Int = 0,
    private val bridge: MediaSessionBridge,
    private val targetPackage: String?,
    /** 触发 seek 的偏差阈值（毫秒） */
    private val seekThresholdMs: Long = 200,
    /**
     * 设备持久化 ID（如 "dev-a1b2c3d4e5f6"）。
     *
     * 关键：必须是「同一设备每次连接都相同」的值。
     * 之前用随机 ID，导致从机每次重连都被主机当成新设备。
     */
    private val deviceId: String = "mc-" + Net.randomId(),
    private val onStats: (Stats) -> Unit,
    private val onLog: (String) -> Unit
) {
    companion object {
        /** 占位符：表示「不指定 IP，用配对码自动找主机」 */
        const val PLACEHOLDER_IP = "auto"

        /**
         * 偏差检测周期：2 秒。
         *
         * 检测本身很轻（只读 MediaSession），不产生声音中断。
         * 频繁检测的目的是「尽早发现大偏差」，
         * 但真正是否 seek 由下面的预算与迟滞机制决定。
         */
        private const val ALIGN_PERIOD_NS = 2_000_000_000L

        /**
         * 同步阈值：偏差超过 20ms 才考虑对齐。
         *
         * 20ms 是听感分界：
         * - 低于 20ms：人耳几乎分辨不出两台设备错位
         * - 超过 20ms：可能出现双声或相位干涉
         */
        const val DEAD_ZONE_MS = 20L

        /**
         * 迟滞：需要连续 N 次检测都超过阈值，才确认要 seek。
         *
         * 单次超阈值可能是测量噪声（网络抖动、MediaSession 刷新时机），
         * 连续 3 次超标（约 6 秒）说明是真实漂移。
         */
        private const val CONFIRM_COUNT = 3

        /**
         * 严重偏差：超过这个值立即 seek，不走预算。
         * 500ms 的错位是灾难性的，用户会立刻听出来。
         */
        private const val SEVERE_DIFF_MS = 500L

        /**
         * 预算窗口：1 分钟。
         *
         * 原来 5 分钟，改成 1 分钟让系统对漂移的响应更快：
         * 一旦累积偏差超阈值，最多等 1 分钟就能纠正，
         * 而不是拖到 5 分钟后才允许对齐。
         */
        private const val BUDGET_WINDOW_NS = 60_000_000_000L

        /**
         * 每个 1 分钟窗口允许的 seek 次数。
         *
         * 注意：1 分钟 × 1 次 = 5 分钟最多 5 次，
         * 比原来「5 分钟 2 次」的上限更宽松。
         * 如果实际听感觉得卡顿偏多，把这个改回 2 次窗口即可。
         */
        private const val BUDGET_MAX_SEEKS = 1

        /** 两次 seek 的最小间隔，5 秒 */
        private const val MIN_SEEK_INTERVAL_NS = 5_000_000_000L

        /** seek 前预加量：补偿 seek 从发出到实际生效的耗时 */
        private const val SEEK_LEAD_MS = 0L
    }

    data class Stats(
        val connected: Boolean,
        val hostSong: String,
        val hostArtist: String,
        val hostPositionMs: Long,
        val hostPlaying: Boolean,
        val hostVolumePercent: Int,
        val localVolumePercent: Int,
        val whileSyncingVolume: Boolean,
        val localSong: String,
        val localArtist: String,
        val localPositionMs: Long,
        val localPlaying: Boolean,
        val offsetMs: Long,
        val rttMs: Long,
        val songMatch: Boolean,
        val lastSeekAtMs: Long,
        val seekCount: Int,
        val seeking: Boolean,
        val hasPermission: Boolean,
        val error: String?,
        val hint: String?,
        /** 是否处于死区内（偏差可接受） */
        val inDeadZone: Boolean,
        /** 上一次 seek 的实际误差 */
        val lastSeekErrorMs: Long,
        /** RTT 抖动 */
        val jitterMs: Long,
        /** 死区阈值 */
        val deadZoneMs: Long,
        /** 平滑后的偏差（毫秒），决策依据 */
        val smoothDiffMs: Long,
        /** 当前窗口内已用 seek 次数 */
        val seeksInWindow: Int,
        /** 本窗口 seek 上限 */
        val seekBudget: Int,
        /** 音量统一实际是否生效 */
        val volumeSyncActive: Boolean,
        /** 主机侧开关 */
        val hostVolumeSyncEnabled: Boolean,
        /** 本机侧开关 */
        val localVolumeSyncEnabled: Boolean
    )

    private val clock = ClockSync()
    private var socket: Socket? = null
    private var fs: FrameStream? = null
    private var readThread: Thread? = null
    private var alignThread: Thread? = null
    private var statsThread: Thread? = null

    @Volatile private var running = false
    @Volatile private var fatalError: String? = null

    // 主机最新状态
    @Volatile private var hostTitle = ""
    @Volatile private var hostArtist = ""
    @Volatile private var hostPosMs = 0L
    @Volatile private var hostPlaying = false
    @Volatile private var hostSpeed = 1f
    @Volatile private var hostStampLocalNs = 0L
    @Volatile private var hostSeekable = false
    @Volatile private var hasHostState = false

    @Volatile private var seekCount = 0
    @Volatile private var lastSeekAt = 0L
    @Volatile private var seeking = false
    @Volatile private var hint: String? = null

    /** 原始快照位置（未外推），-1 表示未收到 */
    @Volatile private var rawPosMs = -1L
    /** 是否处于死区内（偏差可接受） */
    @Volatile private var inDeadZone = false
    /** 上一次 seek 的目标位置，-1 表示无待校验 */
    @Volatile private var pendingSeekTargetMs = -1L
    /** 上一次 seek 的校验误差 */
    @Volatile private var lastSeekErrorMs = 0L

    /** 最近 3 次偏差，用于中位数平滑 */
    private val diffHistory = java.util.ArrayDeque<Long>()
    /** 平滑后的偏差（毫秒），供 UI 显示 */
    @Volatile private var lastSmoothDiffMs = 0L
    /** 累计 seek 次数（旧值，保留兼容） */
    @Volatile private var skippedAlignCount = 0

    /** 连续超阈值的次数（迟滞用） */
    @Volatile private var overCount = 0

    /** 预算窗口起始时刻 */
    @Volatile private var budgetWindowStartNs = System.nanoTime()
    /** 当前窗口内已用 seek 次数 */
    @Volatile private var seeksInWindow = 0

    /** 主机音量百分比 -1 表示未收到 */
    @Volatile private var hostVolumePercent = -1
    @Volatile private var volumeController: VolumeController? = null

    /** 主机侧音量统一开关 */
    @Volatile private var hostVolumeSyncEnabled = true
    /** 本机侧强制开关（与主机开关是「与」关系） */
    @Volatile private var localVolumeSyncEnabled = true

    /** 实际是否生效：两个开关都为真 */
    fun isVolumeSyncActive(): Boolean = hostVolumeSyncEnabled && localVolumeSyncEnabled

    /** 本机开关音量统一 */
    fun setLocalVolumeSyncEnabled(enabled: Boolean) {
        localVolumeSyncEnabled = enabled
        onLog("本机音量统一 -> ${if (enabled) "开启" else "关闭"}")
    }

    fun isHostVolumeSyncEnabled(): Boolean = hostVolumeSyncEnabled
    fun isLocalVolumeSyncEnabled(): Boolean = localVolumeSyncEnabled

    fun attachVolume(vc: VolumeController) {
        volumeController = vc
    }

    fun start(): Boolean {
        if (running) return true
        running = true
        Thread({ doConnect() }, "media-client-connect").start()
        return true
    }

    /**
     * 建连。
     *
     * 【配对码模式】依次（并行）试探候选主机地址：
     *   - 系统路由表里的默认网关（最准）
     *   - 本机网段内的常见地址（因为热点网关不一定以 .1 结尾，
     *     实测 iQOO 热点网关是 10.174.67.202）
     *   - 硬编码兜底
     * 用 Net.codeToPort(pairingCode) 作为端口，第一个连通的即为主机。
     *
     * 【性能】候选地址多（30+），必须并行探测 + 短超时，
     * 否则串行等待会让用户等上一分钟。
     */
    private fun doConnect() {
        val explicitIp = hostIp.trim()
        val hasExplicit = explicitIp.isNotEmpty() && explicitIp != PLACEHOLDER_IP

        val portForCode = if (pairingCode > 0) Net.codeToPort(pairingCode) else port

        val candidates: List<String> = when {
            hasExplicit && pairingCode <= 0 -> listOf(explicitIp)
            hasExplicit -> listOf(explicitIp) + Net.candidateHosts().filter { it != explicitIp }
            else -> Net.candidateHosts()
        }

        if (candidates.isEmpty()) {
            fatalError = "没有可用的连接目标"
            onLog(fatalError!!)
            running = false
            return
        }

        onLog("开始在 ${candidates.size} 个候选地址中查找主机（端口 $portForCode）")

        // 并行探测：谁先连上就用谁。
        // 候选可能有 250+ 个，用 32 线程 + 250ms 超时，
        // 总耗时约 2~4 秒。
        val found = java.util.concurrent.atomic.AtomicReference<Socket?>(null)
        val done = java.util.concurrent.CountDownLatch(1)
        val threads = minOf(32, candidates.size)
        val pool = java.util.concurrent.Executors.newFixedThreadPool(threads)

        for (ip in candidates) {
            pool.execute {
                if (found.get() != null || !running) return@execute
                var s: Socket? = null
                try {
                    s = Socket()
                    s.connect(InetSocketAddress(ip, portForCode), 250)
                    s.tcpNoDelay = true
                    // 抢占式：谁先连上谁赢
                    if (found.compareAndSet(null, s)) {
                        onLog("连通成功：$ip:$portForCode")
                        done.countDown()
                    } else {
                        try { s.close() } catch (_: Throwable) { }
                    }
                } catch (_: Throwable) {
                    try { s?.close() } catch (_: Throwable) { }
                }
            }
        }

        // 总超时 15 秒
        val ok = try {
            done.await(15, java.util.concurrent.TimeUnit.SECONDS)
        } catch (_: InterruptedException) {
            false
        }
        pool.shutdownNow()

        val sock = found.get()
        if (sock != null) {
            finishConnect(sock)
            return
        }

        fatalError = if (!ok)
            "连接主机失败：${candidates.size} 个地址均无响应。\n" +
                "请确认：① 主机已点「启动同步主机」 ② 两台在同一热点或同一 Wi-Fi 下"
        else
            "连接主机失败"
        onLog(fatalError!!)
        running = false
    }

    /** 已完成 TCP 建连，进行握手与启动线程 */
    private fun finishConnect(sock: Socket) {
        if (!running) {
            try { sock.close() } catch (_: Throwable) { }
            return
        }
        socket = sock
        val frameStream = FrameStream.open(sock)
        fs = frameStream
        try {
            frameStream.writeJson(
                JSONObject().apply {
                    put("t", "hello")
                    // 用持久化设备 ID，保证重连时主机能认出是同一台
                    put("clientId", deviceId)
                    put("name", Net.deviceName())
                }.toString()
            )
        } catch (t: Throwable) {
            fatalError = "握手失败：${t.message}"
            onLog(fatalError!!)
            closeAll()
            running = false
            return
        }
        readThread = Thread({ readLoop(frameStream) }, "media-read").apply { start() }
        alignThread = Thread({ alignLoop() }, "align").apply { start() }
        statsThread = Thread({ statsLoop() }, "media-stats").apply { start() }
        onLog("已连接同步主机 $hostIp")
    }

    private fun readLoop(f: FrameStream) {
        try {
            while (running) {
                val frame = f.readFrame()
                if (frame.type != Proto.MAGIC_TYPE_CONTROL) continue
                val o = JSONObject(String(frame.payload, Charsets.UTF_8))
                when (o.optString("t")) {
                    "ping" -> {
                        val seq = o.optLong("seq")
                        val t0 = o.optLong("t0")
                        val recv = Timeline.nowNs()
                        clock.onIncomingPing(t0, recv, recv)
                        runCatching { f.writeJson(Msg.pong(seq, t0, recv, Timeline.nowNs())) }
                    }
                    "clock" -> {
                        val rtt = o.optLong("rtt", -1)
                        if (rtt > 0) clock.onRttReported(rtt, o.optLong("t0"), o.optLong("c1"))
                    }
                    "volsync" -> {
                        // 主机侧音量统一开关
                        hostVolumeSyncEnabled = o.optBoolean("enabled", true)
                        val pct = o.optInt("vol", -1)
                        if (pct >= 0 && hostVolumeSyncEnabled && isVolumeSyncActive()) {
                            hostVolumePercent = pct
                            applyVolumeNow(pct)
                        }
                    }
                    "volume" -> {
                        // 音量包：立即对齐，不等待下一轮
                        val pct = o.optInt("vol", -1)
                        if (pct >= 0) {
                            hostVolumePercent = pct
                            applyVolumeNow(pct)
                        }
                    }
                    "media" -> {
                        hostTitle = o.optString("title")
                        hostArtist = o.optString("artist")
                        hostPosMs = o.optLong("pos")
                        hostPlaying = o.optBoolean("playing")
                        hostSpeed = o.optDouble("speed", 1.0).toFloat()
                        hostSeekable = o.optBoolean("seekable")
                        val pct = o.optInt("vol", -1)
                        if (pct >= 0 && pct != hostVolumePercent) {
                            hostVolumePercent = pct
                            applyVolumeNow(pct)
                        }
                        rawPosMs = o.optLong("rawPos", -1L)
                        // 换算成本地时刻
                        hostStampLocalNs = clock.hostToLocal(o.optLong("hostNs"))
                        hasHostState = true
                    }
                }
            }
        } catch (_: Throwable) {
        } finally {
            if (running) fatalError = "与主机连接已断开"
        }
    }

    /**
     * 对齐循环。
     *
     * 周期：每 3 秒执行一次主动对齐（用户要求），
     * 中间每 100ms 只做轻量监控，不触碰音乐 App。
     *
     * 死区：15ms 以内不动，避免 seek 抖动。
     * seek 后校验：记录目标位置与发起时刻，下次比对确认是否生效。
     */
    private fun alignLoop() {
        var lastAlignNs = 0L
        while (running) {
            try {
                val now = System.nanoTime()
                val due = (now - lastAlignNs) >= ALIGN_PERIOD_NS
                doMonitor()          // 轻量：更新统计与音量
                if (due) {
                    lastAlignNs = now
                    doAlign()        // 重量：必要时 seek
                }
            } catch (t: Throwable) {
                onLog("对齐异常：${t.message}")
            }
            try { Thread.sleep(100) } catch (_: InterruptedException) { return }
        }
    }

    /**
     * 计算「此刻主机应该播放到的位置（毫秒）」。
     *
     * 用主机下发的原始快照做本地外推，比直接用主机外推好的值更准：
     *   主机时刻 hostStamp 对应主机位置 rawPos
     *   经过 (现在本地时刻 - hostStamp 的本地等价) 之后
     *   应再前进 elapsed * speed
     *
     * hostNs 是主机发消息瞬间的主机时钟，经 clock.hostToLocal 换算成本地时刻，
     * 再与本地 now 相减得到真实经过时间。
     */
    private fun hostPositionNowMs(): Long {
        if (!hasHostState) return 0
        val basePos = if (rawPosMs >= 0) rawPosMs else hostPosMs
        if (!hostPlaying) return basePos
        val elapsedNs = System.nanoTime() - hostStampLocalNs
        // 认为消息在主机侧发出到我们换算之间存在极小误差，忽略
        val elapsedMs = (elapsedNs / 1_000_000L).coerceAtLeast(0)
        return basePos + (elapsedMs * hostSpeed).toLong()
    }

    /** 轻量监控：只读本地状态、对齐音量，不做 seek */
    private fun doMonitor() {
        // 兜底：即使没收到音量包，也保证音量跟随（覆盖丢包情况）
        alignVolume()
    }

    /**
     * 立即应用音量（收到 volume 包时调用，不等轮询）。
     *
     * 关键：只改变本机音量，绝不回写主机。
     * 之前的实现让主从互相覆盖，形成拉锯。
     */
    private fun applyVolumeNow(percent: Int) {
        if (!isVolumeSyncActive()) return
        val vc = volumeController ?: return
        val localPct = (vc.currentPercent() * 100).toInt()
        // 已经足够接近就不动，避免频繁调用
        if (kotlin.math.abs(localPct - percent) <= 1) return
        val ok = vc.setPercent(percent / 100f)
        if (!ok) onLog("设置音量失败：目标 ${percent}%")
    }

    /**
     * 音量对齐兜底（轮询式）。
     *
     * 阈值从 5% 收紧到 2%——实测两台手机
     * 19/150=12.7% 与 2/15=13.3% 只差 0.6%，
     * 5% 的阈值会让它们永远不调。
     */
    private fun alignVolume() {
        if (!isVolumeSyncActive()) return
        val vc = volumeController ?: return
        if (hostVolumePercent < 0) return
        val localPct = (vc.currentPercent() * 100).toInt()
        if (kotlin.math.abs(localPct - hostVolumePercent) <= 2) return
        vc.setPercent(hostVolumePercent / 100f)
    }

    /** 周期对齐：必要时 seek */
    private fun doAlign() {
        if (!hasHostState || !clock.isSynced) {
            hint = "等待时钟同步"
            return
        }
        val ctrl: MediaController = bridge.findController(targetPackage) ?: run {
            hint = "未检测到音乐 App，请打开网易云"
            return
        }
        val local = bridge.snapshot(ctrl) ?: run {
            hint = "音乐 App 无播放信息"
            return
        }

        // 歌曲一致性
        val hostKey = normalizeKey(hostTitle, hostArtist)
        val localKey = normalizeKey(local.title, local.artist)
        val songMatch = hostKey.isNotEmpty() && hostKey == localKey
        if (!songMatch) {
            hint = "歌曲不同：请手动切到「${hostTitle}」"
            return
        }
        hint = null

        // 播放状态同步
        if (hostPlaying != local.playing) {
            if (System.nanoTime() - lastSeekAt > 1_000_000_000L) {
                bridge.setPlaying(ctrl, hostPlaying)
                lastSeekAt = System.nanoTime()
                onLog("同步播放状态 -> ${if (hostPlaying) "播放" else "暂停"}")
            }
            return
        }

        val hostPos = hostPositionNowMs()
        val localPos = local.positionNowMs()
        val diff = localPos - hostPos

        // ── 偏差平滑 ──
        // 用最近 3 次的中位数，抑制单次测量噪声
        synchronized(diffHistory) {
            diffHistory.addLast(diff)
            while (diffHistory.size > 3) diffHistory.removeFirst()
        }
        val smoothDiff = synchronized(diffHistory) {
            val sorted = diffHistory.sorted()
            sorted[sorted.size / 2]
        }
        lastSmoothDiffMs = smoothDiff

        // ── 死区：20ms 内视为同步良好 ──
        if (kotlin.math.abs(smoothDiff) <= DEAD_ZONE_MS) {
            inDeadZone = true
            overCount = 0          // 回到同步状态，迟滞计数清零
            return
        }
        inDeadZone = false

        // ── 迟滞：需要连续 CONFIRM_COUNT 次超标才确认 ──
        overCount++
        if (overCount < CONFIRM_COUNT && kotlin.math.abs(smoothDiff) < SEVERE_DIFF_MS) {
            // 还没确认，先等着（除非偏差极大）
            return
        }

        // ── 严重偏差直接处理（不走预算）──
        val isSevere = kotlin.math.abs(smoothDiff) >= SEVERE_DIFF_MS

        // ── 上一次 seek 结果校验 ──
        if (pendingSeekTargetMs >= 0 && System.nanoTime() - lastSeekAt < 800_000_000L) {
            return
        }
        if (pendingSeekTargetMs >= 0) {
            val delta = kotlin.math.abs(localPos - pendingSeekTargetMs)
            lastSeekErrorMs = delta
            pendingSeekTargetMs = -1
            if (delta > DEAD_ZONE_MS * 3) {
                onLog("seek 未完全生效：实际 ${localPos}ms 误差 ${delta}ms")
            }
        }

        if (!bridge.supportsSeek(local) && !hostSeekable) {
            hint = "音乐 App 不支持精确跳转"
            return
        }

        // ── 间隔保护 ──
        val nowNs = System.nanoTime()
        if (nowNs - lastSeekAt < MIN_SEEK_INTERVAL_NS && !isSevere) {
            return
        }

        // ── 预算控制：每 1 分钟窗口内最多 1 次 ──
        if (!isSevere) {
            if (nowNs - budgetWindowStartNs > BUDGET_WINDOW_NS) {
                // 窗口滚动，重置预算
                budgetWindowStartNs = nowNs
                seeksInWindow = 0
                onLog("对齐预算重置（新窗口）")
            }
            if (seeksInWindow >= BUDGET_MAX_SEEKS) {
                hint = "已用尽本周期对齐次数（${BUDGET_MAX_SEEKS}次/5分钟），等待下一窗口"
                return
            }
        } else {
            onLog("检测到严重偏差 ${smoothDiff}ms，立即对齐（不走预算）")
        }

        seeking = true
        val target = hostPos + SEEK_LEAD_MS
        val ok = bridge.seekTo(ctrl, target)
        lastSeekAt = System.nanoTime()
        seeking = false
        if (ok) {
            seekCount++
            seeksInWindow++
            overCount = 0
            pendingSeekTargetMs = target
            onLog("周期对齐：本地 ${localPos}ms -> 目标 ${target}ms (偏差 ${diff}ms)")
        } else {
            hint = "seek 失败"
        }
    }

    private fun normalizeKey(title: String, artist: String): String {
        fun clean(s: String) = s.lowercase()
            .replace(Regex("[\\s\\-_()（）\\[\\]【】·.,，。!！?？]"), "")
        return clean(title) + "|" + clean(artist)
    }

    private fun statsLoop() {
        while (running) {
            val ctrl = runCatching { bridge.findController(targetPackage) }.getOrNull()
            val local = ctrl?.let { runCatching { bridge.snapshot(it) }.getOrNull() }
            val hostKey = normalizeKey(hostTitle, hostArtist)
            val localKey = normalizeKey(local?.title ?: "", local?.artist ?: "")
            val songMatch = hostKey.isNotEmpty() && hostKey == localKey
            val hostPosNow = hostPositionNowMs()
            val vc = volumeController
            val localVolPct = ((vc?.currentPercent() ?: 0f) * 100).toInt()
            val localPos = local?.positionNowMs() ?: 0
            onStats(
                Stats(
                    connected = running,
                    hostSong = hostTitle.ifEmpty { "-" },
                    hostArtist = hostArtist,
                    hostPositionMs = hostPosNow,
                    hostPlaying = hostPlaying,
                    hostVolumePercent = hostVolumePercent,
                    localVolumePercent = localVolPct,
                    whileSyncingVolume = hostVolumePercent >= 0 &&
                        kotlin.math.abs(localVolPct - hostVolumePercent) >= 5,
                    localSong = local?.title ?: "-",
                    localArtist = local?.artist ?: "",
                    localPositionMs = localPos,
                    localPlaying = local?.playing ?: false,
                    offsetMs = localPos - hostPosNow,
                    rttMs = clock.lastRttMs,
                    songMatch = songMatch,
                    lastSeekAtMs = lastSeekAt / 1_000_000L,
                    seekCount = seekCount,
                    seeking = seeking,
                    hasPermission = bridge.hasPermission(),
                    error = fatalError,
                    hint = hint,
                    inDeadZone = inDeadZone,
                    lastSeekErrorMs = lastSeekErrorMs,
                    jitterMs = clock.jitterNs / 1_000_000,
                    deadZoneMs = DEAD_ZONE_MS,
                    smoothDiffMs = lastSmoothDiffMs,
                    seeksInWindow = seeksInWindow,
                    seekBudget = BUDGET_MAX_SEEKS,
                    volumeSyncActive = isVolumeSyncActive(),
                    hostVolumeSyncEnabled = hostVolumeSyncEnabled,
                    localVolumeSyncEnabled = localVolumeSyncEnabled
                )
            )
            try { Thread.sleep(300) } catch (_: InterruptedException) { return }
        }
    }

    fun stop() {
        running = false
        readThread?.interrupt()
        alignThread?.interrupt()
        statsThread?.interrupt()
        readThread = null
        alignThread = null
        statsThread = null
        closeAll()
    }

    private fun closeAll() {
        try { socket?.close() } catch (_: Throwable) { }
        socket = null
        fs = null
    }
}
