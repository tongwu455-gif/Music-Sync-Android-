/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.content.Context
import android.media.AudioManager

/**
 * 系统媒体音量控制。
 *
 * 网易云/QQ音乐播放时走 STREAM_MUSIC，音量由系统控制
 * （MediaSession 里 volumeType=LOCAL 表明音乐 App 不接管会话音量），
 * 因此第三方 App 只能通过 AudioManager 调整整机媒体音量。
 *
 * 注意：不同手机的音量档位数不同（例：小米 0~150，三星 0~15），
 * 所以同步必须按「百分比」而不是绝对值，否则会相差数倍。
 */
class VolumeController(private val ctx: Context) {

    private val am: AudioManager =
        ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val stream = AudioManager.STREAM_MUSIC

    /** 当前音量百分比 0..1 */
    fun currentPercent(): Float {
        val cur = am.getStreamVolume(stream)
        val max = am.getStreamMaxVolume(stream).coerceAtLeast(1)
        return (cur.toFloat() / max).coerceIn(0f, 1f)
    }

    fun maxVolume(): Int = am.getStreamMaxVolume(stream).coerceAtLeast(1)

    fun currentVolume(): Int = am.getStreamVolume(stream)

    /**
     * 把媒体音量设置为指定百分比。
     *
     * 注意：不使用 FLAG_SHOW_UI —— 弹出系统音量条会抢焦点，
     * 并且部分 ROM 在 UI 弹出期间会锁住音量值，导致程序设置被覆盖。
     */
    fun setPercent(percent: Float): Boolean {
        return try {
            val max = am.getStreamMaxVolume(stream)
            val target = (percent.coerceIn(0f, 1f) * max).toInt().coerceIn(0, max)
            if (am.getStreamVolume(stream) == target) return true
            am.setStreamVolume(stream, target, 0)
            // 回读校验，部分 ROM 会钳制
            am.getStreamVolume(stream) == target
        } catch (_: SecurityException) {
            false
        } catch (_: Throwable) {
            false
        }
    }

    /** 按档位设置（用于精确对齐，绕过百分比取整误差） */
    fun setVolumeRaw(volume: Int): Boolean {
        return try {
            val max = am.getStreamMaxVolume(stream)
            val target = volume.coerceIn(0, max)
            if (am.getStreamVolume(stream) == target) return true
            am.setStreamVolume(stream, target, 0)
            am.getStreamVolume(stream) == target
        } catch (_: Throwable) {
            false
        }
    }

    fun isMuted(): Boolean = am.isStreamMute(stream)

    /**
     * 注册音量变化监听。
     * 用 Handler 的 AudioManager.registerAudioDeviceCallback 拿不到音量，
     * 系统没有公开的音量变化回调，因此用轮询式监听器模拟（100ms）。
     *
     * @return 取消函数
     */
    fun observe(onChange: (percent: Float, raw: Int) -> Unit): () -> Unit {
        val stopped = java.util.concurrent.atomic.AtomicBoolean(false)
        var lastRaw = -1
        val t = Thread({
            while (!stopped.get()) {
                try {
                    val raw = am.getStreamVolume(stream)
                    if (raw != lastRaw) {
                        lastRaw = raw
                        val max = am.getStreamMaxVolume(stream).coerceAtLeast(1)
                        onChange(raw.toFloat() / max, raw)
                    }
                } catch (_: Throwable) {
                }
                try {
                    Thread.sleep(100)
                } catch (_: InterruptedException) {
                    return@Thread
                }
            }
        }, "volume-observe")
        t.isDaemon = true
        t.start()
        return {
            stopped.set(true)
            t.interrupt()
        }
    }
}
