/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.synccast.app.core.ConnectLink
import com.synccast.app.core.Net
import com.synccast.app.service.MediaClientService
import com.synccast.app.ui.SyncCastApp
import com.synccast.app.ui.theme.SyncCastTheme

class MainActivity : ComponentActivity() {

    private var permissionsGranted by mutableStateOf(false)

    /** 由 Deep Link 带入的待连接请求 */
    private var pendingConnectCode by mutableStateOf(0)
    private var pendingConnectHost by mutableStateOf("")

    private val requestPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permissionsGranted = result.values.all { it }
        // 授权完成后，如果有待连接请求，自动建立连接
        if (permissionsGranted) tryAutoConnect()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionsGranted = hasAllCorePermissions()
        handleDeepLink(intent)
        setContent {
            SyncCastTheme {
                SyncCastApp(
                    permissionsGranted = permissionsGranted,
                    onRequestPermissions = { requestPermissionsNow() },
                    pendingConnectCode = pendingConnectCode,
                    pendingConnectHost = pendingConnectHost,
                    onConsumePendingConnect = {
                        pendingConnectCode = 0
                        pendingConnectHost = ""
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDeepLink(intent)
    }

    /**
     * 解析连接链接：synccast://connect?code=7429&host=10.174.67.202
     */
    private fun handleDeepLink(intent: Intent?) {
        val payload = ConnectLink.parse(intent) ?: return
        pendingConnectCode = payload.code
        pendingConnectHost = payload.host
        // 权限已具备时立刻连接
        if (permissionsGranted) {
            tryAutoConnect()
        } else {
            // 缺权限，先请求；授权回调里会再触发
            requestPermissionsNow()
        }
    }

    /** 用链接里的 code+host 建立连接 */
    private fun tryAutoConnect() {
        val code = pendingConnectCode
        if (code <= 0) return
        val host = pendingConnectHost.ifBlank { Net.localIpv4()?.address ?: "" }
        runCatching {
            // 优先直接用链接里的主机 IP（最可靠）
            if (host.isNotBlank()) {
                MediaClientService.connectWithCodeAndHost(this, code, host)
            } else {
                MediaClientService.connectWithCode(this, code)
            }
        }
    }

    private fun requiredPermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return list.toTypedArray()
    }

    private fun hasAllCorePermissions(): Boolean {
        val must = listOf(Manifest.permission.RECORD_AUDIO)
        val ok = must.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ok && ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }
        return ok
    }

    private fun requestPermissionsNow() {
        requestPerms.launch(requiredPermissions())
    }
}
