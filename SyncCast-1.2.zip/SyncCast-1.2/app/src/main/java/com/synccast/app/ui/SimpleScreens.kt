/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 简洁模式专用组件。
 *
 * ⚠️ Compose 重要约束：本文件内所有 @Composable 函数
 * **不允许使用 return / return@Scope 提前返回**。
 *
 * 原因：Compose 依赖「组栈严格配对」——
 * 每个 Composable 的开闭会对应内部的 group 进出。
 * 提前 return 会跳过部分 endGroup()，破坏组栈，
 * 最终在 ComposerImpl.endRoot() 时抛
 * IndexOutOfBoundsException: Index -1 out of bounds
 * （v0.7.0 的闪退就是这个原因）。
 *
 * 所以全部改成 if / else 分支嵌套。
 */

internal val STATUS_OK = Color(0xFF4CA6A0)
internal val STATUS_WAIT = Color(0xFFFFA726)

/**
 * 简洁模式主机界面。
 */
@Composable
fun SimpleMasterScreen(
    code: Int,
    running: Boolean,
    authorized: Boolean,
    slaves: Int,
    songTitle: String,
    playing: Boolean,
    hotspotHost: Boolean,
    localIp: String,
    error: String?,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onGoPermission: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        if (!authorized) {
            // 未授权：只显示提示卡
            SimpleNoticeCard(
                title = "需要先开启一个权限",
                body = "SyncCast 要读取网易云/QQ音乐的播放进度，\n需要「通知使用权」。",
                action = "去开启",
                onAction = onGoPermission
            )
        } else if (!running) {
            // 已授权但未启动
            MasterStartPanel(onStart = onStart)
        } else {
            // 正在运行
            MasterRunningPanel(
                code = code,
                slaves = slaves,
                songTitle = songTitle,
                onStop = onStop,
                error = error
            )
        }
    }
}

/** 未启动时的启动面板 */
@Composable
private fun MasterStartPanel(onStart: () -> Unit) {
    Spacer(Modifier.height(40.dp))
    Text(
        "让多台手机\n同步播放同一首歌",
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 38.sp,
        color = MaterialTheme.colorScheme.onBackground
    )
    Spacer(Modifier.height(12.dp))
    Text(
        "这台手机作为「主机」",
        fontSize = 15.sp,
        color = Color.Gray
    )
    Spacer(Modifier.height(48.dp))
    Button(
        onClick = onStart,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text("开始同步", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(16.dp))
    Text(
        "开始后，其他手机输配对码就能加入",
        fontSize = 13.sp,
        color = Color.Gray,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center
    )
}

/** 运行中的面板 */
@Composable
private fun MasterRunningPanel(
    code: Int,
    slaves: Int,
    songTitle: String,
    onStop: () -> Unit,
    error: String?
) {
    // 配对码大卡片
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary
        )
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 32.dp, horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "配对码",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 14.sp
            )
            Spacer(Modifier.height(14.dp))
            Text(
                if (code > 0) code.toString().toCharArray().joinToString(" ") else "- - - -",
                color = Color.White,
                fontSize = 56.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "让其他手机输这 4 位数字",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 13.sp
            )
        }
    }

    Spacer(Modifier.height(20.dp))

    // 连接状态
    StatusBigRow(
        connected = slaves > 0,
        mainText = if (slaves > 0) "已连接 $slaves 台手机" else "等待其他手机加入",
        subText = if (slaves > 0) "可以开始播放音乐了" else "请确认对方连上了本机热点"
    )

    Spacer(Modifier.height(20.dp))

    // 当前歌曲
    if (songTitle.isNotBlank() && songTitle != "（未检测到播放）") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("正在播放", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(4.dp))
                Text(
                    songTitle,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2
                )
            }
        }
        Spacer(Modifier.height(20.dp))
    }

    // 停止按钮
    Button(
        onClick = onStop,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text("停止同步", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }

    if (error != null) {
        Spacer(Modifier.height(12.dp))
        Text(
            error,
            color = MaterialTheme.colorScheme.error,
            fontSize = 12.sp
        )
    }
}

/**
 * 简洁模式从机界面。
 */
@Composable
fun SimpleClientScreen(
    codeInput: String,
    onCodeChange: (String) -> Unit,
    connected: Boolean,
    connecting: Boolean,
    songTitle: String,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    authorized: Boolean,
    error: String?,
    onGoPermission: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        if (!authorized) {
            SimpleNoticeCard(
                title = "需要先开启一个权限",
                body = "SyncCast 要控制本机音乐的播放进度，\n需要「通知使用权」。",
                action = "去开启",
                onAction = onGoPermission
            )
        } else if (connected) {
            ClientConnectedPanel(
                songTitle = songTitle,
                onDisconnect = onDisconnect
            )
        } else {
            ClientInputPanel(
                codeInput = codeInput,
                onCodeChange = onCodeChange,
                connecting = connecting,
                error = error,
                onConnect = onConnect
            )
        }
    }
}

/** 已连接面板 */
@Composable
private fun ClientConnectedPanel(
    songTitle: String,
    onDisconnect: () -> Unit
) {
    Spacer(Modifier.height(24.dp))
    StatusBigRow(
        connected = true,
        mainText = "已连接主机",
        subText = "正在同步播放"
    )
    Spacer(Modifier.height(24.dp))

    if (songTitle.isNotBlank()) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("正在同步", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(4.dp))
                Text(
                    songTitle,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2
                )
            }
        }
        Spacer(Modifier.height(20.dp))
    }

    Text(
        "在主机上切歌，这台会自动跟随",
        fontSize = 13.sp,
        color = Color.Gray,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center
    )
    Spacer(Modifier.height(28.dp))

    Button(
        onClick = onDisconnect,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text("断开连接", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

/** 未连接：配对码输入面板 */
@Composable
private fun ClientInputPanel(
    codeInput: String,
    onCodeChange: (String) -> Unit,
    connecting: Boolean,
    error: String?,
    onConnect: () -> Unit
) {
    Spacer(Modifier.height(28.dp))
    Text(
        "输入主机屏幕上的\n4 位配对码",
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 34.sp
    )
    Spacer(Modifier.height(8.dp))
    Text(
        "先连上主机的热点，再输入",
        fontSize = 13.sp,
        color = Color.Gray
    )
    Spacer(Modifier.height(32.dp))

    OutlinedTextField(
        value = codeInput,
        onValueChange = onCodeChange,
        placeholder = {
            Text(
                "0000",
                fontSize = 40.sp,
                color = Color.LightGray,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        },
        textStyle = androidx.compose.ui.text.TextStyle(
            fontSize = 44.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 12.sp,
            textAlign = TextAlign.Center
        ),
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(96.dp)
    )

    Spacer(Modifier.height(24.dp))

    Button(
        onClick = onConnect,
        enabled = codeInput.length == 4 && !connecting,
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(
            when {
                connecting -> "正在连接…"
                codeInput.length == 4 -> "连接"
                else -> "请输入 4 位数"
            },
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
    }

    if (error != null) {
        Spacer(Modifier.height(16.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.errorContainer
            )
        ) {
            Text(
                error,
                color = MaterialTheme.colorScheme.onErrorContainer,
                fontSize = 13.sp,
                modifier = Modifier.padding(14.dp)
            )
        }
    }
}

/** 大字状态行 */
@Composable
private fun StatusBigRow(connected: Boolean, mainText: String, subText: String) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(14.dp)
                .background(
                    if (connected) STATUS_OK else STATUS_WAIT,
                    CircleShape
                )
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text(
                mainText,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
            if (subText.isNotBlank()) {
                Text(
                    subText,
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

/** 简洁提示卡 */
@Composable
private fun SimpleNoticeCard(
    title: String,
    body: String,
    action: String,
    onAction: () -> Unit
) {
    Spacer(Modifier.height(24.dp))
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFFF3CD)
        )
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(body, fontSize = 14.sp, lineHeight = 22.sp, color = Color(0xFF6B5A00))
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onAction,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(action, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
