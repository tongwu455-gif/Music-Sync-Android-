/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

/**
 * 高精度时钟同步器（v2）。
 *
 * 相对第一版的关键改进：
 *
 * 1. **偏移方向修正**：offset 定义为「本地时刻 - 主机时刻」，
 *    hostToLocal(h) = h + offset 才是正确的换算。
 *
 * 2. **精确处理 RTT**：单向延迟取 RTT/2 作为补偿，
 *    并只用 RTT 处于最低分位的样本做估计，剔除排队抖动。
 *
 * 3. **滑窗 + 中位数**：保存最近 24 个样本，
 *    取中位数抵抗单次异常，比平均值稳得多。
 *
 * 4. **漂移率估计**：同时估计 offset 随时间的变化率（ppm），
 *    用于两次样本之间的线性外推，避免样本间隔内产生误差累积。
 *
 * 5. **自适应更新频率**：由调用方控制 ping 频率，
 *    本类只负责把每次样本变成尽可能准确的偏估计。
 *
 * 精度预期：局域网内 RTT < 5ms 时，偏移估计误差可控制在 ±1ms。
 */
class ClockSync {

    /** offset = 本地时刻 - 主机时刻（纳秒） */
    @Volatile private var offsetNs: Long = 0
    @Volatile private var driftNsPerSec: Double = 0.0
    @Volatile private var offsetAnchorLocalNs: Long = 0
    @Volatile private var syncedFlag = false

    @Volatile var lastRttMs: Long = -1
        private set
    @Volatile var bestRttNs: Long = Long.MAX_VALUE
        private set
    @Volatile var sampleCount: Int = 0
        private set
    @Volatile var syncState: String = "等待同步"
        private set
    @Volatile var jitterNs: Long = 0
        private set

    private class Sample(val rttNs: Long, val offsetNs: Long, val localNs: Long)

    private val samples = ArrayList<Sample>(32)

    val isSynced: Boolean get() = syncedFlag

    /** 主机时刻 -> 本地时刻（含漂移外推） */
    fun hostToLocal(hostNs: Long): Long {
        if (!syncedFlag) return hostNs + offsetNs
        // 在当前 offset 基础上按漂移率外推到「现在」
        val elapsed = System.nanoTime() - offsetAnchorLocalNs
        val drift = (elapsed / 1_000_000_000.0 * driftNsPerSec).toLong()
        return hostNs + offsetNs + drift
    }

    /** 本地时刻 -> 主机时刻 */
    fun localToHost(localNs: Long): Long {
        if (!syncedFlag) return localNs - offsetNs
        val elapsed = System.nanoTime() - offsetAnchorLocalNs
        val drift = (elapsed / 1_000_000_000.0 * driftNsPerSec).toLong()
        return localNs - offsetNs - drift
    }

    fun reset() {
        samples.clear()
        offsetNs = 0
        driftNsPerSec = 0.0
        offsetAnchorLocalNs = 0
        syncedFlag = false
        lastRttMs = -1
        bestRttNs = Long.MAX_VALUE
        sampleCount = 0
        jitterNs = 0
        syncState = "等待同步"
    }

    /** 收到主机 ping 时调用（提供粗略样本，用于尚未拿到 RTT 时的兜底） */
    fun onIncomingPing(hostSendNs: Long, localRecvNs: Long, localReplyNs: Long) {
        if (!syncedFlag) {
            offsetNs = localRecvNs - hostSendNs
            offsetAnchorLocalNs = localRecvNs
            syncedFlag = true
        }
    }

    /**
     * 收到主机回报的 RTT 时调用，做精确估计。
     *
     * 主机侧测量：
     *   t0 = 主机发出 ping 的主机时刻
     *   t3 = 主机收到 pong 的主机时刻
     *   rtt = t3 - t0 - (从机处理时间)
     *
     * 从机侧已知：
     *   c1 = 从机收到 ping 的本地时刻
     *
     * 单向延迟 ≈ rtt / 2，因此：
     *   主机在 c1 时刻的主机时钟 ≈ t0 + rtt/2
     *   offset = c1 - (t0 + rtt/2)
     */
    fun onRttReported(rttNs: Long, hostSendNs: Long, localRecvNs: Long) {
        if (rttNs <= 0) {
            lastRttMs = rttNs / 1_000_000
            return
        }
        lastRttMs = rttNs / 1_000_000
        if (hostSendNs == 0L || localRecvNs == 0L) {
            updateState()
            return
        }

        val oneWay = rttNs / 2
        val offset = localRecvNs - hostSendNs - oneWay

        sampleCount++
        synchronized(samples) {
            samples.add(Sample(rttNs, offset, localRecvNs))
            if (samples.size > 24) samples.removeAt(0)
            recompute()
        }
    }

    /** 用当前样本集重新估计 offset 与漂移率 */
    private fun recompute() {
        if (samples.isEmpty()) return

        // 1) 只用 RTT 处于最低分位的样本（最优路径，抖动最小）
        val sorted = samples.sortedBy { it.rttNs }
        val keep = maxOf(1, (sorted.size + 2) / 3) // 最低 1/3
        val best = sorted.take(keep)

        if (best.isNotEmpty()) {
            bestRttNs = best.first().rttNs
        }

        // 2) offset 取中位数，抵抗异常样本
        val offsets = best.map { it.offsetNs }.sorted()
        val medianOffset = offsets[offsets.size / 2]

        // 3) 用最小二乘估计漂移率（ppm），只在样本跨度足够时做
        if (samples.size >= 4) {
            val base = samples.first().localNs
            var sumX = 0.0
            var sumY = 0.0
            var sumXY = 0.0
            var sumXX = 0.0
            for (s in samples) {
                val x = ((s.localNs - base) / 1_000_000_000.0) // 秒
                val y = s.offsetNs.toDouble()
                sumX += x
                sumY += y
                sumXY += x * y
                sumXX += x * x
            }
            val n = samples.size.toDouble()
            val denom = n * sumXX - sumX * sumX
            if (kotlin.math.abs(denom) > 1e-6) {
                val slope = (n * sumXY - sumX * sumY) / denom // 纳秒/秒
                // 合理性检查：晶振漂移通常在 ±200ppm 以内（即 ±200000 ns/s）
                if (kotlin.math.abs(slope) < 200_000.0) {
                    driftNsPerSec = slope
                }
            }
        }

        // 4) 计算抖动（RTT 离散度），用于评估同步质量
        jitterNs = if (samples.size >= 2)
            samples.maxOf { it.rttNs } - samples.minOf { it.rttNs }
        else 0L

        val newOffset = if (syncedFlag) {
            // 平滑跟随：每次修正 1/4，避免跳变
            offsetNs + (medianOffset - offsetNs) / 4
        } else {
            medianOffset
        }
        offsetNs = newOffset
        offsetAnchorLocalNs = System.nanoTime()
        syncedFlag = true
        updateState()
    }

    /** 兜底：一个 RTT 样本都没有时，用主机下发的 epoch 做粗对齐 */
    fun onEpochHint(hostEpochNs: Long, localRecvNs: Long) {
        if (syncedFlag && sampleCount > 0) return
        offsetNs = localRecvNs - hostEpochNs
        offsetAnchorLocalNs = localRecvNs
        syncedFlag = true
        updateState()
    }

    private fun updateState() {
        val rtt = if (bestRttNs == Long.MAX_VALUE) lastRttMs else bestRttNs / 1_000_000
        val jitter = jitterNs / 1_000_000
        syncState = when {
            !syncedFlag -> "等待同步"
            rtt < 0 -> "已对齐（无RTT）"
            rtt <= 5 -> "极佳 RTT ${rtt}ms 抖动 ${jitter}ms"
            rtt <= 15 -> "优秀 RTT ${rtt}ms 抖动 ${jitter}ms"
            rtt <= 50 -> "良好 RTT ${rtt}ms 抖动 ${jitter}ms"
            else -> "较差 RTT ${rtt}ms 抖动 ${jitter}ms"
        }
    }
}
