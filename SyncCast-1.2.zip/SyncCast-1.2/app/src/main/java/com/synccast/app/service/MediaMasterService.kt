/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.synccast.app.MainActivity
import com.synccast.app.core.MediaMasterSession
import com.synccast.app.core.MediaSessionBridge

/**
 * 媒体同步主机服务：读取本机网易云/QQ音乐的播放状态并广播给从机。
 * 不录音、不外放。
 */
class MediaMasterService : Service() {

    companion object {
        const val CHANNEL_ID = "synccast_media_master"
        const val NOTIF_ID = 1003
        const val ACTION_STOP = "com.synccast.action.MEDIA_MASTER_STOP"

        /** 启动主机服务（简洁模式用） */
        fun start(ctx: android.content.Context) {
            val i = Intent(ctx, MediaMasterService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }

        /** 停止主机服务 */
        fun stop(ctx: android.content.Context) {
            runCatching {
                ctx.startService(
                    Intent(ctx, MediaMasterService::class.java).setAction(ACTION_STOP)
                )
            }
        }

        private var instance: MediaMasterService? = null
        private var latest: MediaMasterSession.Stats? = null
        private val listeners = mutableListOf<(MediaMasterSession.Stats) -> Unit>()
        private val lock = Any()

        fun addListener(l: (MediaMasterSession.Stats) -> Unit) {
            synchronized(lock) {
                listeners.add(l)
                latest?.let { l(it) }
            }
        }

        fun removeListener(l: (MediaMasterSession.Stats) -> Unit) {
            synchronized(lock) { listeners.remove(l) }
        }

        fun isActive(): Boolean = instance != null

        /** 开关音量统一（主机侧） */
        fun setVolumeSyncEnabled(enabled: Boolean) {
            instance?.session?.setVolumeSyncEnabled(enabled)
        }

        fun isVolumeSyncEnabled(): Boolean =
            instance?.session?.volumeSyncEnabled ?: true

        /** 当前 4 位配对码（未运行时返回 0） */
        fun pairingCode(): Int = instance?.session?.pairingCode ?: 0

        /** 主机本地 IP */
        fun localIp(): String = instance?.session?.localIp ?: "-"

        /** 主机是否作为热点运行 */
        fun isHotspotHost(): Boolean = instance?.session?.isHotspotHost ?: false

        /** 已发现的从机列表（供 UI 显示并一键连接） */
        private val discovered = mutableMapOf<String, com.synccast.app.core.SlavePresenceListener.SlaveInfo>()
        private val discoveredLock = Any()
        private val discoveryListeners = mutableListOf<(List<com.synccast.app.core.SlavePresenceListener.SlaveInfo>) -> Unit>()

        fun addDiscoveryListener(l: (List<com.synccast.app.core.SlavePresenceListener.SlaveInfo>) -> Unit) {
            synchronized(discoveredLock) {
                discoveryListeners.add(l)
                l(discovered.values.toList())
            }
        }

        fun removeDiscoveryListener(l: (List<com.synccast.app.core.SlavePresenceListener.SlaveInfo>) -> Unit) {
            synchronized(discoveredLock) { discoveryListeners.remove(l) }
        }

        private fun onSlaveSeen(info: com.synccast.app.core.SlavePresenceListener.SlaveInfo) {
            val snapshot: List<com.synccast.app.core.SlavePresenceListener.SlaveInfo>
            synchronized(discoveredLock) {
                discovered[info.id] = info
                // 清理 8 秒未报到的
                val now = System.currentTimeMillis()
                discovered.entries.removeAll { now - it.value.lastSeenMs > 8000 }
                snapshot = discovered.values.sortedBy { it.name }
            }
            val ls: List<(List<com.synccast.app.core.SlavePresenceListener.SlaveInfo>) -> Unit>
            synchronized(discoveredLock) { ls = discoveryListeners.toList() }
            for (l in ls) runCatching { l(snapshot) }
        }
    }

    private var session: MediaMasterSession? = null

    /** 从机发现监听器（热点模式下由主机主动发现从机） */
    private var presence: com.synccast.app.core.SlavePresenceListener? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            session?.stop()
            session = null
            presence?.stop()
            presence = null
            synchronized(discoveredLock) { discovered.clear() }
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        // 启动「从机发现」：监听 UDP 报到包
        if (presence == null) {
            presence = com.synccast.app.core.SlavePresenceListener { info ->
                onSlaveSeen(info)
            }.also { it.start() }
        }
        if (session == null) {
            val bridge = MediaSessionBridge(this)
            val s = MediaMasterSession(
                bridge = bridge,
                targetPackage = null, // 自动识别正在播放的音乐 App
                onStats = { st ->
                    synchronized(lock) { latest = st }
                    val snap: List<(MediaMasterSession.Stats) -> Unit>
                    synchronized(lock) { snap = listeners.toList() }
                    for (l in snap) runCatching { l(st) }
                    updateNotification(st)
                },
                onLog = { android.util.Log.i("SyncCast", it) }
            )
            if (!s.start()) {
                stopSelf()
                return START_NOT_STICKY
            }
            s.attachVolume(com.synccast.app.core.VolumeController(this))
            session = s
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(): Boolean = try {
        val n = buildNotification("媒体同步主机", "等待从机连接…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (t: Throwable) {
        android.util.Log.e("SyncCast", "startForeground 失败", t)
        false
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "媒体同步主机", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 3, Intent(this, MediaMasterService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "停止", stop).build())
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(st: MediaMasterSession.Stats) {
        val nm = getSystemService(NotificationManager::class.java)
        val text = if (!st.hasPermission) "缺少通知使用权，无法读取播放状态"
        else "配对码 ${st.pairingCode} · 从机 ${st.clients} 台 · ${if (st.playing) "播放中" else "已暂停"}"
        runCatching { nm.notify(NOTIF_ID, buildNotification("媒体同步主机", text)) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        session?.stop()
        session = null
        presence?.stop()
        presence = null
        instance = null
        synchronized(lock) { latest = null }
        synchronized(discoveredLock) { discovered.clear() }
        super.onDestroy()
    }
}
