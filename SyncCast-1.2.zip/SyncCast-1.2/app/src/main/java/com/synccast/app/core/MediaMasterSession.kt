/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.media.session.MediaController
import android.os.SystemClock
import org.json.JSONObject
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger

/**
 * 媒体同步主机。
 *
 * 不录音、不推音频流，只做一件事：
 *   每 200ms 读取一次网易云/QQ音乐的 MediaSession，
 *   把 {歌曲标识, 播放位置, 播放状态, 时间戳} 广播给所有从机。
 *
 * 从机收到后与自己的音乐 App 对比，必要时 seekTo 对齐。
 * 由于音乐 App 本体在各自设备上播放，音质是原生的，带宽几乎为零。
 */
class MediaMasterSession(
    private val bridge: MediaSessionBridge,
    private val targetPackage: String?,
    private val onStats: (Stats) -> Unit,
    private val onLog: (String) -> Unit
) {
    data class Stats(
        val running: Boolean,
        val clients: Int,
        val songTitle: String,
        val songArtist: String,
        val positionMs: Long,
        val playing: Boolean,
        val localIp: String,
        val hasPermission: Boolean,
        val volumePercent: Int,
        val volumeLevel: String,
        val volumeSyncEnabled: Boolean,
        /** 4 位配对码，供从机输入 */
        val pairingCode: Int,
        /** 是否作为热点主机运行 */
        val hotspotHost: Boolean,
        val error: String?
    )

    /** 音量控制（延迟初始化，避免无 Context 时报错） */
    private var volumeController: VolumeController? = null

    /** 主机当前音量缓存，由监听器实时更新 */
    @Volatile private var currentVolumePercent: Int = -1
    @Volatile private var currentVolumeRaw: Int = -1
    private var stopVolumeObserver: (() -> Unit)? = null

    /** 是否启用音量统一。关闭后不再广播音量包 */
    @Volatile var volumeSyncEnabled: Boolean = true
        private set

    fun attachVolume(vc: VolumeController) {
        volumeController = vc
        // 事件驱动：音量一变就立刻广播，不再等下一轮轮询
        currentVolumePercent = (vc.currentPercent() * 100).toInt()
        currentVolumeRaw = vc.currentVolume()
        stopVolumeObserver = vc.observe { percent, raw ->
            val newPct = (percent * 100).toInt()
            if (newPct == currentVolumePercent && raw == currentVolumeRaw) return@observe
            currentVolumePercent = newPct
            currentVolumeRaw = raw
            // 只在开启音量统一时才广播
            if (!volumeSyncEnabled) return@observe
            onLog("主机音量变化 -> ${newPct}% (${raw}/${vc.maxVolume()})")
            broadcastVolumeNow()
        }
    }

    /** 开关音量统一 */
    fun setVolumeSyncEnabled(enabled: Boolean) {
        if (volumeSyncEnabled == enabled) return
        volumeSyncEnabled = enabled
        // 状态变化立即通知从机
        val json = JSONObject().apply {
            put("t", "volsync")
            put("enabled", enabled)
            put("vol", currentVolumePercent)
            put("hostNs", Timeline.nowNs())
        }.toString()
        val snapshot = synchronized(clients) { clients.toList() }
        for (c in snapshot) {
            runCatching { c.fs?.writeJson(json) }
        }
        onLog("音量统一 -> ${if (enabled) "开启" else "关闭"}")
    }

    /** 立刻广播一次音量包 */
    private fun broadcastVolumeNow() {
        if (!volumeSyncEnabled) return
        val pct = currentVolumePercent
        if (pct < 0) return
        val json = JSONObject().apply {
            put("t", "volume")
            put("vol", pct)
            put("max", volumeController?.maxVolume() ?: -1)
            put("hostNs", Timeline.nowNs())
        }.toString()
        val snapshot = synchronized(clients) { clients.toList() }
        for (c in snapshot) {
            runCatching { c.fs?.writeJson(json) }
        }
    }

    private class Client(
        val clientId: String,
        val name: String,
        /** 从机的 IP，重连时可能变化，所以是 var */
        @Volatile var ip: String
    ) {
        @Volatile var fs: FrameStream? = null
        @Volatile var socket: Socket? = null
        @Volatile var pingSeq: Long = 0
        @Volatile var pingSentAt: Long = 0
        @Volatile var bestRttNs: Long = Long.MAX_VALUE
        /** 最近一次连接建立时间，用于识别陈旧记录 */
        @Volatile var connectedAt: Long = System.currentTimeMillis()
    }

    private val clients = Collections.synchronizedList(mutableListOf<Client>())
    private val idGen = AtomicInteger(1)

    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var broadcastThread: Thread? = null
    private var statsThread: Thread? = null
    @Volatile private var fatalError: String? = null

    val localIp: String = Net.localIpv4()?.address ?: "0.0.0.0"

    /**
     * 4 位配对码。启动时随机生成，映射为控制端口。
     * 用户只需在从机输入这 4 位数字，无需知道 IP。
     */
    @Volatile var pairingCode: Int = Net.randomCode()
        private set

    /** 实际监听的控制端口 */
    @Volatile var controlPort: Int = 0
        private set

    /** 当前是否作为热点主机运行（本地 IP 为网关 .1） */
    val isHotspotHost: Boolean get() = Net.isHotspotHost()

    /** 是否有从机在线（供 UI 判断是否显示「主动连接」） */
    fun isSlaveOnline(): Boolean = clients.isNotEmpty()

    fun start(): Boolean {
        if (running) return true
        running = true
        Thread({ doStart() }, "media-master-start").start()
        return true
    }

    private fun doStart() {
        // 用配对码算出端口；若被占用则顺延重试，最多 30 次
        var attemptCode = pairingCode
        var ok = false
        repeat(30) {
            val port = Net.codeToPort(attemptCode)
            try {
                server = ServerSocket(port).apply { reuseAddress = true }
                pairingCode = attemptCode
                controlPort = port
                ok = true
                return@repeat
            } catch (_: Throwable) {
                attemptCode = if (attemptCode >= Net.CODE_MAX) Net.CODE_MIN else attemptCode + 1
            }
        }
        if (!ok || server == null) {
            fatalError = "端口全部被占用（已尝试 30 个配对码），请稍后重试"
            onLog(fatalError!!)
            running = false
            return
        }
        Thread({ acceptLoop() }, "accept").start()
        broadcastThread = Thread({ broadcastLoop() }, "media-broadcast").apply { start() }
        statsThread = Thread({ statsLoop() }, "stats").apply { start() }
        onLog(
            "媒体同步主机启动 IP=$localIp 配对码=$pairingCode 端口=$controlPort " +
                "热点模式=${if (isHotspotHost) "是" else "否"} 目标=${targetPackage ?: "自动"}"
        )
    }

    private fun acceptLoop() {
        while (running) {
            val sock = try {
                server?.accept()
            } catch (_: Throwable) {
                break
            } ?: break
            Thread({
                try {
                    sock.tcpNoDelay = true
                    sock.soTimeout = 8000
                    val fs = FrameStream.open(sock)
                    val first = fs.readFrame()
                    if (first.type != Proto.MAGIC_TYPE_CONTROL) {
                        sock.close(); return@Thread
                    }
                    val hello = JSONObject(String(first.payload, Charsets.UTF_8))
                    val rawCid = hello.optString("clientId")
                    val cname = hello.optString("name", "从机")
                    val remoteIp = sock.inetAddress.hostAddress ?: "?"
                    sock.soTimeout = 0

                    // ── 校验与去重 ──
                    // 从机可能因为断线重连而重复出现。三层判据：
                    //   1) clientId 相同       → 同一台设备，直接复用旧记录
                    //   2) 名字 + IP 都相同    → 极可能是重连，同样复用
                    //   3) 名字相同但 IP 不同  → 可能换了网络，仍复用以避免堆积
                    // 复用旧记录时，关闭它的旧连接，替换为新的。
                    val existing = synchronized(clients) {
                        clients.firstOrNull { it.clientId == rawCid && rawCid.isNotBlank() }
                            ?: clients.firstOrNull { it.name == cname && it.ip == remoteIp }
                            ?: clients.firstOrNull { it.name == cname }
                    }

                    val c: Client = if (existing != null) {
                        onLog("从机重连，复用记录：$cname (${existing.ip} → $remoteIp)")
                        // 关掉旧连接，避免僵尸连接
                        runCatching { existing.socket?.close() }
                        existing.socket = sock
                        existing.fs = fs
                        existing.ip = remoteIp
                        existing
                    } else {
                        val cid = rawCid.ifBlank { "c${idGen.getAndIncrement()}" }
                        Client(cid, cname, remoteIp).also {
                            clients.add(it)
                            onLog("新从机接入：$cname ($remoteIp)")
                        }
                    }
                    c.fs = fs
                    c.socket = sock
                    c.connectedAt = System.currentTimeMillis()
                    // 立即发一次完整状态
                    pushMediaState(c)
                    // 立即告知从机当前音量统一开关状态
                    runCatching {
                        c.fs?.writeJson(
                            JSONObject().apply {
                                put("t", "volsync")
                                put("enabled", volumeSyncEnabled)
                                put("vol", currentVolumePercent)
                                put("hostNs", Timeline.nowNs())
                            }.toString()
                        )
                    }
                    // 读 pong
                    while (running) {
                        val f = fs.readFrame()
                        if (f.type != Proto.MAGIC_TYPE_CONTROL) continue
                        val o = JSONObject(String(f.payload, Charsets.UTF_8))
                        if (o.optString("t") == "pong") {
                            val now = Timeline.nowNs()
                            if (o.optLong("seq") == c.pingSeq) {
                                val rtt = now - c.pingSentAt
                                if (rtt > 0) {
                                    if (rtt < c.bestRttNs) c.bestRttNs = rtt
                                    runCatching {
                                        fs.writeJson(Msg.clock(rtt, o.optLong("t0"), o.optLong("c1")))
                                    }
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {
                } finally {
                    clients.removeAll { it.socket === sock }
                    try { sock.close() } catch (_: Throwable) { }
                }
            }, "client").start()
        }
    }

    private fun broadcastLoop() {
        var seq = 0L
        while (running) {
            seq++
            val snap = try {
                bridge.currentSnapshot(targetPackage)
            } catch (_: Throwable) {
                null
            }
            val snapshot = synchronized(clients) { clients.toList() }
            if (snap != null) {
                val volPercent = volumeController?.currentPercent() ?: -1f
                val json = JSONObject().apply {
                    put("t", "media")
                    put("title", snap.title)
                    put("artist", snap.artist)
                    put("album", snap.album)
                    put("pkg", snap.packageName)
                    put("pos", snap.positionNowMs())
                    put("playing", snap.playing)
                    put("speed", snap.speed.toDouble())
                    put("hostNs", Timeline.nowNs())
                    put("seekable", bridge.supportsSeek(snap))
                    // 原始快照（未外推），供从机做更精细的推算与校验
                    put("rawPos", snap.positionMs)
                    put("rawUpdatedMs", snap.updatedElapsedMs)
                    if (volPercent >= 0f) put("vol", (volPercent * 100).toInt())
                }.toString()
                for (c in snapshot) {
                    runCatching { c.fs?.writeJson(json) }
                }
            }
            // 时钟同步：提高到每 500ms 一次（每 5 个 tick，tick=100ms）
            if (seq % 5 == 0L) {
                val t = Timeline.nowNs()
                for (c in snapshot) {
                    runCatching {
                        c.pingSeq++
                        c.pingSentAt = t
                        c.fs?.writeJson(Msg.ping(c.pingSeq, t))
                    }
                }
            }
            try { Thread.sleep(100) } catch (_: InterruptedException) { return }
        }
    }

    private fun pushMediaState(c: Client) {
        val snap = bridge.currentSnapshot(targetPackage) ?: return
        val volPercent = volumeController?.currentPercent() ?: -1f
        runCatching {
            c.fs?.writeJson(
                JSONObject().apply {
                    put("t", "media")
                    put("title", snap.title)
                    put("artist", snap.artist)
                    put("album", snap.album)
                    put("pkg", snap.packageName)
                    put("pos", snap.positionNowMs())
                    put("playing", snap.playing)
                    put("speed", snap.speed.toDouble())
                    put("hostNs", Timeline.nowNs())
                    put("seekable", bridge.supportsSeek(snap))
                    if (volPercent >= 0f) put("vol", (volPercent * 100).toInt())
                }.toString()
            )
        }
    }

    private fun statsLoop() {
        while (running) {
            // 清理断开的连接：socket 已关闭的从机不再计入
            pruneDeadClients()

            val snap = runCatching { bridge.currentSnapshot(targetPackage) }.getOrNull()
            val vc = volumeController
            onStats(
                Stats(
                    running = running,
                    clients = clients.size,
                    songTitle = snap?.title ?: "（未检测到播放）",
                    songArtist = snap?.artist ?: "",
                    positionMs = snap?.positionNowMs() ?: 0,
                    playing = snap?.playing ?: false,
                    localIp = localIp,
                    hasPermission = bridge.hasPermission(),
                    volumePercent = ((vc?.currentPercent() ?: 0f) * 100).toInt(),
                    volumeLevel = if (vc != null) "${vc.currentVolume()}/${vc.maxVolume()}" else "-",
                    volumeSyncEnabled = volumeSyncEnabled,
                    pairingCode = pairingCode,
                    hotspotHost = isHotspotHost,
                    error = fatalError
                )
            )
            try { Thread.sleep(400) } catch (_: InterruptedException) { return }
        }
    }

    /**
     * 清理已断开的从机记录。
     *
     * socket 被关闭或连接已断（isClosed / !isConnected）的，
     * 从列表中移除，避免「已断开的从机仍显示在线」。
     */
    private fun pruneDeadClients() {
        val dead: List<Client>
        synchronized(clients) {
            dead = clients.filter { c ->
                val s = c.socket
                s == null || s.isClosed || !s.isConnected
            }
            if (dead.isNotEmpty()) {
                clients.removeAll(dead)
            }
        }
        for (c in dead) {
            onLog("清理断开的从机：${c.name} (${c.ip})")
        }
    }

    /** 主机本地调音量 */
    fun setVolumePercent(percent: Float): Boolean {
        return volumeController?.setPercent(percent) ?: false
    }

    fun stop() {
        running = false
        stopVolumeObserver?.invoke()
        stopVolumeObserver = null
        broadcastThread?.interrupt()
        statsThread?.interrupt()
        broadcastThread = null
        statsThread = null
        synchronized(clients) {
            for (c in clients) {
                try { c.socket?.close() } catch (_: Throwable) { }
            }
            clients.clear()
        }
        try { server?.close() } catch (_: Throwable) { }
        server = null
    }

    fun clientCount(): Int = clients.size
}
