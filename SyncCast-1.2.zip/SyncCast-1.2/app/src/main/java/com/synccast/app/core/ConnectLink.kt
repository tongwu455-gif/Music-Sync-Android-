/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * 连接链接（Deep Link）。
 *
 * 主机生成：
 *     synccast://connect?code=7429&host=10.174.67.202
 *
 * 从机点击后：
 *     系统识别 synccast:// 协议 → 打开 SyncCast
 *     → MainActivity 解析 code 与 host
 *     → 自动建立连接，用户无需输入任何内容
 *
 * 相比「配对码 + 猜测网段」，这个方案把主机 IP 直接写进链接，
 * 从机不需要猜，可靠性高得多。
 */
object ConnectLink {

    const val SCHEME = "synccast"
    const val HOST_PART = "connect"

    data class Payload(
        /** 4 位配对码 */
        val code: Int,
        /** 主机 IP（可能为空，为空时走网段扫描兜底） */
        val host: String
    )

    /** 生成连接链接 */
    fun build(code: Int, hostIp: String): String {
        val h = if (hostIp.isBlank() || hostIp == "0.0.0.0") "" else hostIp
        return "$SCHEME://$HOST_PART?code=$code&host=$h"
    }

    /**
     * 从 Intent 解析连接参数。
     * 返回 null 表示这个 Intent 不是连接链接。
     */
    fun parse(intent: Intent?): Payload? {
        val data: Uri = intent?.data ?: return null
        // 同时支持 synccast://connect 与 https://synccast.local/connect
        val okScheme = data.scheme == SCHEME ||
            (data.scheme == "https" && data.host == "synccast.local")
        if (!okScheme) return null

        val codeStr = data.getQueryParameter("code") ?: return null
        val code = codeStr.toIntOrNull() ?: return null
        if (!Net.isValidCode(code)) return null
        val host = data.getQueryParameter("host") ?: ""
        return Payload(code, host)
    }

    /** 供其他 App / 浏览器调起的 Intent */
    fun toIntent(ctx: Context, code: Int, hostIp: String): Intent {
        return Intent(Intent.ACTION_VIEW, Uri.parse(build(code, hostIp))).apply {
            setPackage(ctx.packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
