/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.core

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState

/**
 * 通过标准 MediaSession API 读写第三方音乐 App（网易云/QQ音乐）的播放状态。
 *
 * 关键点：
 *  - 需要用户在「设置 → 通知使用权」里授权本应用（NotificationListenerService 的标准入口）
 *  - 授权后 MediaSessionManager.getActiveSessions() 能拿到所有活跃会话
 *  - PlaybackState.position 是精确毫秒，配合 updated 时间戳可推算当前实时位置
 *  - TransportControls.seekTo() 可让音乐 App 跳到指定毫秒
 */
class MediaSessionBridge(private val ctx: Context) {

    data class Snapshot(
        val packageName: String,
        val title: String,
        val artist: String,
        val album: String,
        /** 播放位置（毫秒），0 表示未知 */
        val positionMs: Long,
        val playing: Boolean,
        val speed: Float,
        /** 该 position 对应的系统时刻（elapsedRealtime 毫秒） */
        val updatedElapsedMs: Long,
        /** 会话可用的动作位 */
        val actions: Long
    ) {
        val songKey: String get() = "$title|$artist"

        /** 按速度推算到「现在」的实时位置 */
        fun positionNowMs(): Long {
            if (!playing) return positionMs
            val delta = android.os.SystemClock.elapsedRealtime() - updatedElapsedMs
            return positionMs + (delta * speed).toLong()
        }
    }

    private val sessionManager: MediaSessionManager? =
        ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager

    /** 是否已获得通知使用权（MediaSession 访问前提） */
    fun hasPermission(): Boolean {
        val sm = sessionManager ?: return false
        return try {
            sm.getActiveSessions(ComponentName(ctx, MediaNotificationListener::class.java))
            true
        } catch (_: SecurityException) {
            false
        } catch (_: Throwable) {
            false
        }
    }

    /** 当前活跃会话的控制器列表 */
    fun activeControllers(): List<MediaController> {
        val sm = sessionManager ?: return emptyList()
        return try {
            sm.getActiveSessions(ComponentName(ctx, MediaNotificationListener::class.java))
        } catch (_: Throwable) {
            emptyList()
        }
    }

    /**
     * 找到指定包名的会话；传 null 则返回最可能是「正在播放音乐」的那个。
     */
    fun findController(packageName: String? = null): MediaController? {
        val list = activeControllers()
        if (list.isEmpty()) return null
        if (packageName != null) {
            list.firstOrNull { it.packageName == packageName }?.let { return it }
        }
        // 优先返回正在播放的
        list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }?.let { return it }
        // 其次返回有音乐元数据的
        list.firstOrNull { it.metadata != null }?.let { return it }
        return list.firstOrNull()
    }

    fun snapshot(controller: MediaController): Snapshot? {
        val st = controller.playbackState ?: return null
        val md: MediaMetadata? = controller.metadata
        val updated = if (st.lastPositionUpdateTime > 0) st.lastPositionUpdateTime
        else android.os.SystemClock.elapsedRealtime()
        return Snapshot(
            packageName = controller.packageName,
            title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
            artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "",
            album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: "",
            positionMs = st.position.coerceAtLeast(0),
            playing = st.state == PlaybackState.STATE_PLAYING,
            speed = if (st.playbackSpeed > 0f) st.playbackSpeed else 1f,
            updatedElapsedMs = updated,
            actions = st.actions
        )
    }

    /** 当前播放快照（自动挑选合适的会话） */
    fun currentSnapshot(packageName: String? = null): Snapshot? {
        val c = findController(packageName) ?: return null
        return snapshot(c)
    }

    /** 跳转到指定毫秒 */
    fun seekTo(controller: MediaController, positionMs: Long): Boolean {
        return try {
            controller.transportControls.seekTo(positionMs.coerceAtLeast(0))
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** 播放 / 暂停 */
    fun setPlaying(controller: MediaController, play: Boolean): Boolean {
        return try {
            if (play) controller.transportControls.play()
            else controller.transportControls.pause()
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** 会话是否支持 seek */
    fun supportsSeek(s: Snapshot): Boolean =
        (s.actions and PlaybackState.ACTION_SEEK_TO) != 0L
}
