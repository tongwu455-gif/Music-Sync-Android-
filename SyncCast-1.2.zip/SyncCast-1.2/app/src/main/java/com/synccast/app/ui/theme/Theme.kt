/*
 * SyncCast - 多设备音乐同步播放
 * Copyright (C) 2026 高子谦
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.synccast.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Purple = Color(0xFF6C5CE7)
private val Teal = Color(0xFF00B894)
private val Ink = Color(0xFF12121A)

private val Light = lightColorScheme(
    primary = Purple,
    secondary = Teal,
    background = Color(0xFFF7F7FB),
    surface = Color.White
)

private val Dark = darkColorScheme(
    primary = Purple,
    secondary = Teal,
    background = Ink,
    surface = Color(0xFF1C1C26)
)

@Composable
fun SyncCastTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content
    )
}
