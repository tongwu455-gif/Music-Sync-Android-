# SyncCast 1.2 · 多设备音乐同步播放

> 让多台 Android 手机同步播放同一个音乐 App（网易云 / QQ 音乐）里的同一首歌。

**最终版本**：`0.7.3-modeback`
**构建日期**：2026-11-12
**目标设备**：Android 8.0+（minSdk 26）
**许可证**：[AGPL-3.0](LICENSE) © 2026 高子谦

---

## 一、项目目标与演进

### 最初需求

> "我有时候会想用好几个手机同时放同一首歌"

关键约束：**必须用网易云 / QQ 音乐这类在线音乐 App，不是本地文件播放。**

### 方案经历了三次重构

#### 阶段 1：麦克风拾音 + 局域网推流（v0.1.x）

```
主机外放网易云 → 麦克风拾音 → 48kHz PCM 分块 → TCP 广播 → 从机播放
```

**放弃原因**：

1. 实测发现从机连接即闪退（`NetworkOnMainThreadException`）——已修复
2. 修完后连上了但没声音：诊断数据显示 `recvPackets=2202`（收包正常）但 `writtenMs=0`，
   时钟偏移算成了 **725433436ms（8.4 天）**，所有音频包被判"过期"丢弃
3. 即使修好时钟，还有音质损失、啸叫、延迟累积等根本问题

#### 阶段 2：MediaSession 状态同步（v0.2.0+，最终采用）

转折点来自一次 adb 探测：

```
state=PlaybackState {position=64250, speed=1.0, actions=822}
actions=822 = 0x336 → ACTION_SEEK_TO ✅
```

**思路彻底改变**：不再录音，改为**每台手机各自播放网易云，只同步播放进度**。

| 维度 | 麦克风方案 | MediaSession 方案 |
|---|---|---|
| 音质 | 损失（二次录音） | **原生音质** |
| 带宽 | ~768 kbps | ~1 kbps |
| 延迟 | 数百 ms | 20~50 ms |
| 设备数 | 受主机 CPU 限制 | 基本无限制 |

#### 阶段 3：热点 + 配对码 + 双模式 UI（v0.4.x ~ v0.7.x）

在外出场景下（无 Wi-Fi、无电脑），需要手机自己当热点。这一阶段解决了连接可靠性与可用性。

---

## 二、核心技术约束（实测结论）

这一节是整个项目最重要的部分——**以下都是我通过 adb 实测确认的硬限制**，不是推测。

### 约束 1：网易云不支持播放速度调节

```
actions = 822 (0x336)
  ACTION_PLAY         (0x1)      ❌ 不支持
  ACTION_PAUSE        (0x2)      ✅
  ACTION_SEEK_TO      (0x100)    ✅
  ACTION_PLAY_PAUSE   (0x200)    ✅
  ACTION_SET_SPEED    (0x2000)   ❌ 不支持
  ACTION_SET_RATE     (0x400000) ❌ 不支持
```

**影响**：无法通过"临时加速 2% 慢慢追平"来消除偏差。这是消除卡顿的最佳方案，
但网易云没提供接口。**每一次修正只能靠 seek，而 seek 必然产生音频中断。**

### 约束 2：播放开始后 PlaybackState 不再刷新

```
播放中 3 秒内采样 10 次：
position = 119549    始终不变
updated  = 770708076 始终不变
```

**影响**：位置只能靠 `speed = 1.0` 线性外推。这意味着：

- **无法验证 seek 是否真的生效**（因为位置不刷新）
- 绝对精度受限于外推误差

### 约束 3：无法自动切歌

```
actions 不含 SKIP_TO_NEXT / SKIP_TO_PREVIOUS
queueTitle = null，size = 0
```

**影响**：切歌必须手动。从机检测到歌曲不一致时，只能提示用户，不能自动切换。

### 约束 4：热点网关 IP 不可预测

实测数据：

```
iQOO 开热点：   ap0     10.174.67.202/24   ← 网关是 .202，不是 .1
三星连热点：   wlan0   10.174.67.240/24
Windows 热点：          192.168.137.1
多数国产 ROM：          192.168.43.1
```

且热点网段**没有默认网关条目**（主机自己就是网关）：

```
路由表：ap0  0043AE0A  00000000   ← Gateway 是 0
```

**影响**：不能用硬编码 IP 列表，也不能读路由表。必须靠"本机网段穷举扫描"。

### 约束 5：自定义 URL scheme 会被部分 App 拦截

微信等 App 对 `synccast://` 这类自定义协议有拦截，用户点击可能无反应。

---

## 三、系统架构

```
┌─────────────────────────────────────────────────┐
│                    主机 (Master)                 │
│                                                 │
│  ┌──────────────────────────────────────────┐   │
│  │ MediaNotificationListener                │   │
│  │  「通知使用权」→ 拿到 MediaSessionManager │   │
│  └───────────────┬──────────────────────────┘   │
│                  ↓                               │
│  ┌──────────────────────────────────────────┐   │
│  │ MediaMasterSession                       │   │
│  │  · 读取网易云播放状态（每 200ms 广播）    │   │
│  │  · 提供 ping/pong 时钟基准               │   │
│  │  · ServerSocket 监听配对码映射的端口     │   │
│  └───────────────┬──────────────────────────┘   │
│                  ↓ TCP                           │
└──────────────────┼──────────────────────────────┘
                   │
        ┌──────────┴──────────┐
        ↓                     ↓
┌───────────────┐     ┌───────────────┐
│  从机 A        │     │  从机 B        │
│               │     │               │
│ MediaClient   │     │ MediaClient   │
│ Session       │     │ Session       │
│  · 时钟同步    │     │  · 时钟同步    │
│  · 偏差计算    │     │  · 偏差计算    │
│  · seekTo 对齐 │     │  · seekTo 对齐 │
└───────────────┘     └───────────────┘
```

### 关键文件职责

| 文件 | 职责 | 关键程度 |
|---|---|---|
| `core/MediaSessionBridge.kt` | MediaSession 读写封装 | ⭐⭐⭐ |
| `core/MediaMasterSession.kt` | 主机：广播状态、接受连接、去重 | ⭐⭐⭐ |
| `core/MediaClientSession.kt` | 从机：时钟同步、偏差计算、对齐决策 | ⭐⭐⭐ |
| `core/ClockSync.kt` | 时钟偏移与漂移率估计 | ⭐⭐⭐ |
| `core/Net.kt` | 配对码映射、网段扫描、UDP 发现 | ⭐⭐ |
| `core/DeviceId.kt` | 设备持久化 ID（防重复） | ⭐⭐ |
| `core/VolumeController.kt` | 音量百分比同步 | ⭐⭐ |
| `ui/SimpleScreens.kt` | 简洁模式界面 | ⭐ |
| `ui/MediaSyncScreens.kt` | 专业模式界面 | ⭐ |

---

## 四、关键算法

### 4.1 时钟同步

```kotlin
// 每一轮 ping/pong：
offset = c1 - t0 - RTT / 2

// 反问题：主机时刻 H 对应本地时刻 L
L = H + offset
```

**抗抖动措施**（`ClockSync.kt`）：

1. **24 个样本滑窗**：保留最近 24 次测量
2. **只取 RTT 最低的 1/3**：网络抖动大的样本被剔除
3. **中位数**：抗单次异常值
4. **最小二乘拟合漂移率**（ppm 级）：修正两台设备晶振频率差异
5. **平滑跟随 1/4**：避免 offset 突变导致跳变

### 4.2 偏差计算与对齐

```kotlin
// 主机的"此刻位置"：快照 + 线性外推
fun hostPositionNowMs(): Long {
    val ageMs = localNowMs() - hostSnapshotLocalMs
    return hostRawPos + (ageMs * hostSpeed).toLong()
}

// 从机偏差
val diff = localPos - hostPos      // 负=落后，正=超前
```

**决策流程**（`MediaClientSession.doAlign()`）：

```
每 2 秒检测一次（检测本身不产生中断）
        ↓
用最近 3 次偏差的中位数 → smoothDiff（抗噪声）
        ↓
┌───────────────────────┴────────────────────────┐
│ |smoothDiff| ≤ 20ms                            │ → 不动（人耳无感）
└───────────────────────┬────────────────────────┘
                        ↓
          连续 3 次超标？(迟滞，防误判)
                  否 → 继续等
                  是 ↓
┌───────────────────────┴────────────────────────┐
│ |smoothDiff| ≥ 500ms（严重失步）                 │ → 立即 seek，不走预算
└───────────────────────┬────────────────────────┘
                        ↓
              1 分钟预算内还有余额？
                  否 → 只提示，不对齐
                  是 ↓
              seekTo(hostPos)
```

### 4.3 参数演进记录

| 版本 | 检测周期 | 阈值 | 最小间隔 | 预算 | 结果 |
|---|---|---|---|---|---|
| 0.3.0 | 3s | 15ms | 2.5s | 无 | seek 太频繁，卡顿多 |
| 0.4.2 | 5s | 20ms | 8s | 无 | 卡顿缓解 |
| 0.5.0 | 2s | 20ms | 5s | 5分钟/2次 | **5分钟≤2次卡顿** ✅ |
| **0.7.3** | 2s | 20ms | 5s | **1分钟/1次** | 响应更快，5分钟最多5次 |

**取舍说明**：预算窗口从 5 分钟缩到 1 分钟时，如果把次数也保持 2 次，
5 分钟内最多会 seek 10 次（卡顿翻 5 倍）。所以配成 **1分钟/1次**，
折合 5 分钟最多 5 次，是在"响应速度"与"卡顿次数"之间的折中。

### 4.4 音量同步

**必须先测音量档位范围**——不同机型差异巨大：

```
iQOO Neo9 Pro：0 ~ 150 档
三星 SM-F731U：0 ~ 15 档
```

**方案**：按**百分比**同步，而非绝对档位。

```kotlin
// 主机端：event-driven，音量一变立刻广播
volumeController.observe { percent, raw ->
    broadcastVolumeNow()
}

// 从机端：单向跟随，绝不写回主机
setVolumePercent(hostPercent)
readBackAndVerify()          // 回读校验
```

**踩坑记录**：早期用了 `FLAG_SHOW_UI`，导致从机弹出音量条并锁死音量；
主从互相写回也造成"打架"。现已在 `VolumeController.kt` 中彻底移除。

---

## 五、连接方案演进

### 5.1 配对码（当前方案）

```
主机启动 → 随机生成 4 位码 7429
        → 内部端口 = 52000 + (7429 - 1000) = 56429
        → 屏幕 56sp 大字显示
                ↓
从机输入 7429 → 穷举本机网段 254 个地址
              → 32 线程并行探测，250ms 超时
              → 第一个连上 56429 端口的就是主机
```

**为什么用配对码而不是 IP**：Android 热点网关 IP 由系统固定分配，
应用层改不了。把 4 位码映射到端口，用户完全不用碰 IP。

### 5.2 Deep Link（0.6.0 实验，未保留在主流程）

```
synccast://connect?code=7429&host=10.174.67.202
```

主机点「分享连接链接」→ 通过微信发送 → 从机点开自动连接。

**优点**：主机 IP 直接写在链接里，从机不用猜。
**缺点**：微信等 App 会拦截自定义 scheme，点击可能无反应。

### 5.3 从机去重（重要修复）

**问题现象**：从机每次重连，主机列表里就多一台同名设备。

**根因**：

```kotlin
// 修复前：每次连接都生成全新随机 ID
put("clientId", "mc-" + Net.randomId())
```

**修复**：改用 Android ID（SSAID）持久化：

```kotlin
// DeviceId.kt
"dev-" + Settings.Secure.getString(cr, ANDROID_ID).take(12)
```

**主机端三重复合去重**：

```kotlin
val existing = clients.firstOrNull { it.clientId == rawCid }        // ① ID 相同
    ?: clients.firstOrNull { it.name == cname && it.ip == remoteIp } // ② 名字+IP
    ?: clients.firstOrNull { it.name == cname }                      // ③ 名字
// 命中就复用旧记录，不从列表新增
```

---

## 六、界面设计：双模式

### 简洁模式（默认）

目标用户：只想赶紧放歌的人。**一屏只回答一个问题："现在该做什么"**。

```
┌────────────────────────┐
│ SyncCast      专业模式 │
├────────────────────────┤
│  首页  │  主机  │ 从机 │
├────────────────────────┤
│                        │
│   多台手机             │
│   同步播放同一首歌     │
│                        │
│   这台手机要做什么？   │
│                        │
│  ┌──────────────────┐  │
│  │    我是主机      │  │  ← 112dp 高
│  │ 这台放音乐，其他…│  │
│  └──────────────────┘  │
│                        │
│  ┌──────────────────┐  │
│  │    我是从机      │  │
│  │ 输配对码，跟着…  │  │
│  └──────────────────┘  │
└────────────────────────┘
```

主机运行后：
```
┌──────────────────┐
│     配对码       │
│                  │
│   7  4  2  9     │  ← 56sp
│                  │
│ 让其他手机输这4位│
└──────────────────┘

● 已连接 1 台手机       ← 绿点
  可以开始播放音乐了

正在播放
晴天 - 周杰伦

[   停止同步   ]
```

从机未连接：
```
输入主机屏幕上的
4 位配对码
先连上主机的热点，再输入

┌──────────────────┐
│    7 4 2 9       │  ← 44sp 等宽
└──────────────────┘

[      连接      ]      ← 60dp 高
```

### 专业模式

保留全部技术指标：

```
位置差值（原始）    18 ms
位置差值（平滑）    16 ms
同步状态          ✅ 已同步（阈值 20ms 内）
已对齐次数         1
本周期预算         1 / 1 次（每1分钟）
时钟偏移            23 ms
时钟抖动            4 ms
媒体音量           65%  (98/150)
```

### 关键设计决策

**简洁模式不是功能阉割版**——两种模式连同一套服务、同一套算法，
只是信息密度不同。模式选择持久化到 SharedPreferences。

---

## 七、踩坑记录（按严重程度）

| # | 问题 | 根因 | 修复 |
|---|---|---|---|
| 1 | **App 打开即闪退** | Composable 里用 `return@Column` 提前返回，破坏 Compose 组栈 | 改为 if/else 嵌套分支，全项目禁用提前返回 |
| 2 | 从机连不上主机 | 热点网关是 `10.174.67.202`，硬编码列表只有 `192.168.43.1` 等 | 改为穷举本机网段 254 个地址，并行探测 |
| 3 | 从机列表无限增长 | 每次连接生成随机 clientId | Android ID 持久化 + 三重去重 |
| 4 | 音量同步需滑动屏幕才生效 | 只在 Android 确认音量后触发 | 改 event-driven 监听 |
| 5 | 主从音量互相覆盖 | 从机把音量写回主机 | 从机单向跟随，绝不写回 |
| 6 | 音量条锁死无法调节 | 用了 `FLAG_SHOW_UI` | 移除该 flag |
| 7 | 音量统一开关点击无反应 | Switch 绑定的是只在收到主机回调才更新的值 | 改用独立本地状态 |
| 8 | 主机 IP 显示错误 | 取 IP 时按遍历顺序，拿到移动数据网卡 `ccmni4` | 增加网卡黑名单，优先 `ap0`/`wlan0` |
| 9 | 时钟偏移算成 8.4 天 | offset 方向搞反 | 重写 `ClockSync` |
| 10 | 连接到从机即闪退（历史） | `Socket.connect()` 在主线程执行 | 移到后台线程 |

### ⚠️ Compose 开发铁律

**所有 @Composable 函数禁止使用 `return` / `return@Scope` 提前返回。**

```kotlin
// ❌ 错误：会破坏组栈，导致 IndexOutOfBoundsException
@Composable
fun Foo(flag: Boolean) {
    Column {
        if (!flag) {
            Text("提示")
            return@Column        // 跳过 endGroup()，栈失衡
        }
        Text("正常")
    }
}

// ✅ 正确：完整分支
@Composable
fun Foo(flag: Boolean) {
    Column {
        if (!flag) {
            Text("提示")
        } else {
            Text("正常")
        }
    }
}
```

崩溃堆栈特征：

```
java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
    at androidx.compose.runtime.Stack.pop(Stack.kt:26)
    at androidx.compose.runtime.ComposerImpl.exitGroup(Composer.kt:2333)
    at androidx.compose.runtime.ComposerImpl.endRoot(Composer.kt:1483)
```

---

## 八、构建说明

### 环境要求

| 组件 | 版本 |
|---|---|
| JDK | 17.0.13 |
| Gradle | 8.7 |
| AGP | 8.3.2 |
| Kotlin | 1.9.23 |
| compileSdk | 34 |
| minSdk | 26 |
| targetSdk | 34 |

### 构建命令

```bash
cd sync-cast源码
./gradlew assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

### 注意：工程路径不能含中文

Gradle 对非 ASCII 路径会报：
```
Your project path contains non-ASCII characters
```

`gradle.properties` 里已加：
```properties
android.overridePathCheck=true
```

### 本地配置

需要自己创建 `local.properties`（未打包，含本机 SDK 路径）：

```properties
sdk.dir=C\:\\path\\to\\android-sdk
```

---

## 九、使用流程

### 场景：2~3 台手机同步放歌

```
1. 主机：系统设置 → 个人热点 → 打开
2. 主机：打开 SyncCast → 「我是主机」→ 开始同步
        → 屏幕显示 4 位配对码（如 7429）
3. 从机：连接主机的 Wi-Fi 热点
4. 从机：打开 SyncCast → 「我是从机」→ 输入 7429 → 连接
5. 主机：打开网易云，播放任意歌曲
6. 从机：打开网易云，手动播放同一首歌
        → 之后自动跟随进度
```

### 首次使用必做

**授予「通知使用权」**——这是读取 MediaSession 的唯一途径：

```
设置 → 应用 → 特殊权限 → 通知使用权 → 勾选 SyncCast
```

App 内点在提示卡的「去开启」按钮会直接跳转。

### 已知限制

- ❌ 不能自动切歌（网易云无 SKIP_TO_NEXT）
- ❌ 从机切歌需手动（提示会显示歌名）
- ❌ 部分 ROM 的热点开启"设备隔离"会导致连不上
- ⚠️ 对齐精度受 seek 中断限制，无法做到"零卡顿 + 零误差"

---

## 十、目录结构

```
SyncCast1.2/
├── README.md                       本文档
├── apk/
│   └── SyncCast-0.7.3-modeback.apk 可直接安装
├── docs/
│   └── (补充文档)
└── sync-cast源码/                  完整可构建工程
    ├── build.gradle.kts
    ├── settings.gradle.kts
    ├── gradle.properties
    ├── gradlew / gradlew.bat
    ├── gradle/wrapper/
    └── app/
        ├── build.gradle.kts
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/com/synccast/app/
            │   ├── MainActivity.kt
            │   ├── SyncCastApp.kt
            │   ├── core/          核心算法
            │   ├── service/       前台服务
            │   ├── ui/            界面
            │   └── util/
            └── res/
```

---

## 十一、后续可做的方向

### 优先级高

1. **降低卡顿频率**
   当前 1分钟/1次的预算是折中值。可尝试：
   - 自适应：偏差小时用 1 分钟窗口，偏差大时才扩展
   - 测量 Seek 实际生效时间，用于更好的预补偿

2. **连接可靠性**
   - 二维码扫码（绕过 scheme 拦截）
   - 热点 AP 隔离检测与提示

### 优先级中

3. **多从机压力测试**
   当前只测过 1 主机 + 1 从机，未验证 3 台以上

4. **断线自动重连**
   当前断网后需手动重连

### 技术探索

5. **换播放器**
   如果换成支持 `setPlaybackSpeed` 的播放器（部分播客/B站类），
   就能用"变速追赶"实现**零中断 + 高精度**，彻底解决核心矛盾。

6. **A2DP 多广播**
   Android 14+ 有 `BluetoothLeAudio` 广播能力，但需要硬件支持，
   且延迟比局域网方案大。

---

## 附：版本历史

| 版本 | 关键变化 |
|---|---|
| 0.1.0 | 麦克风方案 MVP |
| 0.1.1 | 修主线程网络崩溃 |
| 0.1.2 | 修 startForeground 异常 |
| **0.2.0** | **切换到 MediaSession 方案**，删除全部麦克风代码 |
| 0.2.1 | 音量按百分比同步 |
| 0.3.0 | 时钟同步升级、3 秒对齐周期 |
| 0.3.1 | 音量事件驱动 |
| 0.3.2 | 音量统一开关 |
| 0.4.0 | 热点 + 4 位配对码 |
| 0.4.1 | 网段动态推断（修复网关 IP 不可预测） |
| 0.4.2 | 对齐阈值 15→20ms |
| 0.4.3 | 设备 ID 持久化 + 三重去重 |
| 0.5.0 | 预算 + 迟滞机制（5分钟≤2次卡顿） |
| 0.6.0 | Deep Link 实验（未保留主流程） |
| 0.7.0 | 双模式界面 |
| 0.7.1 | 预算窗口 5分钟→1分钟 |
| 0.7.2 | **修复 Compose 组栈崩溃** |
| **0.7.3** | **模式双向切换（当前版本）** |

---

## 许可证

```
Copyright (C) 2026 高子谦

SyncCast 是自由软件：你可以依据自由软件基金会发布的
GNU Affero 通用公共许可证（第 3 版或你选择的任何更新版本）的条款
重新分发和/或修改它。

本程序基于「希望它有用」的目的分发，但没有任何担保，
甚至没有适销性或特定用途适用性的默示担保。
详见 GNU Affero 通用公共许可证。

你应当已随本程序收到 GNU Affero 通用公共许可证的副本。
如果没有，请访问 https://www.gnu.org/licenses/
```

完整许可证文本见项目根目录的 [LICENSE](LICENSE) 文件。

### 关于 AGPL-3.0 的说明

本项目采用 **AGPL-3.0**（GNU Affero General Public License v3.0），
而非更常见的 GPL 或 MIT。这是一个有意的选择：

**AGPL 与 GPL 的区别**：普通 GPL 只在「分发软件」时要求开源；
AGPL 额外规定，**即使不分发、仅通过网络提供服务，也必须开源**（第 13 条）。

**对本项目意味着什么**：

| 你的行为 | 需要做什么 |
|---|---|
| 自己用，不分发 | 无需任何操作 |
| 修改后分发 APK 给别人 | 必须公开完整源码 |
| 基于本项目搭建网络服务 | 必须公开完整源码 |
| 引用本项目的部分代码到自己的项目 | 你的项目也需要采用 AGPL（传染性） |

**如果你只想自由使用、不想被约束**，可以考虑使用 [MIT](https://opensource.org/licenses/MIT)
或 [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0)。

**如果你在意「别人拿我的代码做成闭源商业版」**，AGPL 是合适的防线。

### 第三方组件

本项目仅使用 Android 官方 SDK 与 Jetpack Compose，
未引入任何 AGPL 不兼容的第三方库。

构建工具链（JDK 17、Gradle 8.7、AGP 8.3.2、Kotlin 1.9.23）遵循各自的开源许可，
不构成对本项目许可的影响。

