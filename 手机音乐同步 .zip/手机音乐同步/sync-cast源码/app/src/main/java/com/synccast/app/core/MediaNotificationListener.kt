package com.synccast.app.core

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * 通知监听服务。
 *
 * 这是获得 MediaSession 访问权限的标准入口（「设置 → 通知使用权」）。
 * 没有它，MediaSessionManager.getActiveSessions() 会直接抛 SecurityException。
 *
 * 本身不处理通知内容，只用于获得授权；媒体会话通过 MediaSessionManager 读取。
 */
class MediaNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile var connected: Boolean = false
            private set

        fun component(ctx: android.content.Context): ComponentName =
            ComponentName(ctx, MediaNotificationListener::class.java)

        /** 是否已获得通知使用权 */
        fun isAuthorized(ctx: android.content.Context): Boolean {
            val flat = android.provider.Settings.Secure.getString(
                ctx.contentResolver, "enabled_notification_listeners"
            ) ?: return false
            return flat.contains(ctx.packageName)
        }
    }

    override fun onCreate() {
        super.onCreate()
        connected = true
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        connected = false
    }

    override fun onDestroy() {
        connected = false
        super.onDestroy()
    }

    // 通知内容不关心，仅用于持有权限
    override fun onNotificationPosted(sbn: StatusBarNotification?) = Unit
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = Unit
}
