package com.synccast.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Tab { HOME, MEDIA_MASTER, MEDIA_CLIENT, ABOUT }

@Composable
fun SyncCastApp(permissionsGranted: Boolean, onRequestPermissions: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.HOME) }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopTabs(tab) { tab = it }
            if (!permissionsGranted) {
                PermissionBanner(onRequestPermissions)
            }
            Box(Modifier.fillMaxSize().padding(12.dp)) {
                when (tab) {
                    Tab.HOME -> HomeScreen(
                        permissionsGranted = permissionsGranted,
                        onGoMaster = { tab = Tab.MEDIA_MASTER },
                        onGoClient = { tab = Tab.MEDIA_CLIENT }
                    )
                    Tab.MEDIA_MASTER -> MediaMasterScreen()
                    Tab.MEDIA_CLIENT -> MediaClientScreen()
                    Tab.ABOUT -> AboutScreen()
                }
            }
        }
    }
}

@Composable
private fun PermissionBanner(onRequest: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "需要麦克风与通知权限（主机要采集外放声音，从机要保持后台播放）。",
                modifier = Modifier.weight(1f),
                fontSize = 13.sp,
                color = Color(0xFF6B5200)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = onRequest) { Text("授权") }
        }
    }
}

@Composable
private fun TopTabs(current: Tab, onSelect: (Tab) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        val items = listOf(
            Tab.HOME to "首页",
            Tab.MEDIA_MASTER to "同步主机",
            Tab.MEDIA_CLIENT to "同步从机",
            Tab.ABOUT to "说明"
        )
        for ((t, label) in items) {
            TextButton(
                onClick = { onSelect(t) },
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    label,
                    fontWeight = if (t == current) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
    HorizontalDivider()
}

// ------------------------------------------------------------------ 首页

@Composable
private fun HomeScreen(
    permissionsGranted: Boolean,
    onGoMaster: () -> Unit,
    onGoClient: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("SyncCast", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary)
        Text("多台手机同步播放同一首歌", fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "主机外放网易云/QQ音乐，麦克风拾音后通过局域网广播给其他手机，\n" +
                "各机按统一时间轴精确对齐播放。",
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))

        BigAction(
            title = "我是主机",
            desc = "这台手机外放音乐，并采集麦克风广播",
            enabled = permissionsGranted,
            color = MaterialTheme.colorScheme.primary,
            onClick = onGoMaster
        )
        Spacer(Modifier.height(16.dp))
        BigAction(
            title = "我是从机",
            desc = "这台手机接收并同步播放",
            enabled = permissionsGranted,
            color = MaterialTheme.colorScheme.secondary,
            onClick = onGoClient
        )
        Spacer(Modifier.height(32.dp))
        Text(
            "使用提示：\n" +
                "1. 所有手机连接到同一个 Wi-Fi（或主机热点）\n" +
                "2. 主机把音量调到中高，手机靠近播放的扬声器\n" +
                "3. 从机延迟建议 200ms，网络抖动大时调到 300ms",
            fontSize = 12.sp,
            color = Color.Gray
        )
    }
}

@Composable
private fun BigAction(
    title: String,
    desc: String,
    enabled: Boolean,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(96.dp),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(desc, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ 说明

@Composable
private fun AboutScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        InfoCard(title = "工作原理") {
            Text(
                "1. 每台手机都运行 SyncCast，并各自打开网易云播放同一首歌。\n\n" +
                    "2. 主机 SyncCast 通过系统 MediaSession 读取本机网易云的播放位置（毫秒级）。\n\n" +
                    "3. 主机把「歌曲名 + 歌手 + 播放位置 + 精确时间戳」通过局域网广播给所有从机。\n\n" +
                    "4. 从机同样读取本机网易云的位置，与主机对比：\n" +
                    "   · 歌曲不一致 → 提示你手动切歌\n" +
                    "   · 位置偏差 > 200ms → 调用 seekTo 精确对齐\n\n" +
                    "这样音质是网易云原生音质，不需要录音、不需要外放。",
                fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        InfoCard(title = "已知限制") {
            Text(
                "· 需要授予「通知使用权」，这是 Android 读取 MediaSession 的标准入口。\n\n" +
                    "· 每台手机必须各自打开网易云并播放**同一首歌**，App 无法强制切歌，只能提示。\n\n" +
                    "· seek 会有极短暂顿（约 100ms），偏差超过 200ms 才触发，每分钟通常只触发几次。\n\n" +
                    "· 需要所有设备在同一 Wi-Fi。\n\n" +
                    "· 音乐 App 若上报的进度不准（个别版本存在），同步效果会受影响。",
                fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        InfoCard(title = "版本") {
            StatRow("版本号", "0.2.0-media")
            StatRow("构建类型", "debug")
        }
    }
}

// ------------------------------------------------------------------ 组件

@Composable
private fun InfoCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}
