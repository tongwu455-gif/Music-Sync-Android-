package com.synccast.app

import android.app.Application
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 全局异常兜底：把未捕获异常写入文件，方便用户导出日志定位闪退。
 * 文件位置：/sdcard/Android/data/com.synccast.app/files/crash_last.txt
 */
class SyncCastApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                dumpCrash(t, e)
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    private fun dumpCrash(t: Thread, e: Throwable) {
        val sw = StringWriter()
        val pw = PrintWriter(sw)
        e.printStackTrace(pw)
        pw.flush()
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val text = buildString {
            append("时间: ").append(ts).append("\n")
            append("线程: ").append(t.name).append("\n")
            append("机型: ").append(android.os.Build.MANUFACTURER).append(' ')
            append(android.os.Build.MODEL).append('\n')
            append("系统: Android ").append(android.os.Build.VERSION.RELEASE)
            append(" (SDK ").append(android.os.Build.VERSION.SDK_INT).append(")\n")
            append("版本: ").append("0.1.0-mvp").append('\n')
            append("---\n")
            append(sw.toString())
        }
        // 尝试多个位置，至少一个可写
        val dirs = listOfNotNull(
            getExternalFilesDir(null),
            filesDir
        )
        for (d in dirs) {
            try {
                val f = java.io.File(d, "crash_last.txt")
                f.writeText(text)
                Log.e("SyncCast", "崩溃日志已写入 ${f.absolutePath}", e)
                return
            } catch (_: Throwable) {
            }
        }
    }
}
