package com.synccast.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.synccast.app.MainActivity
import com.synccast.app.core.MediaClientSession
import com.synccast.app.core.MediaSessionBridge

/**
 * 媒体同步从机服务：接收主机播放状态并让本机音乐 App 对齐。
 */
class MediaClientService : Service() {

    companion object {
        const val CHANNEL_ID = "synccast_media_client"
        const val NOTIF_ID = 1004
        const val ACTION_STOP = "com.synccast.action.MEDIA_CLIENT_STOP"
        const val EXTRA_IP = "ip"

        private var instance: MediaClientService? = null
        private var latest: MediaClientSession.Stats? = null
        private val listeners = mutableListOf<(MediaClientSession.Stats) -> Unit>()
        private val lock = Any()

        fun addListener(l: (MediaClientSession.Stats) -> Unit) {
            synchronized(lock) {
                listeners.add(l)
                latest?.let { l(it) }
            }
        }

        fun removeListener(l: (MediaClientSession.Stats) -> Unit) {
            synchronized(lock) { listeners.remove(l) }
        }

        fun isActive(): Boolean = instance != null

        /** 开关音量统一（本机侧） */
        fun setLocalVolumeSyncEnabled(enabled: Boolean) {
            instance?.session?.setLocalVolumeSyncEnabled(enabled)
        }

        fun isLocalVolumeSyncEnabled(): Boolean =
            instance?.session?.isLocalVolumeSyncEnabled() ?: true

        fun connect(ctx: android.content.Context, ip: String) {
            val i = Intent(ctx, MediaClientService::class.java).apply {
                putExtra(EXTRA_IP, ip)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }
    }

    private var session: MediaClientSession? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            session?.stop()
            session = null
            stopSelf()
            return START_NOT_STICKY
        }
        val ip = intent?.getStringExtra(EXTRA_IP)
        if (ip.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (session == null) {
            val bridge = MediaSessionBridge(this)
            val s = try {
                MediaClientSession(
                    hostIp = ip,
                    port = com.synccast.app.core.Net.CONTROL_PORT,
                    bridge = bridge,
                    targetPackage = null,
                    onStats = { st ->
                        synchronized(lock) { latest = st }
                        val snap: List<(MediaClientSession.Stats) -> Unit>
                        synchronized(lock) { snap = listeners.toList() }
                        for (l in snap) runCatching { l(st) }
                        updateNotification(st)
                    },
                    onLog = { android.util.Log.i("SyncCast", it) }
                )
            } catch (t: Throwable) {
                android.util.Log.e("SyncCast", "创建 MediaClientSession 失败", t)
                stopSelf()
                return START_NOT_STICKY
            }
            if (!s.start()) {
                stopSelf()
                return START_NOT_STICKY
            }
            s.attachVolume(com.synccast.app.core.VolumeController(this))
            session = s
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(): Boolean = try {
        val n = buildNotification("媒体同步从机", "连接中…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (t: Throwable) {
        android.util.Log.e("SyncCast", "startForeground 失败", t)
        false
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "媒体同步从机", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 4, Intent(this, MediaClientService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "断开", stop).build())
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(st: MediaClientSession.Stats) {
        val nm = getSystemService(NotificationManager::class.java)
        val text = if (!st.hasPermission) "缺少通知使用权"
        else if (st.hint != null) st.hint!!
        else "已同步 · 偏差 ${st.offsetMs}ms · seek ${st.seekCount} 次"
        runCatching { nm.notify(NOTIF_ID, buildNotification("媒体同步从机", text)) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        session?.stop()
        session = null
        instance = null
        synchronized(lock) { latest = null }
        super.onDestroy()
    }
}
