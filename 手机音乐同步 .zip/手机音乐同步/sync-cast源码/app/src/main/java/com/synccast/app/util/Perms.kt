package com.synccast.app.util

import android.content.Context
import android.content.pm.PackageManager

object Perms {
    fun hasPermission(ctx: Context, perm: String): Boolean =
        ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
}
