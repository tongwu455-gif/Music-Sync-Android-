package com.synccast.app.core

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.NetworkInterface

object Net {
    const val DISCOVERY_GROUP = "239.255.42.99"
    const val DISCOVERY_PORT = 47777
    const val CONTROL_PORT = 47778
    const val AUDIO_PORT = 47779

    data class LocalIp(val address: String, val iface: NetworkInterface)

    fun localIpv4(): LocalIp? {
        return try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback || ni.isVirtual) continue
                for (addr in ni.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                        return LocalIp(addr.hostAddress ?: continue, ni)
                    }
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    fun deviceName(): String {
        val m = android.os.Build.MANUFACTURER ?: ""
        val mo = android.os.Build.MODEL ?: ""
        return "$m $mo".trim().ifEmpty { "Android 设备" }
    }

    fun randomId(): String =
        java.util.UUID.randomUUID().toString().replace("-", "").take(8)
}

/**
 * 主机发现广播：主机每秒向组播地址发一条 JSON，从机扫描页监听即可无需输入 IP。
 */
class DiscoveryAdvertiser(
    private val sessionName: String,
    private val controlPort: Int = Net.CONTROL_PORT,
    private val audioPort: Int = Net.AUDIO_PORT
) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var socket: MulticastSocket? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                val group = InetAddress.getByName(Net.DISCOVERY_GROUP)
                val s = MulticastSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(Net.DISCOVERY_PORT + 1))
                s.timeToLive = 4
                s.networkInterface = Net.localIpv4()?.iface
                socket = s
                val ip = Net.localIpv4()?.address ?: ""
                val payload = JSONObject().apply {
                    put("t", "adv")
                    put("name", sessionName)
                    put("ip", ip)
                    put("control", controlPort)
                    put("audio", audioPort)
                    put("dev", Net.deviceName())
                }.toString().toByteArray(Charsets.UTF_8)
                while (running) {
                    s.send(DatagramPacket(payload, payload.size, group, Net.DISCOVERY_PORT))
                    Thread.sleep(1000)
                }
            } catch (_: Throwable) {
            } finally {
                try { socket?.close() } catch (_: Throwable) { }
            }
        }, "discovery-adv").apply { start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        try { socket?.close() } catch (_: Throwable) { }
    }
}

data class FoundHost(
    val name: String,
    val ip: String,
    val controlPort: Int,
    val audioPort: Int,
    val lastSeenMs: Long
)

/**
 * 从机侧发现监听器。
 */
class DiscoveryListener(private val onFound: (FoundHost) -> Unit) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var socket: MulticastSocket? = null
    @Volatile var lastError: String? = null
        private set

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                val group = InetAddress.getByName(Net.DISCOVERY_GROUP)
                val s = MulticastSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(Net.DISCOVERY_PORT))
                val local = Net.localIpv4()
                if (local != null) {
                    try { s.joinGroup(InetSocketAddress(group, Net.DISCOVERY_PORT), local.iface) }
                    catch (_: Throwable) { s.joinGroup(group) }
                } else {
                    s.joinGroup(group)
                }
                socket = s
                val buf = ByteArray(2048)
                while (running) {
                    val pkt = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(pkt)
                    } catch (_: Throwable) {
                        if (!running) break else continue
                    }
                    try {
                        val o = JSONObject(String(pkt.data, 0, pkt.length, Charsets.UTF_8))
                        val ip = o.optString("ip").ifBlank { pkt.address.hostAddress }
                        onFound(
                            FoundHost(
                                name = o.optString("dev", "未知主机"),
                                ip = ip,
                                controlPort = o.optInt("control", Net.CONTROL_PORT),
                                audioPort = o.optInt("audio", Net.AUDIO_PORT),
                                lastSeenMs = System.currentTimeMillis()
                            )
                        )
                    } catch (_: Throwable) {
                    }
                }
            } catch (t: Throwable) {
                lastError = t.message
            } finally {
                try { socket?.close() } catch (_: Throwable) { }
            }
        }, "discovery-listen").apply { start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        try { socket?.close() } catch (_: Throwable) { }
    }
}

/** 拿一个 WifiManager 多播锁，避免部分机型休眠后收不到组播。 */
fun acquireMulticastLock(ctx: Context): WifiManager.MulticastLock? {
    return try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.createMulticastLock("synccast-mcast").apply {
            setReferenceCounted(false)
            acquire()
        }
    } catch (_: Throwable) {
        null
    }
}
