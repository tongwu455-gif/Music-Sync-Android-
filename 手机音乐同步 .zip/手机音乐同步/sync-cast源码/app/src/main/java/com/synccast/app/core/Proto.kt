package com.synccast.app.core

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * 线上协议（全部小端）。
 *
 * 传输结构：
 *   [1 字节 type][1 字节 flags][2 字节 reserved]
 *   type=0x01 CONTROL: 后跟 4 字节长度 + UTF-8 JSON 负载
 *   type=0x02 AUDIO  : 后跟 4 字节长度 + 4 字节 seq + 8 字节主机播放位置(微秒) + 8 字节主机纳秒时间戳 + PCM
 *
 * 同步原理：
 *   主机用 System.nanoTime() 作为唯一时间基准（单调钟）。
 *   每个 CONTROL 包和 AUDIO 包都携带主机发送时刻 t_host。
 *   从机测出 (接收时刻 - t_host) = 单向延迟 + 时钟偏移，取往返最小值作为
 *   baseline_offset（把主机时钟换算到从机时钟），之后按
 *   playAtMicros = hostPositionUs + delayUs 精确排期播放。
 */
object Proto {
    const val MAGIC_TYPE_CONTROL = 0x01
    const val MAGIC_TYPE_AUDIO = 0x02

    // ---------- 控制消息 ----------
    const val MSG_HELLO = "hello"          // 主机 -> 从机
    const val MSG_WELCOME = "welcome"      // 从机 -> 主机
    const val MSG_PING = "ping"            // 双向测延迟，receiver 填入 t_recv/t_ack
    const val MSG_STATE = "state"          // 主机 -> 从机 播放状态变化
    const val MSG_CLOCK = "clock"          // 主机 -> 从机 低开销时钟校准
    const val MSG_LATENCY = "latency"      // 主机 -> 从机 期望整体延迟

    // ---------- 播放状态 ----------
    const val PLAYING = 1
    const val PAUSED = 0

    /** 主机对外声明的会话参数，从机据此创建对应的 AudioTrack。 */
    data class SessionConfig(
        val sessionId: String,
        val sampleRate: Int,
        val channels: Int,
        val bufferBytes: Int,
        /** 主机端从采集到发出的固定处理延迟，作为整体延迟的一部分。 */
        val masterPipelineUs: Long
    )
}
