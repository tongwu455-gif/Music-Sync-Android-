package com.synccast.app.core

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.Socket

/**
 * TCP 帧流。
 *
 * 帧头 8 字节：
 *   byte  type        1=CONTROL 2=AUDIO
 *   byte  flags       保留
 *   short reserved    保留
 *   int   payloadLen
 *
 * CONTROL payload = UTF-8 JSON
 * AUDIO   payload = 20 字节头 + PCM：int seq、long chunkStartHostNs、long reserved
 */
class FrameStream(socket: Socket) {

    private val input = DataInputStream(socket.getInputStream().buffered(128 * 1024))
    private val output = DataOutputStream(socket.getOutputStream().buffered(128 * 1024))

    class Frame(val type: Int, val payload: ByteArray)

    @Throws(IOException::class)
    fun readFrame(): Frame {
        val type = readByteOrThrow()
        readByteOrThrow()
        readShortOrThrow()
        val len = input.readInt()
        if (len < 0 || len > MAX_FRAME) throw IOException("帧长度非法: $len")
        val payload = ByteArray(len)
        input.readFully(payload)
        return Frame(type, payload)
    }

    @Synchronized
    @Throws(IOException::class)
    fun writeJson(json: String) {
        writeFrame(Proto.MAGIC_TYPE_CONTROL, json.toByteArray(Charsets.UTF_8))
    }

    @Synchronized
    @Throws(IOException::class)
    fun writeAudio(seq: Int, chunkStartHostNs: Long, pcm: ByteArray, offset: Int, length: Int) {
        output.writeByte(Proto.MAGIC_TYPE_AUDIO)
        output.writeByte(0)
        output.writeShort(0)
        output.writeInt(20 + length)
        output.writeInt(seq)
        output.writeLong(chunkStartHostNs)
        output.writeLong(0L)
        output.write(pcm, offset, length)
        output.flush()
    }

    @Synchronized
    @Throws(IOException::class)
    private fun writeFrame(type: Int, payload: ByteArray) {
        output.writeByte(type)
        output.writeByte(0)
        output.writeShort(0)
        output.writeInt(payload.size)
        output.write(payload)
        output.flush()
    }

    private fun readByteOrThrow(): Int {
        val v = input.read()
        if (v < 0) throw EOFException()
        return v
    }

    private fun readShortOrThrow(): Int = (readByteOrThrow() shl 8) or readByteOrThrow()

    companion object {
        const val MAX_FRAME = 512 * 1024

        fun open(socket: Socket): FrameStream {
            socket.tcpNoDelay = true
            socket.soTimeout = 0
            return FrameStream(socket)
        }
    }
}
