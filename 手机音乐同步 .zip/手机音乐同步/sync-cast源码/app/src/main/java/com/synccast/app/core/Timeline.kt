package com.synccast.app.core

/**
 * 统一的时钟与时间轴工具。
 *
 * 全局时间基准：System.nanoTime()（单调，不受系统时间调整影响）。
 * 主机广播的每个音频包都带有「该包首帧在主机时间轴上的位置」和「主机发送时刻」。
 * 从机通过 ping-pong 得到 (主机时钟 - 从机时钟) 偏移，从而把所有时间换算到本地。
 */
object Timeline {
    fun nowNs(): Long = System.nanoTime()

    fun usToNs(us: Long): Long = us * 1000L

    fun nsToUs(ns: Long): Long = ns / 1000L

    /** 字节数 -> 微秒时长 */
    fun bytesToUs(bytes: Int, sampleRate: Int, channels: Int): Long {
        val bytesPerSec = sampleRate.toLong() * channels * 2
        return if (bytesPerSec <= 0) 0 else bytes * 1_000_000L / bytesPerSec
    }

    /** 字节数 -> 帧数 */
    fun bytesToFrames(bytes: Int, channels: Int): Long = (bytes / (channels * 2)).toLong()
}
