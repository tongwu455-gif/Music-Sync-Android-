package com.synccast.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Purple = Color(0xFF6C5CE7)
private val Teal = Color(0xFF00B894)
private val Ink = Color(0xFF12121A)

private val Light = lightColorScheme(
    primary = Purple,
    secondary = Teal,
    background = Color(0xFFF7F7FB),
    surface = Color.White
)

private val Dark = darkColorScheme(
    primary = Purple,
    secondary = Teal,
    background = Ink,
    surface = Color(0xFF1C1C26)
)

@Composable
fun SyncCastTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content
    )
}
