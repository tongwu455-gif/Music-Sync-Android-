package com.synccast.app.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.synccast.app.core.MediaClientSession
import com.synccast.app.core.MediaMasterSession
import com.synccast.app.core.MediaNotificationListener
import com.synccast.app.service.MediaClientService
import com.synccast.app.service.MediaMasterService

/** 媒体同步：主机页 */
@Composable
fun MediaMasterScreen() {
    val ctx = LocalContext.current
    var stats by remember { mutableStateOf<MediaMasterSession.Stats?>(null) }
    var running by remember { mutableStateOf(MediaMasterService.isActive()) }
    var authorized by remember { mutableStateOf(MediaNotificationListener.isAuthorized(ctx)) }

    DisposableEffect(Unit) {
        val l: (MediaMasterSession.Stats) -> Unit = { stats = it }
        MediaMasterService.addListener(l)
        onDispose { MediaMasterService.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            running = MediaMasterService.isActive()
            authorized = MediaNotificationListener.isAuthorized(ctx)
            kotlinx.coroutines.delay(600)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        if (!authorized) {
            PermissionCard(
                title = "需要「通知使用权」",
                body = "Android 只有拿到通知使用权，才允许读取网易云/QQ音乐的播放状态。" +
                    "这是系统标准权限，不会读取你的通知内容。",
                action = "去授权",
                onAction = {
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            )
            Spacer(Modifier.height(12.dp))
        }

        SectionCard("主机状态") {
            StatRow("运行中", if (running) "是" else "否")
            StatRow("授权状态", if (authorized) "已授权 ✅" else "未授权 ❌")
            StatRow("本机 IP", stats?.localIp ?: "-")
            StatRow("已连从机", "${stats?.clients ?: 0} 台")
            StatRow("当前歌曲", stats?.songTitle ?: "-")
            StatRow("歌手", stats?.songArtist ?: "-")
            StatRow("播放位置", formatMs(stats?.positionMs ?: 0))
            StatRow("播放状态", if (stats?.playing == true) "播放中" else "已暂停")
            StatRow("媒体音量", "${stats?.volumePercent ?: 0}%  (${stats?.volumeLevel ?: "-"})")
            stats?.error?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = Color.Red, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("统一音量") {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("音量统一", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        if (stats?.volumeSyncEnabled != false) "开启：从机音量跟随主机"
                        else "关闭：各机音量独立控制",
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                androidx.compose.material3.Switch(
                    checked = stats?.volumeSyncEnabled != false,
                    onCheckedChange = { enabled ->
                        MediaMasterService.setVolumeSyncEnabled(enabled)
                    }
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "拖动会同时改变本机与所有从机的媒体音量（按百分比对齐，" +
                    "不同机型音量档位不同）。关闭后各机互不影响。",
                fontSize = 12.sp, color = Color.Gray
            )
            Spacer(Modifier.height(8.dp))
            val vc = remember { com.synccast.app.core.VolumeController(ctx) }
            var pct by remember { mutableStateOf((vc.currentPercent() * 100).toInt()) }
            Text("${pct}%", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            androidx.compose.material3.Slider(
                value = pct.toFloat(),
                onValueChange = {
                    pct = it.toInt()
                    vc.setPercent(it / 100f)
                },
                valueRange = 0f..100f,
                enabled = stats?.volumeSyncEnabled != false
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 50, 70, 100).forEach { preset ->
                    Button(
                        onClick = {
                            pct = preset
                            vc.setPercent(preset / 100f)
                        },
                        enabled = stats?.volumeSyncEnabled != false,
                        modifier = Modifier.weight(1f)
                    ) { Text("$preset%", fontSize = 12.sp) }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("使用说明") {
            Text(
                "1. 本机打开网易云，播放你想同步的歌\n" +
                    "2. 点下面「启动同步主机」\n" +
                    "3. 其他手机在同一 Wi-Fi 下打开 SyncCast，进入「媒体同步 · 从机」，输入本机 IP\n" +
                    "4. 从机会自动对齐进度；若提示歌曲不同，请手动切到同一首\n\n" +
                    "本模式不录音、不外放，音质是网易云原生音质。",
                fontSize = 13.sp
            )
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (running) {
                    ctx.startService(
                        Intent(ctx, MediaMasterService::class.java)
                            .setAction(MediaMasterService.ACTION_STOP)
                    )
                } else {
                    val i = Intent(ctx, MediaMasterService::class.java)
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        ctx.startForegroundService(i)
                    } else {
                        ctx.startService(i)
                    }
                }
                running = !running
            },
            enabled = authorized,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text(if (running) "停止同步主机" else "启动同步主机")
        }
    }
}

/** 媒体同步：从机页 */
@Composable
fun MediaClientScreen() {
    val ctx = LocalContext.current
    var ip by remember { mutableStateOf("") }
    var stats by remember { mutableStateOf<MediaClientSession.Stats?>(null) }
    var running by remember { mutableStateOf(MediaClientService.isActive()) }
    var authorized by remember { mutableStateOf(MediaNotificationListener.isAuthorized(ctx)) }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        val l: (MediaClientSession.Stats) -> Unit = { stats = it }
        MediaClientService.addListener(l)
        onDispose { MediaClientService.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            running = MediaClientService.isActive()
            authorized = MediaNotificationListener.isAuthorized(ctx)
            kotlinx.coroutines.delay(600)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        if (!authorized) {
            PermissionCard(
                title = "需要「通知使用权」",
                body = "读取和控制本机网易云的播放进度需要这个系统权限。",
                action = "去授权",
                onAction = {
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            )
            Spacer(Modifier.height(12.dp))
        }

        error?.let {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
            ) {
                Text(it, color = Color(0xFFB71C1C), fontSize = 13.sp,
                    modifier = Modifier.padding(12.dp))
            }
        }

        SectionCard("连接主机") {
            OutlinedTextField(
                value = ip,
                onValueChange = { ip = it },
                label = { Text("主机 IP，如 192.168.1.10") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val t = ip.trim()
                    if (!Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(t)) {
                        error = "IP 格式不正确"
                        return@Button
                    }
                    error = null
                    try {
                        MediaClientService.connect(ctx, t)
                        running = true
                    } catch (e: Throwable) {
                        error = "启动失败：${e.message}"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("连接并同步") }
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("音量统一") {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("本机跟随主机音量", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        when {
                            stats?.localVolumeSyncEnabled == false -> "本机已关闭"
                            stats?.hostVolumeSyncEnabled == false -> "主机已关闭音量统一"
                            else -> "生效中：跟随主机音量"
                        },
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                androidx.compose.material3.Switch(
                    checked = stats?.localVolumeSyncEnabled != false,
                    onCheckedChange = { enabled ->
                        MediaClientService.setLocalVolumeSyncEnabled(enabled)
                    }
                )
            }
            Spacer(Modifier.height(6.dp))
            StatRow("本机开关", if (stats?.localVolumeSyncEnabled != false) "开" else "关")
            StatRow("主机开关", if (stats?.hostVolumeSyncEnabled != false) "开" else "关")
            StatRow("实际生效", if (stats?.volumeSyncActive == true) "✅ 是" else "❌ 否")
        }

        Spacer(Modifier.height(12.dp))
        SectionCard("同步状态") {
            StatRow("已连接", if (stats?.connected == true) "是" else "否")
            StatRow("授权", if (authorized) "✅" else "❌")
            StatRow("歌曲是否一致", if (stats?.songMatch == true) "✅ 一致" else "❌ 不一致")
            StatRow("主机歌曲", "${stats?.hostSong ?: "-"} / ${stats?.hostArtist ?: ""}")
            StatRow("本机歌曲", "${stats?.localSong ?: "-"} / ${stats?.localArtist ?: ""}")
            StatRow("主机位置", formatMs(stats?.hostPositionMs ?: 0))
            StatRow("本机位置", formatMs(stats?.localPositionMs ?: 0))
            StatRow("位置差值", "${stats?.offsetMs ?: 0} ms")
            StatRow("死区状态", if (stats?.inDeadZone == true) "✅ 在 ${stats?.deadZoneMs}ms 内" else "⚠️ 超出死区")
            StatRow("上次 seek 误差", if ((stats?.lastSeekErrorMs ?: 0) > 0) "${stats?.lastSeekErrorMs} ms" else "-")
            StatRow("RTT 抖动", "${stats?.jitterMs ?: 0} ms")
            StatRow("主机音量", "${stats?.hostVolumePercent ?: -1}%")
            StatRow("本机音量", "${stats?.localVolumePercent ?: 0}%")
            StatRow("音量同步", if (stats?.whileSyncingVolume == true) "对齐中…" else "✅ 一致")
            StatRow("RTT", if ((stats?.rttMs ?: -1) >= 0) "${stats?.rttMs} ms" else "-")
            StatRow("已对齐次数", "${stats?.seekCount ?: 0}")
            StatRow("主机播放态", if (stats?.hostPlaying == true) "播放中" else "暂停")
            stats?.hint?.let {
                Spacer(Modifier.height(8.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))) {
                    Text(it, color = Color(0xFF6B5200), fontSize = 13.sp,
                        modifier = Modifier.padding(10.dp))
                }
            }
            stats?.error?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = Color.Red, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                ctx.startService(
                    Intent(ctx, MediaClientService::class.java)
                        .setAction(MediaClientService.ACTION_STOP)
                )
                running = false
            },
            enabled = running,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("断开") }
    }
}

@Composable
private fun PermissionCard(title: String, body: String, action: String, onAction: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color(0xFF6B5200))
            Spacer(Modifier.height(6.dp))
            Text(body, fontSize = 13.sp, color = Color(0xFF6B5200))
            Spacer(Modifier.height(10.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
internal fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
internal fun StatRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = Color.Gray)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

internal fun formatMs(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val m = total / 60
    val s = total % 60
    return "%d:%02d.%03d".format(m, s, ms % 1000)
}
