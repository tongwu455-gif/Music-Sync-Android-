package com.synccast.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.synccast.app.MainActivity
import com.synccast.app.core.MediaMasterSession
import com.synccast.app.core.MediaSessionBridge

/**
 * 媒体同步主机服务：读取本机网易云/QQ音乐的播放状态并广播给从机。
 * 不录音、不外放。
 */
class MediaMasterService : Service() {

    companion object {
        const val CHANNEL_ID = "synccast_media_master"
        const val NOTIF_ID = 1003
        const val ACTION_STOP = "com.synccast.action.MEDIA_MASTER_STOP"

        private var instance: MediaMasterService? = null
        private var latest: MediaMasterSession.Stats? = null
        private val listeners = mutableListOf<(MediaMasterSession.Stats) -> Unit>()
        private val lock = Any()

        fun addListener(l: (MediaMasterSession.Stats) -> Unit) {
            synchronized(lock) {
                listeners.add(l)
                latest?.let { l(it) }
            }
        }

        fun removeListener(l: (MediaMasterSession.Stats) -> Unit) {
            synchronized(lock) { listeners.remove(l) }
        }

        fun isActive(): Boolean = instance != null

        /** 开关音量统一（主机侧） */
        fun setVolumeSyncEnabled(enabled: Boolean) {
            instance?.session?.setVolumeSyncEnabled(enabled)
        }

        fun isVolumeSyncEnabled(): Boolean =
            instance?.session?.volumeSyncEnabled ?: true
    }

    private var session: MediaMasterSession? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            session?.stop()
            session = null
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (session == null) {
            val bridge = MediaSessionBridge(this)
            val s = MediaMasterSession(
                bridge = bridge,
                targetPackage = null, // 自动识别正在播放的音乐 App
                onStats = { st ->
                    synchronized(lock) { latest = st }
                    val snap: List<(MediaMasterSession.Stats) -> Unit>
                    synchronized(lock) { snap = listeners.toList() }
                    for (l in snap) runCatching { l(st) }
                    updateNotification(st)
                },
                onLog = { android.util.Log.i("SyncCast", it) }
            )
            if (!s.start()) {
                stopSelf()
                return START_NOT_STICKY
            }
            s.attachVolume(com.synccast.app.core.VolumeController(this))
            session = s
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(): Boolean = try {
        val n = buildNotification("媒体同步主机", "等待从机连接…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (t: Throwable) {
        android.util.Log.e("SyncCast", "startForeground 失败", t)
        false
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "媒体同步主机", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 3, Intent(this, MediaMasterService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "停止", stop).build())
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(st: MediaMasterSession.Stats) {
        val nm = getSystemService(NotificationManager::class.java)
        val text = if (!st.hasPermission) "缺少通知使用权，无法读取播放状态"
        else "从机 ${st.clients} 台 · ${if (st.playing) "播放中" else "已暂停"} · ${st.songTitle}"
        runCatching { nm.notify(NOTIF_ID, buildNotification("媒体同步主机", text)) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        session?.stop()
        session = null
        instance = null
        synchronized(lock) { latest = null }
        super.onDestroy()
    }
}
