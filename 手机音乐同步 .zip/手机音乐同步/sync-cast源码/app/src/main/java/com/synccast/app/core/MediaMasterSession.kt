package com.synccast.app.core

import android.media.session.MediaController
import android.os.SystemClock
import org.json.JSONObject
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger

/**
 * 媒体同步主机。
 *
 * 不录音、不推音频流，只做一件事：
 *   每 200ms 读取一次网易云/QQ音乐的 MediaSession，
 *   把 {歌曲标识, 播放位置, 播放状态, 时间戳} 广播给所有从机。
 *
 * 从机收到后与自己的音乐 App 对比，必要时 seekTo 对齐。
 * 由于音乐 App 本体在各自设备上播放，音质是原生的，带宽几乎为零。
 */
class MediaMasterSession(
    private val bridge: MediaSessionBridge,
    private val targetPackage: String?,
    private val onStats: (Stats) -> Unit,
    private val onLog: (String) -> Unit
) {
    data class Stats(
        val running: Boolean,
        val clients: Int,
        val songTitle: String,
        val songArtist: String,
        val positionMs: Long,
        val playing: Boolean,
        val localIp: String,
        val hasPermission: Boolean,
        val volumePercent: Int,
        val volumeLevel: String,
        val volumeSyncEnabled: Boolean,
        val error: String?
    )

    /** 音量控制（延迟初始化，避免无 Context 时报错） */
    private var volumeController: VolumeController? = null

    /** 主机当前音量缓存，由监听器实时更新 */
    @Volatile private var currentVolumePercent: Int = -1
    @Volatile private var currentVolumeRaw: Int = -1
    private var stopVolumeObserver: (() -> Unit)? = null

    /** 是否启用音量统一。关闭后不再广播音量包 */
    @Volatile var volumeSyncEnabled: Boolean = true
        private set

    fun attachVolume(vc: VolumeController) {
        volumeController = vc
        // 事件驱动：音量一变就立刻广播，不再等下一轮轮询
        currentVolumePercent = (vc.currentPercent() * 100).toInt()
        currentVolumeRaw = vc.currentVolume()
        stopVolumeObserver = vc.observe { percent, raw ->
            val newPct = (percent * 100).toInt()
            if (newPct == currentVolumePercent && raw == currentVolumeRaw) return@observe
            currentVolumePercent = newPct
            currentVolumeRaw = raw
            // 只在开启音量统一时才广播
            if (!volumeSyncEnabled) return@observe
            onLog("主机音量变化 -> ${newPct}% (${raw}/${vc.maxVolume()})")
            broadcastVolumeNow()
        }
    }

    /** 开关音量统一 */
    fun setVolumeSyncEnabled(enabled: Boolean) {
        if (volumeSyncEnabled == enabled) return
        volumeSyncEnabled = enabled
        // 状态变化立即通知从机
        val json = JSONObject().apply {
            put("t", "volsync")
            put("enabled", enabled)
            put("vol", currentVolumePercent)
            put("hostNs", Timeline.nowNs())
        }.toString()
        val snapshot = synchronized(clients) { clients.toList() }
        for (c in snapshot) {
            runCatching { c.fs?.writeJson(json) }
        }
        onLog("音量统一 -> ${if (enabled) "开启" else "关闭"}")
    }

    /** 立刻广播一次音量包 */
    private fun broadcastVolumeNow() {
        if (!volumeSyncEnabled) return
        val pct = currentVolumePercent
        if (pct < 0) return
        val json = JSONObject().apply {
            put("t", "volume")
            put("vol", pct)
            put("max", volumeController?.maxVolume() ?: -1)
            put("hostNs", Timeline.nowNs())
        }.toString()
        val snapshot = synchronized(clients) { clients.toList() }
        for (c in snapshot) {
            runCatching { c.fs?.writeJson(json) }
        }
    }

    private class Client(val clientId: String, val name: String) {
        @Volatile var fs: FrameStream? = null
        @Volatile var socket: Socket? = null
        @Volatile var pingSeq: Long = 0
        @Volatile var pingSentAt: Long = 0
        @Volatile var bestRttNs: Long = Long.MAX_VALUE
    }

    private val clients = Collections.synchronizedList(mutableListOf<Client>())
    private val idGen = AtomicInteger(1)

    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var broadcastThread: Thread? = null
    private var statsThread: Thread? = null
    @Volatile private var fatalError: String? = null

    val localIp: String = Net.localIpv4()?.address ?: "0.0.0.0"

    fun start(): Boolean {
        if (running) return true
        running = true
        Thread({ doStart() }, "media-master-start").start()
        return true
    }

    private fun doStart() {
        try {
            server = ServerSocket(Net.CONTROL_PORT).apply { reuseAddress = true }
        } catch (e: Throwable) {
            fatalError = "端口被占用：${e.message}"
            onLog(fatalError!!)
            running = false
            return
        }
        Thread({ acceptLoop() }, "accept").start()
        broadcastThread = Thread({ broadcastLoop() }, "media-broadcast").apply { start() }
        statsThread = Thread({ statsLoop() }, "stats").apply { start() }
        onLog("媒体同步主机启动 IP=$localIp，目标=${targetPackage ?: "自动"}")
    }

    private fun acceptLoop() {
        while (running) {
            val sock = try {
                server?.accept()
            } catch (_: Throwable) {
                break
            } ?: break
            Thread({
                try {
                    sock.tcpNoDelay = true
                    sock.soTimeout = 8000
                    val fs = FrameStream.open(sock)
                    val first = fs.readFrame()
                    if (first.type != Proto.MAGIC_TYPE_CONTROL) {
                        sock.close(); return@Thread
                    }
                    val hello = JSONObject(String(first.payload, Charsets.UTF_8))
                    val cid = hello.optString("clientId").ifBlank { "c${idGen.getAndIncrement()}" }
                    val cname = hello.optString("name", "从机")
                    sock.soTimeout = 0
                    val c = Client(cid, cname)
                    c.fs = fs
                    c.socket = sock
                    clients.add(c)
                    onLog("从机接入：$cname (${sock.inetAddress.hostAddress})")
                    // 立即发一次完整状态
                    pushMediaState(c)
                    // 立即告知从机当前音量统一开关状态
                    runCatching {
                        c.fs?.writeJson(
                            JSONObject().apply {
                                put("t", "volsync")
                                put("enabled", volumeSyncEnabled)
                                put("vol", currentVolumePercent)
                                put("hostNs", Timeline.nowNs())
                            }.toString()
                        )
                    }
                    // 读 pong
                    while (running) {
                        val f = fs.readFrame()
                        if (f.type != Proto.MAGIC_TYPE_CONTROL) continue
                        val o = JSONObject(String(f.payload, Charsets.UTF_8))
                        if (o.optString("t") == "pong") {
                            val now = Timeline.nowNs()
                            if (o.optLong("seq") == c.pingSeq) {
                                val rtt = now - c.pingSentAt
                                if (rtt > 0) {
                                    if (rtt < c.bestRttNs) c.bestRttNs = rtt
                                    runCatching {
                                        fs.writeJson(Msg.clock(rtt, o.optLong("t0"), o.optLong("c1")))
                                    }
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {
                } finally {
                    clients.removeAll { it.socket === sock }
                    try { sock.close() } catch (_: Throwable) { }
                }
            }, "client").start()
        }
    }

    private fun broadcastLoop() {
        var seq = 0L
        while (running) {
            seq++
            val snap = try {
                bridge.currentSnapshot(targetPackage)
            } catch (_: Throwable) {
                null
            }
            val snapshot = synchronized(clients) { clients.toList() }
            if (snap != null) {
                val volPercent = volumeController?.currentPercent() ?: -1f
                val json = JSONObject().apply {
                    put("t", "media")
                    put("title", snap.title)
                    put("artist", snap.artist)
                    put("album", snap.album)
                    put("pkg", snap.packageName)
                    put("pos", snap.positionNowMs())
                    put("playing", snap.playing)
                    put("speed", snap.speed.toDouble())
                    put("hostNs", Timeline.nowNs())
                    put("seekable", bridge.supportsSeek(snap))
                    // 原始快照（未外推），供从机做更精细的推算与校验
                    put("rawPos", snap.positionMs)
                    put("rawUpdatedMs", snap.updatedElapsedMs)
                    if (volPercent >= 0f) put("vol", (volPercent * 100).toInt())
                }.toString()
                for (c in snapshot) {
                    runCatching { c.fs?.writeJson(json) }
                }
            }
            // 时钟同步：提高到每 500ms 一次（每 5 个 tick，tick=100ms）
            if (seq % 5 == 0L) {
                val t = Timeline.nowNs()
                for (c in snapshot) {
                    runCatching {
                        c.pingSeq++
                        c.pingSentAt = t
                        c.fs?.writeJson(Msg.ping(c.pingSeq, t))
                    }
                }
            }
            try { Thread.sleep(100) } catch (_: InterruptedException) { return }
        }
    }

    private fun pushMediaState(c: Client) {
        val snap = bridge.currentSnapshot(targetPackage) ?: return
        val volPercent = volumeController?.currentPercent() ?: -1f
        runCatching {
            c.fs?.writeJson(
                JSONObject().apply {
                    put("t", "media")
                    put("title", snap.title)
                    put("artist", snap.artist)
                    put("album", snap.album)
                    put("pkg", snap.packageName)
                    put("pos", snap.positionNowMs())
                    put("playing", snap.playing)
                    put("speed", snap.speed.toDouble())
                    put("hostNs", Timeline.nowNs())
                    put("seekable", bridge.supportsSeek(snap))
                    if (volPercent >= 0f) put("vol", (volPercent * 100).toInt())
                }.toString()
            )
        }
    }

    private fun statsLoop() {
        while (running) {
            val snap = runCatching { bridge.currentSnapshot(targetPackage) }.getOrNull()
            val vc = volumeController
            onStats(
                Stats(
                    running = running,
                    clients = clients.size,
                    songTitle = snap?.title ?: "（未检测到播放）",
                    songArtist = snap?.artist ?: "",
                    positionMs = snap?.positionNowMs() ?: 0,
                    playing = snap?.playing ?: false,
                    localIp = localIp,
                    hasPermission = bridge.hasPermission(),
                    volumePercent = ((vc?.currentPercent() ?: 0f) * 100).toInt(),
                    volumeLevel = if (vc != null) "${vc.currentVolume()}/${vc.maxVolume()}" else "-",
                    volumeSyncEnabled = volumeSyncEnabled,
                    error = fatalError
                )
            )
            try { Thread.sleep(400) } catch (_: InterruptedException) { return }
        }
    }

    /** 主机本地调音量 */
    fun setVolumePercent(percent: Float): Boolean {
        return volumeController?.setPercent(percent) ?: false
    }

    fun stop() {
        running = false
        stopVolumeObserver?.invoke()
        stopVolumeObserver = null
        broadcastThread?.interrupt()
        statsThread?.interrupt()
        broadcastThread = null
        statsThread = null
        synchronized(clients) {
            for (c in clients) {
                try { c.socket?.close() } catch (_: Throwable) { }
            }
            clients.clear()
        }
        try { server?.close() } catch (_: Throwable) { }
        server = null
    }

    fun clientCount(): Int = clients.size
}
