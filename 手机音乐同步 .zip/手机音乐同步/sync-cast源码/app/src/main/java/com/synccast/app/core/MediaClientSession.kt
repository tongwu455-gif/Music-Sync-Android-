package com.synccast.app.core

import android.media.session.MediaController
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

/**
 * 媒体同步从机。
 *
 * 连接主机，接收 {歌曲, 位置, 状态, 时间戳}，与本地音乐 App 对比：
 *  - 歌曲不一致 → 提示用户手动切歌（不强行切，避免打断）
 *  - 位置偏差 > 200ms → seekTo 对齐
 *  - 播放/暂停不一致 → 同步
 *
 * 时钟同步：复用 ping/pong 得到主机与本地的时间偏移，
 * 从而把主机的「位置 + 时间戳」换算成「此刻应该播到哪」。
 */
class MediaClientSession(
    private val hostIp: String,
    private val port: Int,
    private val bridge: MediaSessionBridge,
    private val targetPackage: String?,
    /** 触发 seek 的偏差阈值（毫秒） */
    private val seekThresholdMs: Long = 200,
    private val onStats: (Stats) -> Unit,
    private val onLog: (String) -> Unit
) {
    data class Stats(
        val connected: Boolean,
        val hostSong: String,
        val hostArtist: String,
        val hostPositionMs: Long,
        val hostPlaying: Boolean,
        val hostVolumePercent: Int,
        val localVolumePercent: Int,
        val whileSyncingVolume: Boolean,
        val localSong: String,
        val localArtist: String,
        val localPositionMs: Long,
        val localPlaying: Boolean,
        val offsetMs: Long,
        val rttMs: Long,
        val songMatch: Boolean,
        val lastSeekAtMs: Long,
        val seekCount: Int,
        val seeking: Boolean,
        val hasPermission: Boolean,
        val error: String?,
        val hint: String?,
        /** 是否处于死区内（偏差可接受） */
        val inDeadZone: Boolean,
        /** 上一次 seek 的实际误差 */
        val lastSeekErrorMs: Long,
        /** RTT 抖动 */
        val jitterMs: Long,
        /** 死区阈值 */
        val deadZoneMs: Long,
        /** 音量统一实际是否生效 */
        val volumeSyncActive: Boolean,
        /** 主机侧开关 */
        val hostVolumeSyncEnabled: Boolean,
        /** 本机侧开关 */
        val localVolumeSyncEnabled: Boolean
    )

    private val clock = ClockSync()
    private var socket: Socket? = null
    private var fs: FrameStream? = null
    private var readThread: Thread? = null
    private var alignThread: Thread? = null
    private var statsThread: Thread? = null

    @Volatile private var running = false
    @Volatile private var fatalError: String? = null

    // 主机最新状态
    @Volatile private var hostTitle = ""
    @Volatile private var hostArtist = ""
    @Volatile private var hostPosMs = 0L
    @Volatile private var hostPlaying = false
    @Volatile private var hostSpeed = 1f
    @Volatile private var hostStampLocalNs = 0L
    @Volatile private var hostSeekable = false
    @Volatile private var hasHostState = false

    @Volatile private var seekCount = 0
    @Volatile private var lastSeekAt = 0L
    @Volatile private var seeking = false
    @Volatile private var hint: String? = null

    /** 原始快照位置（未外推），-1 表示未收到 */
    @Volatile private var rawPosMs = -1L
    /** 是否处于 15ms 死区内 */
    @Volatile private var inDeadZone = false
    /** 上一次 seek 的目标位置，-1 表示无待校验 */
    @Volatile private var pendingSeekTargetMs = -1L
    /** 上一次 seek 的校验误差 */
    @Volatile private var lastSeekErrorMs = 0L

    /** 主机音量百分比 -1 表示未收到 */
    @Volatile private var hostVolumePercent = -1
    @Volatile private var volumeController: VolumeController? = null

    /** 主机侧音量统一开关 */
    @Volatile private var hostVolumeSyncEnabled = true
    /** 本机侧强制开关（与主机开关是「与」关系） */
    @Volatile private var localVolumeSyncEnabled = true

    /** 实际是否生效：两个开关都为真 */
    fun isVolumeSyncActive(): Boolean = hostVolumeSyncEnabled && localVolumeSyncEnabled

    /** 本机开关音量统一 */
    fun setLocalVolumeSyncEnabled(enabled: Boolean) {
        localVolumeSyncEnabled = enabled
        onLog("本机音量统一 -> ${if (enabled) "开启" else "关闭"}")
    }

    fun isHostVolumeSyncEnabled(): Boolean = hostVolumeSyncEnabled
    fun isLocalVolumeSyncEnabled(): Boolean = localVolumeSyncEnabled

    fun attachVolume(vc: VolumeController) {
        volumeController = vc
    }

    companion object {
        /** 主动对齐周期：3 秒 */
        private const val ALIGN_PERIOD_NS = 3_000_000_000L
        /** 死区：15ms 内不调整 */
        const val DEAD_ZONE_MS = 15L
        /** 两次 seek 的最小间隔，防止连续抖动 */
        private const val MIN_SEEK_INTERVAL_NS = 2_500_000_000L
        /** seek 前预加量：补偿 seek 从发出到实际生效的耗时 */
        private const val SEEK_LEAD_MS = 0L
    }

    fun start(): Boolean {
        if (running) return true
        running = true
        Thread({ doConnect() }, "media-client-connect").start()
        return true
    }

    private fun doConnect() {
        val sock: Socket
        try {
            sock = Socket()
            sock.connect(InetSocketAddress(hostIp, port), 5000)
            sock.tcpNoDelay = true
        } catch (t: Throwable) {
            fatalError = "连接主机失败：${t.message}"
            onLog(fatalError!!)
            running = false
            return
        }
        if (!running) {
            try { sock.close() } catch (_: Throwable) { }
            return
        }
        socket = sock
        val frameStream = FrameStream.open(sock)
        fs = frameStream
        try {
            frameStream.writeJson(
                JSONObject().apply {
                    put("t", "hello")
                    put("clientId", "mc-" + Net.randomId())
                    put("name", Net.deviceName())
                }.toString()
            )
        } catch (t: Throwable) {
            fatalError = "握手失败：${t.message}"
            onLog(fatalError!!)
            closeAll()
            running = false
            return
        }
        readThread = Thread({ readLoop(frameStream) }, "media-read").apply { start() }
        alignThread = Thread({ alignLoop() }, "align").apply { start() }
        statsThread = Thread({ statsLoop() }, "media-stats").apply { start() }
        onLog("已连接同步主机 $hostIp")
    }

    private fun readLoop(f: FrameStream) {
        try {
            while (running) {
                val frame = f.readFrame()
                if (frame.type != Proto.MAGIC_TYPE_CONTROL) continue
                val o = JSONObject(String(frame.payload, Charsets.UTF_8))
                when (o.optString("t")) {
                    "ping" -> {
                        val seq = o.optLong("seq")
                        val t0 = o.optLong("t0")
                        val recv = Timeline.nowNs()
                        clock.onIncomingPing(t0, recv, recv)
                        runCatching { f.writeJson(Msg.pong(seq, t0, recv, Timeline.nowNs())) }
                    }
                    "clock" -> {
                        val rtt = o.optLong("rtt", -1)
                        if (rtt > 0) clock.onRttReported(rtt, o.optLong("t0"), o.optLong("c1"))
                    }
                    "volsync" -> {
                        // 主机侧音量统一开关
                        hostVolumeSyncEnabled = o.optBoolean("enabled", true)
                        val pct = o.optInt("vol", -1)
                        if (pct >= 0 && hostVolumeSyncEnabled && isVolumeSyncActive()) {
                            hostVolumePercent = pct
                            applyVolumeNow(pct)
                        }
                    }
                    "volume" -> {
                        // 音量包：立即对齐，不等待下一轮
                        val pct = o.optInt("vol", -1)
                        if (pct >= 0) {
                            hostVolumePercent = pct
                            applyVolumeNow(pct)
                        }
                    }
                    "media" -> {
                        hostTitle = o.optString("title")
                        hostArtist = o.optString("artist")
                        hostPosMs = o.optLong("pos")
                        hostPlaying = o.optBoolean("playing")
                        hostSpeed = o.optDouble("speed", 1.0).toFloat()
                        hostSeekable = o.optBoolean("seekable")
                        val pct = o.optInt("vol", -1)
                        if (pct >= 0 && pct != hostVolumePercent) {
                            hostVolumePercent = pct
                            applyVolumeNow(pct)
                        }
                        rawPosMs = o.optLong("rawPos", -1L)
                        // 换算成本地时刻
                        hostStampLocalNs = clock.hostToLocal(o.optLong("hostNs"))
                        hasHostState = true
                    }
                }
            }
        } catch (_: Throwable) {
        } finally {
            if (running) fatalError = "与主机连接已断开"
        }
    }

    /**
     * 对齐循环。
     *
     * 周期：每 3 秒执行一次主动对齐（用户要求），
     * 中间每 100ms 只做轻量监控，不触碰音乐 App。
     *
     * 死区：15ms 以内不动，避免 seek 抖动。
     * seek 后校验：记录目标位置与发起时刻，下次比对确认是否生效。
     */
    private fun alignLoop() {
        var lastAlignNs = 0L
        while (running) {
            try {
                val now = System.nanoTime()
                val due = (now - lastAlignNs) >= ALIGN_PERIOD_NS
                doMonitor()          // 轻量：更新统计与音量
                if (due) {
                    lastAlignNs = now
                    doAlign()        // 重量：必要时 seek
                }
            } catch (t: Throwable) {
                onLog("对齐异常：${t.message}")
            }
            try { Thread.sleep(100) } catch (_: InterruptedException) { return }
        }
    }

    /**
     * 计算「此刻主机应该播放到的位置（毫秒）」。
     *
     * 用主机下发的原始快照做本地外推，比直接用主机外推好的值更准：
     *   主机时刻 hostStamp 对应主机位置 rawPos
     *   经过 (现在本地时刻 - hostStamp 的本地等价) 之后
     *   应再前进 elapsed * speed
     *
     * hostNs 是主机发消息瞬间的主机时钟，经 clock.hostToLocal 换算成本地时刻，
     * 再与本地 now 相减得到真实经过时间。
     */
    private fun hostPositionNowMs(): Long {
        if (!hasHostState) return 0
        val basePos = if (rawPosMs >= 0) rawPosMs else hostPosMs
        if (!hostPlaying) return basePos
        val elapsedNs = System.nanoTime() - hostStampLocalNs
        // 认为消息在主机侧发出到我们换算之间存在极小误差，忽略
        val elapsedMs = (elapsedNs / 1_000_000L).coerceAtLeast(0)
        return basePos + (elapsedMs * hostSpeed).toLong()
    }

    /** 轻量监控：只读本地状态、对齐音量，不做 seek */
    private fun doMonitor() {
        // 兜底：即使没收到音量包，也保证音量跟随（覆盖丢包情况）
        alignVolume()
    }

    /**
     * 立即应用音量（收到 volume 包时调用，不等轮询）。
     *
     * 关键：只改变本机音量，绝不回写主机。
     * 之前的实现让主从互相覆盖，形成拉锯。
     */
    private fun applyVolumeNow(percent: Int) {
        if (!isVolumeSyncActive()) return
        val vc = volumeController ?: return
        val localPct = (vc.currentPercent() * 100).toInt()
        // 已经足够接近就不动，避免频繁调用
        if (kotlin.math.abs(localPct - percent) <= 1) return
        val ok = vc.setPercent(percent / 100f)
        if (!ok) onLog("设置音量失败：目标 ${percent}%")
    }

    /**
     * 音量对齐兜底（轮询式）。
     *
     * 阈值从 5% 收紧到 2%——实测两台手机
     * 19/150=12.7% 与 2/15=13.3% 只差 0.6%，
     * 5% 的阈值会让它们永远不调。
     */
    private fun alignVolume() {
        if (!isVolumeSyncActive()) return
        val vc = volumeController ?: return
        if (hostVolumePercent < 0) return
        val localPct = (vc.currentPercent() * 100).toInt()
        if (kotlin.math.abs(localPct - hostVolumePercent) <= 2) return
        vc.setPercent(hostVolumePercent / 100f)
    }

    /** 周期对齐：必要时 seek */
    private fun doAlign() {
        if (!hasHostState || !clock.isSynced) {
            hint = "等待时钟同步"
            return
        }
        val ctrl: MediaController = bridge.findController(targetPackage) ?: run {
            hint = "未检测到音乐 App，请打开网易云"
            return
        }
        val local = bridge.snapshot(ctrl) ?: run {
            hint = "音乐 App 无播放信息"
            return
        }

        // 歌曲一致性
        val hostKey = normalizeKey(hostTitle, hostArtist)
        val localKey = normalizeKey(local.title, local.artist)
        val songMatch = hostKey.isNotEmpty() && hostKey == localKey
        if (!songMatch) {
            hint = "歌曲不同：请手动切到「${hostTitle}」"
            return
        }
        hint = null

        // 播放状态同步
        if (hostPlaying != local.playing) {
            if (System.nanoTime() - lastSeekAt > 1_000_000_000L) {
                bridge.setPlaying(ctrl, hostPlaying)
                lastSeekAt = System.nanoTime()
                onLog("同步播放状态 -> ${if (hostPlaying) "播放" else "暂停"}")
            }
            return
        }

        val hostPos = hostPositionNowMs()
        val localPos = local.positionNowMs()
        val diff = localPos - hostPos

        // 死区：15ms 内不动
        if (kotlin.math.abs(diff) <= DEAD_ZONE_MS) {
            inDeadZone = true
            return
        }
        inDeadZone = false

        // 正在校验上一次 seek，跳过本轮
        if (pendingSeekTargetMs >= 0 && System.nanoTime() - lastSeekAt < 800_000_000L) {
            return
        }
        // 上一次 seek 的结果校验
        if (pendingSeekTargetMs >= 0) {
            val delta = kotlin.math.abs(localPos - pendingSeekTargetMs)
            lastSeekErrorMs = delta
            pendingSeekTargetMs = -1
            if (delta > DEAD_ZONE_MS * 2) {
                onLog("seek 未完全生效：目标 ${pendingSeekTargetMs}ms 实际 ${localPos}ms 误差 ${delta}ms")
            }
        }

        if (!bridge.supportsSeek(local) && !hostSeekable) {
            hint = "音乐 App 不支持精确跳转"
            return
        }
        // 频率保护：最短 2.5 秒一次 seek，避免连续抖动
        if (System.nanoTime() - lastSeekAt < MIN_SEEK_INTERVAL_NS) return

        seeking = true
        val target = hostPos + SEEK_LEAD_MS
        val ok = bridge.seekTo(ctrl, target)
        lastSeekAt = System.nanoTime()
        seeking = false
        if (ok) {
            seekCount++
            pendingSeekTargetMs = target
            onLog("周期对齐：本地 ${localPos}ms -> 目标 ${target}ms (偏差 ${diff}ms)")
        } else {
            hint = "seek 失败"
        }
    }

    private fun normalizeKey(title: String, artist: String): String {
        fun clean(s: String) = s.lowercase()
            .replace(Regex("[\\s\\-_()（）\\[\\]【】·.,，。!！?？]"), "")
        return clean(title) + "|" + clean(artist)
    }

    private fun statsLoop() {
        while (running) {
            val ctrl = runCatching { bridge.findController(targetPackage) }.getOrNull()
            val local = ctrl?.let { runCatching { bridge.snapshot(it) }.getOrNull() }
            val hostKey = normalizeKey(hostTitle, hostArtist)
            val localKey = normalizeKey(local?.title ?: "", local?.artist ?: "")
            val songMatch = hostKey.isNotEmpty() && hostKey == localKey
            val hostPosNow = hostPositionNowMs()
            val vc = volumeController
            val localVolPct = ((vc?.currentPercent() ?: 0f) * 100).toInt()
            val localPos = local?.positionNowMs() ?: 0
            onStats(
                Stats(
                    connected = running,
                    hostSong = hostTitle.ifEmpty { "-" },
                    hostArtist = hostArtist,
                    hostPositionMs = hostPosNow,
                    hostPlaying = hostPlaying,
                    hostVolumePercent = hostVolumePercent,
                    localVolumePercent = localVolPct,
                    whileSyncingVolume = hostVolumePercent >= 0 &&
                        kotlin.math.abs(localVolPct - hostVolumePercent) >= 5,
                    localSong = local?.title ?: "-",
                    localArtist = local?.artist ?: "",
                    localPositionMs = localPos,
                    localPlaying = local?.playing ?: false,
                    offsetMs = localPos - hostPosNow,
                    rttMs = clock.lastRttMs,
                    songMatch = songMatch,
                    lastSeekAtMs = lastSeekAt / 1_000_000L,
                    seekCount = seekCount,
                    seeking = seeking,
                    hasPermission = bridge.hasPermission(),
                    error = fatalError,
                    hint = hint,
                    inDeadZone = inDeadZone,
                    lastSeekErrorMs = lastSeekErrorMs,
                    jitterMs = clock.jitterNs / 1_000_000,
                    deadZoneMs = DEAD_ZONE_MS,
                    volumeSyncActive = isVolumeSyncActive(),
                    hostVolumeSyncEnabled = hostVolumeSyncEnabled,
                    localVolumeSyncEnabled = localVolumeSyncEnabled
                )
            )
            try { Thread.sleep(300) } catch (_: InterruptedException) { return }
        }
    }

    fun stop() {
        running = false
        readThread?.interrupt()
        alignThread?.interrupt()
        statsThread?.interrupt()
        readThread = null
        alignThread = null
        statsThread = null
        closeAll()
    }

    private fun closeAll() {
        try { socket?.close() } catch (_: Throwable) { }
        socket = null
        fs = null
    }
}
