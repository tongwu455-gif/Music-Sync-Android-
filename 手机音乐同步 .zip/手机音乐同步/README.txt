# 手机音乐同步（SyncCast）—— 工程说明

> 多台 Android 手机同步播放网易云/QQ 音乐
> 最终版本：**0.3.2-voltoggle**（versionCode 7）

---

## 一、这个项目要解决什么问题

**场景**：几台手机放在不同房间，想同时播放同一首歌，听起来像一个整体的音响系统。

**难点**：

1. 网易云、QQ 音乐的音频流是加密的，无法导出
2. Android 8+ 禁止第三方 App 直接录制其他 App 的音频（需要目标 App 声明 `allowAudioPlaybackCapture`，网易云/QQ音乐都没开）
3. 蓝牙 A2DP 是点对点的，一台手机只能连一个蓝牙设备，无法组播

---

## 二、方案演进（重要：为什么最终是这个方案）

这个项目经历了**两个完全不同的技术方案**，理解演进过程才能看懂代码。

### 方案 A：麦克风采集 + 局域网推流（v0.1.x）

```
主机外放网易云 → 麦克风采集 PCM → 48kHz 分块 → TCP 广播 → 从机 AudioTrack 播放
```

**为什么放弃**：
- 音质是"扬声器→麦克风"的二次采集，和有线播放完全不是一个级别
- 主机必须外放，不能戴耳机
- 回声消除效果取决于机型，主机扬声器的声音会回灌进麦克风
- 主机自己也在外放，从机晚 200ms，两处同时听会有回声感
- 音频数据量大（768kbps）

实测数据（v0.1.1）：连接正常、收到 2202 个音频包，但 `writtenMs=0`——播放器把所有包都判定为"过期"丢弃。根因是时钟同步算出了 725433436ms（8.4 天）的荒谬偏移。

### 方案 B：MediaSession 状态同步（v0.2.0+，最终方案）

**关键发现**：通过 adb 检查发现网易云暴露了完整的 `MediaSession`：

```
MediaSession com.netease.cloudmusic/MediaSession/3844
  active=true
  controllers: 12
  state=PlaybackState {state=PLAYING, position=64250, speed=1.0, actions=822}
  metadata: "倒数" - G.E.M.邓紫棋
```

`actions=822 = 0x336` 解码：
```
ACTION_PAUSE       (0x002) ✅
ACTION_PLAY_PAUSE  (0x200) ✅
ACTION_SEEK_TO     (0x100) ✅  ← 关键！可精确跳转
ACTION_STOP        (0x010) ✅
ACTION_SKIP_TO_NEXT / PREVIOUS  ❌ 不支持
queueTitle=null, size=0         ❌ 队列为空
```

**于是方案变成**：

```
每台手机各自播放网易云（原生音质）
        ↓
主机读取自己的 MediaSession：歌曲名 + 播放位置 + 精确时间戳
        ↓
通过局域网广播（每 100ms 一次）
        ↓
从机读取自己的 MediaSession，推算"此刻主机应该播到哪"
        ↓
偏差 > 15ms → 调用 seekTo() 对齐
```

**优势**：
- 音质是网易云原生音质
- 不需要麦克风权限、不需要外放
- 带宽几乎为零（每秒几 KB）
- 不受网易云界面版本影响（用的是系统标准 API）

---

## 三、技术架构

### 3.1 模块结构

```
com.synccast.app
├── core/
│   ├── MediaSessionBridge.kt     读取/控制第三方音乐 App 的 MediaSession
│   ├── MediaNotificationListener.kt  通知监听服务（获得 MediaSession 访问权的入口）
│   ├── MediaMasterSession.kt     主机：读状态、广播
│   ├── MediaClientSession.kt     从机：接收、对比、seek 对齐
│   ├── ClockSync.kt              高精度时钟同步（偏移 + 漂移率）
│   ├── VolumeController.kt       系统媒体音量控制 + 变化监听
│   ├── Timeline.kt               时间工具
│   ├── Msg.kt                    消息构造
│   ├── FrameStream.kt            TCP 帧编解码
│   ├── Proto.kt                  协议常量
│   └── Net.kt                    网络工具、设备发现
├── service/
│   ├── MediaMasterService.kt     主机前台服务
│   └── MediaClientService.kt     从机前台服务
├── ui/
│   ├── SyncCastApp.kt            主界面 + 导航
│   ├── MediaSyncScreens.kt       主机页 / 从机页
│   └── theme/Theme.kt            主题
├── MainActivity.kt
├── SyncCastApp.kt                全局崩溃日志捕获
└── util/Perms.kt
```

### 3.2 通信协议

**传输层**：TCP，主机监听 47778 端口，从机主动连接。

**帧格式**（8 字节头 + 负载，小端）：
```
byte    type        1=CONTROL  2=AUDIO(已弃用)
byte    flags
short   reserved
int     payloadLen
byte[]  payload     (CONTROL 帧是 UTF-8 JSON)
```

**消息类型**：

| 消息 | 方向 | 字段 | 用途 |
|---|---|---|---|
| `hello` | 从机→主机 | clientId, name | 握手 |
| `ping` | 主机→从机 | seq, t0 | 时钟同步 |
| `pong` | 从机→主机 | seq, t0, c1, c2 | 时钟同步应答 |
| `clock` | 主机→从机 | rtt, t0, c1 | 回传 RTT 供从机算偏移 |
| `media` | 主机→从机 | title, artist, pos, rawPos, playing, speed, hostNs, vol | 播放状态（每 100ms） |
| `volume` | 主机→从机 | vol, max | 音量变化（事件驱动，立即发送） |
| `volsync` | 主机→从机 | enabled, vol | 音量统一开关状态 |

### 3.3 时钟同步算法

**问题**：主机和从机的 `System.nanoTime()` 各自从开机起算，起点不同。

**解决**：

```
t0 = 主机发出 ping 的主机时刻
c1 = 从机收到 ping 的本地时刻
t3 = 主机收到 pong 的主机时刻

RTT = t3 - t0
单向延迟 ≈ RTT / 2
offset = c1 - t0 - RTT/2     (offset = 本地时刻 - 主机时刻)
```

**精度优化**（`ClockSync.kt`）：

1. **保留 24 个样本的滑动窗口**
2. **只取 RTT 最低的 1/3 样本**——剔除排队抖动
3. **offset 取中位数**而非平均值，抗单点异常
4. **最小二乘拟合漂移率**（ppm）——补偿两台设备晶振频率差
5. **平滑跟随**：每次只修正 1/4，避免时间轴跳变
6. ping 频率：每 500ms 一次

**预期精度**：局域网 RTT < 5ms 时，offset 估计误差 ±1ms。

### 3.4 播放位置推算

**网易云的实测行为**（这是整个精度设计的关键）：

```
播放中，3 秒内采样 10 次：
position=119549     ← 始终不变
updated=770708076   ← 始终不变
```

**网易云一旦开始播放就再也不更新 PlaybackState**，系统里存的是按下播放那一刻的快照。之后位置完全靠 `speed=1.0` 线性推算。

因此从机这样计算：

```kotlin
// 主机下发：rawPos（原始快照位置）+ hostNs（主机时刻）
// 从机换算：hostStampLocalNs = clock.hostToLocal(hostNs)
// 推算当前位置：
elapsedMs = (System.nanoTime() - hostStampLocalNs) / 1_000_000
hostPosNow = rawPos + elapsedMs * speed
```

用**原始快照**而非主机已外推的值，避免二次误差累积。

### 3.5 对齐策略

```kotlin
// 每 100ms 轻量监控（只对齐音量）
// 每 3 秒一次主动对齐
死区：15ms 以内不动
防抖：两次 seek 最小间隔 2.5 秒
校验：seek 后 800ms 读回实际位置，记录误差
```

**为什么是"死区"而不是"精确对齐"**：
- `seekTo()` 从发出到实际生效有 50~200ms 的解码器延迟，无法控制
- 网易云 seek 后不刷新 `position`，无法验证是否精确生效
- 频繁 seek 会造成听感断续

所以正确策略是：**低频纠正漂移，而不是高频强对齐**。

### 3.6 音量同步

**难点**：不同手机音量档位数差异极大（实测 iQOO 0~150，三星 0~15），**必须按百分比而非绝对值**。

```kotlin
val target = (percent * am.getStreamMaxVolume(STREAM_MUSIC)).toInt()
am.setStreamVolume(STREAM_MUSIC, target, 0)  // flags=0，不用 SHOW_UI
```

**为什么不用 FLAG_SHOW_UI**：弹出系统音量条会抢焦点，部分 ROM 在 UI 显示期间会锁住音量值，导致程序设置被覆盖。

**开关设计**：主机和从机各有一个开关，逻辑与关系：

| 主机开关 | 从机开关 | 实际效果 |
|---|---|---|
| 开 | 开 | ✅ 同步 |
| 开 | 关 | ❌ 这台不跟随 |
| 关 | 开 | ❌ 全部不跟随 |

---

## 四、权限说明

| 权限 | 必需性 | 用途 |
|---|---|---|
| **通知使用权**（特殊权限） | **必需** | 访问 MediaSession 的唯一标准入口，不读通知内容 |
| 前台服务 | 必需 | 保持后台运行 |
| 通知（Android 13+） | 必需 | 前台服务通知 |
| 网络 | 必需 | 局域网通信 |
| RECORD_AUDIO | 已不需要 | 方案 B 不再录音，权限保留但代码不再使用 |

**授权步骤**：设置 → 通知使用权 → SyncCast → 打开

---

## 五、已知限制

### 5.1 硬限制（无法绕过）

1. **无法自动切歌**
   网易云 `actions=822` 不包含 `ACTION_SKIP_TO_NEXT/PREVIOUS`，`queueTitle=null`、队列为空。
   唯一的替代方案是无障碍服务模拟点击搜索，但网易云改版就会失效。

2. **seek 精度受硬件限制**
   网易云 seek 后不刷新 `position`，实际生效位置与目标可能有 50~200ms 偏差，无法验证。

3. **绝对对齐 vs 漂移控制**
   - ❌ 绝对对齐到 15ms：受 seek 硬件延迟限制，不可达
   - ✅ 漂移控制在 15ms 内：可行

### 5.2 使用限制

- 每台手机必须**各自打开网易云并播放同一首歌**
- 需要所有设备在同一 Wi-Fi（同网段，不能跨 AP 隔离）
- 部分 ROM 的省电策略会杀掉后台服务，建议手动加白名单

### 5.3 未完成的功能

- **自动切歌**（需要无障碍服务，见 5.1）
- **音量按响度匹配**（目前按百分比，不同机型扬声器功率不同，同等百分比听感可能差 2~3dB）
- **自动重连**（断网后需手动重连）

---

## 六、版本历史

| 版本 | 时间 | 主要变更 |
|---|---|---|
| 0.1.0-mvp | — | 麦克风方案初版 |
| 0.1.1 | — | 修复主线程网络崩溃（`NetworkOnMainThreadException`） |
| 0.1.2 | — | 修复 `startForeground` 未捕获异常 |
| 0.2.0-media | — | **切换方案 B**：MediaSession 状态同步，删除麦克风代码 |
| 0.2.1-vol | — | 新增音量按百分比同步 |
| 0.3.0-precise | — | 时钟同步升级、3 秒周期对齐、15ms 死区 |
| 0.3.1-volfix | — | 音量改为事件驱动、从机单向跟随、去掉 SHOW_UI |
| **0.3.2-voltoggle** | **当前** | **新增音量统一开关（主从可独立控制）** |

---

## 七、构建环境

```
JDK       17.0.13 (Temurin)
Gradle    8.7
AGP       8.3.2
Kotlin    1.9.23
SDK       compileSdk 34 / minSdk 26 / targetSdk 34
```

**构建命令**：

```powershell
$env:JAVA_HOME="D:\桌面\deepseek talk\.tools\jdk\jdk-17.0.13+11"
$env:ANDROID_HOME="D:\桌面\deepseek talk\.android-sdk"
cd sync-cast
..\.tools\gradle-8.7\bin\gradle.bat assembleDebug
```

**注意事项**：工程路径包含中文时，`gradle.properties` 必须包含：
```properties
android.overridePathCheck=true
```

---

## 八、调试经验（踩过的坑）

| 现象 | 根因 | 修复 |
|---|---|---|
| 从机点连接就闪退 | `Socket.connect()` 在主线程执行 | 移到后台线程 |
| 从机连上但没声音 | 时钟偏移算成 8.4 天，所有包被判"过期"丢弃 | 重写 `ClockSync` |
| 从机收到包但不播放 | 用绝对时刻比较墙钟，基准不一致 | 改用"写指针"相对间隔 |
| 音量要滑屏幕才同步 | 轮询 + 5% 阈值挡住 0.6% 差异 | 事件驱动 + 阈值收紧到 2% |
| 主从音量互相覆盖 | 双方都在写音量，形成拉锯 | 从机单向跟随，不回写 |
| 设置音量不生效 | `FLAG_SHOW_UI` 期间被 ROM 钳制 | 去掉 flag，改用回读校验 |
| 日志抓不到 | 部分 ROM 过滤 App 的 Log.i | 关键状态落盘到 `client_state.txt` |

---

## 九、文件清单

```
手机音乐同步/
├── README.md                          （本文件）
├── apk/
│   └── SyncCast-0.3.2-voltoggle.apk   最终版 APK
├── 历史版本apk/
│   └── ...                            各阶段 APK（供对比排查）
└── sync-cast源码/                     完整 Android Studio 工程
    ├── app/src/main/java/...
    ├── app/src/main/res/...
    ├── build.gradle.kts
    └── ...
```

**最终 APK 校验**：
- 文件名：`SyncCast-0.3.2-voltoggle.apk`
- 大小：8.33 MB
- versionCode：7
- SHA256：`8611139DB67F285C6637DB5A105BDED1BC24EE0758D158F8950E07C7D183E6BB`
